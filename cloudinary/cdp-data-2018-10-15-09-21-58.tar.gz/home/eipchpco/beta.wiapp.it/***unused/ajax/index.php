<?php
header("location: /portal/index.php");
?>