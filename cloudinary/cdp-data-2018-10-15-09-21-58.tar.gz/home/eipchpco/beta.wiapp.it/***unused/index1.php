<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/sessions.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/required/header.php';
 		
include_once '/home/eipchpco/beta.wiapp.it/portal/required/navbar_top.php';
?>
<!-- Navbar Tabs -->
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="index.php"><i class="icon-dashboard"></i><span>Dashboard</span> </a> </li>
        <li><a href="reports.php"><i class="icon-list-alt"></i><span>Reports</span> </a> </li>
        <li><a href="guidely.php"><i class="icon-facetime-video"></i><span>App Tour</span> </a></li>
        <li><a href="charts.php"><i class="icon-bar-chart"></i><span>Charts</span> </a> </li>
        <li><a href="shortcodes.php"><i class="icon-code"></i><span>Shortcodes</span> </a> </li>
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-long-arrow-down"></i><span>Drops</span> <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="icons.php">Icons</a></li>
            <li><a href="faq.php">FAQ</a></li>
            <li><a href="pricing.php">Pricing Plans</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="signup.php">Signup</a></li>
            <li><a href="error.php">404</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- /container -->
  </div>
  <!-- /subnavbar-inner -->
</div>
<!-- /subnavbar -->
<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row">
    
    <br><br><br><br><br><br><br><br><br><br>
<?php
echo $_SESSION['id'];
echo "&nbsp";
echo $_SESSION['email'];
echo "&nbsp";
echo $_SESSION['username'];
?>
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    
<?php
//include_once '/home/eipchpco/beta.wiapp.it/portal/modules/guidely_content.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';
      
include_once '/home/eipchpco/beta.wiapp.it/portal/required/footer_bottom.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/required/scripts.php';

//include_once '/home/eipchpco/beta.wiapp.it/portal/pagedata/guidely_data.php';

?>