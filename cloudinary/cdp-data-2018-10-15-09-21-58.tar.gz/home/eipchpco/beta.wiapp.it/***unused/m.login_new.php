<?php require_once '/home/eipchpco/beta.wiapp.it/inc/detect.php';?>
<?php if (Detect::isComputer()) header("location:/login.php");?>
<?php if(isset($_SESSION['id'])) header("location:/connections.php");?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Wi-APP | Login</title>
<meta name = "viewport" content = "width = device-width">
<meta name = "viewport" content = "initial-scale = 1.0, user-scalable = no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    echo '<link href="css/bootstrapi.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivei.min.css" rel="stylesheet">';
    echo '<link href="css/stylei.css" rel="stylesheet">';
    echo '<link href="css/pages/signini.css" rel="stylesheet">';
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    echo '<link href="css/bootstrapa.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivea.min.css" rel="stylesheet">';
    echo '<link href="css/stylea.css" rel="stylesheet">';
    echo '<link href="css/pages/signina.css" rel="stylesheet">';
    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    echo '<link href="css/pages/signinm.css" rel="stylesheet">';
    echo '<link href="css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="css/stylem.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivem.min.css" rel="stylesheet">';
    }
else if (Detect::isComputer()) {
    $notmobile = 101;
    //echo 'Computer';
    echo '<link href="css/bootstrap.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsive.min.css" rel="stylesheet">';
    echo '<link href="css/style.css" rel="stylesheet">';
    echo '<link href="css/pages/signin.css" rel="stylesheet">';
}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    echo '<link href="css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivem.min.css" rel="stylesheet">';    
    echo '<link href="css/stylem.css" rel="stylesheet">';
    echo '<link href="css/pages/signinm.css" rel="stylesheet">';
}

?>



<?php
include_once '/home/eipchpco/beta.wiapp.it/inc/required/sessions.php';
include_once '/home/eipchpco/beta.wiapp.it/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/inc/utilities.php';

if(isset($_POST['loginBtn'])){

//Array to hold errors
$form_errors = array();

// Validate 
	$required_fields = array('loginEmail', 'loginPassword');

	//call the function to check empty field and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_empty_fields($required_fields));
	
	if(empty($form_errors)){
	
	//collect form data
	$user = $_POST['loginEmail'];
	$password = $_POST['loginPassword'];
	
	$user = strtolower($user);
	
	//check if user exist in database
	$sqlQuery = "SELECT * FROM users WHERE email = :Email";
	$statement = $db->prepare($sqlQuery);
	$statement->execute(array(':Email' => $user));
	
	if(!isset($_SESSION['email'])) $result = "<h4 style='color: #381A64; border solid gray;'>" . $user . " is not registered on Wi-APP.<br><br><a href='signup.php'>Register</a>a new acccount.<br><br></h4>";
	$_SESSION['notRegistered'] = $user;
	
	while($row = $statement->fetch()){
		$id = $row['id'];
		$hashed_password = $row['password'];
		$user_email = $row['email'];
		
		if(password_verify($password, $hashed_password)){
			$_SESSION['id'] = $id;
			$_SESSION['email'] = $user_email;
			
		
			if(isset($row['defaultVerification'])) $defaultVerification = $row['defaultVerification'];
			$_SESSION['defaultVerification'] = $defaultVerification;
			
			if(isset($row['first_name'])) $first_name = $row['first_name'];
			if(isset($row['middle_name'])) $middle_name = $row['middle_name'];
			if(isset($row['last_name'])) $last_name = $row['last_name'];
		
			if(isset($row['cell'])) $cell = $row['cell'];
			if(isset($row['dob'])) $dob = $row['dob'];
			if(isset($row['gender'])) $gender = $row['gender'];
			if(isset($row['status'])) $status = $row['status'];
		
			if(isset($row['sc_cell'])) $sc_cell = $row['sc_cell'];
			if(isset($row['sc_whatsapp'])) $sc_whatsapp = $row['sc_whatsapp'];
			if(isset($row['sc_skype'])) $sc_skype = $row['sc_skype'];		
        		
			if(isset($row['hs_street_name'])) $_SESSION['hs_street_name'] = $row['hs_street_name'];
			if(isset($row['hs_number'])) $_SESSION['hs_number'] = $row['hs_number'];
			if(isset($row['hs_suburb'])) $_SESSION['hs_suburb'] = $row['hs_suburb'];
			if(isset($row['hs_city'])) {$_SESSION['hs_city'] = $row['hs_city'];
			}else{
			$_SESSION['hs_city'] = $row['city'];
			}; 
			
			if(isset($row['hs_province'])) {$_SESSION['hs_province'] = $row['hs_province'];
			}else{
			$_SESSION['hs_province'] = $row['province'];
			};
			
			if(isset($row['hs_country'])) {$_SESSION['hs_country'] = $row['hs_country'];
			}else{
			$_SESSION['hs_country'] = $row['country'];
			};   
			
        	if(isset($row['hp_street_name'])) $_SESSION['hp_street_name'] = $row['hp_street_name'];
			if(isset($row['hp_number'])) $_SESSION['hp_number'] = $row['hp_number'];        	
			if(isset($row['hp_suburb'])) $_SESSION['hp_suburb'] = $row['hp_suburb'];
			
			if(isset($row['hp_city'])) {$_SESSION['hp_city'] = $row['hp_city'];
			}else{
			$_SESSION['hp_city'] = $row['city'];
			}; 
			
			if(isset($row['hp_province'])) {$_SESSION['hp_province'] = $row['hp_province'];
			}else{
			$_SESSION['hp_province'] = $row['province'];
			};
			
        	if(isset($row['hp_code'])) $_SESSION['hp_code'] = $row['hp_code'];
        	
        	if(isset($row['hp_country'])) {$_SESSION['hp_country'] = $row['hp_country'];
        	}else{
			$_SESSION['hp_country'] = $row['country'];
			};
			
			if(isset($row['ws_street_name'])) $_SESSION['ws_street_name'] = $row['ws_street_name'];
			if(isset($row['ws_number'])) $_SESSION['ws_number'] = $row['ws_number'];
			if(isset($row['ws_suburb'])) $_SESSION['ws_suburb'] = $row['ws_suburb'];
			
			if(isset($row['ws_city'])) {$_SESSION['ws_city'] = $row['ws_city'];
			}else{
			$_SESSION['ws_city'] = $row['city'];
			}; 
			
			if(isset($row['ws_province'])) {$_SESSION['ws_province'] = $row['ws_province'];
			}else{
			$_SESSION['ws_province'] = $row['province'];
			};
			
			if(isset($row['ws_country'])) {$_SESSION['ws_country'] = $row['ws_country'];
			}else{
			$_SESSION['ws_country'] = $row['country'];
			};	
			
        	if(isset($row['wp_street_name'])) $_SESSION['wp_street_name'] = $row['wp_street_name'];
        	if(isset($row['wp_number'])) $_SESSION['wp_number'] = $row['wp_number'];
			if(isset($row['wp_suburb'])) $_SESSION['wp_suburb'] = $row['wp_suburb'];
			
			if(isset($row['wp_city'])) {$_SESSION['wp_city'] = $row['wp_city'];
			}else{
			$_SESSION['wp_city'] = $row['city'];
			}; 
			
			if(isset($row['wp_province'])) {$_SESSION['wp_province'] = $row['wp_province'];
			}else{
			$_SESSION['wp_province'] = $row['province'];
			};
			
        	if(isset($row['wp_code'])) $_SESSION['wp_code'] = $row['wp_code'];
        	
        	if(isset($row['wp_country'])) {$_SESSION['wp_country'] = $row['wp_country'];
        	}else{
			$_SESSION['wp_country'] = $row['country'];
			};
			
		$username = $first_name.'&nbsp'.$last_name;
			
			if(isset($username)) $_SESSION['username'] = $username;
			if(isset($first_name)) $_SESSION['first_name'] = $first_name;
			if(isset($middle_name)) $_SESSION['middle_name'] = $middle_name;
			if(isset($last_name)) $_SESSION['last_name'] = $last_name; 
			if(!isset($cell)) $cell = "+27";
			if(isset($cell)) $_SESSION['cell'] = $cell;
			if(isset($dob)) $_SESSION['dob'] = $dob;
			if(isset($sc_cell)) $_SESSION['sc_cell'] = $sc_cell;
			if(isset($sc_whatsapp)) $_SESSION['sc_whatsapp'] = $sc_whatsapp;
			if(isset($sc_skype)) $_SESSION['sc_skype'] = $sc_skype;
			if(isset($gender)) $_SESSION['gender'] = $gender;
			if(isset($status)) $_SESSION['status'] = $status;
			
			if(!isset($_SESSION['sc_cell'])) $_SESSION['sc_cell'] = $cell;
			if(!isset($_SESSION['sc_whatsapp'])) $_SESSION['sc_whatsapp'] = $cell;
	
		}else{
		   
			$result = "<h4 style='color: #381A64; border solid gray;'> The <b>Password</b> entered does not match that of the email provided.</h4>";
			
		} 
	}
	
	}else{
		if(count($form_errors) == 1){
			$result = "<h3 style='color: #381A64;'>There was one error in the form </h3>";
		}else{
			$result = "<h3 style='color: #381A64;'>There were " .count($form_errors). " errors in the form</h3>";
		}
	}
}




if(isset($_SESSION['id'])){

//Array to hold errors
$form_errors = array();
	
	if(empty($form_errors)){
	
	//collect form data
	$userID = $_SESSION['id'];
	
	//check if user has Professional Card in database
	$sqlQuery = "SELECT * FROM professional_card WHERE userID = :userID";
	$statement = $db->prepare($sqlQuery);
	$statement->execute(array(':userID' => $userID));
	
	while($row = $statement->fetch()){
		$pcID = $row['pcID'];
		$pc_facebook = $row['pc_facebook'];
		$pc_facebook_perm = $row['pc_facebook_perm'];
		
		$_SESSION['pc_facebook'] = $pc_facebook;	
		$_SESSION['pc_facebook_perm'] = $pc_facebook_perm;	
		
		header("location: index.php");
	}
	
	
	}else{
		if(count($form_errors) == 1){
			$result = "<h3 style='color: #381A64;'>There was one error in the form </h3>";
		}else{
			$result = "<h3 style='color: #381A64;'>There were " .count($form_errors). " errors in the form</h3>";
		}
	}
}

?>








<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script>
function checkServer()
{
    var ajaxrequest;
    var email = document.getElementById("Email").value;
    
    if (window.XMLHttpRequest)
    {
        ajaxrequest = new XMLHttpRequest();
    } else {
        ajaxrequest = new ActiveXObject("Microsoft.XMLHTTP"); /// Older Browsers
    }
    
    ajaxrequest.onreadystatechange = function()
    {
        console.log(ajaxrequest);
    if (ajaxrequest.readyState == 4 && ajaxrequest.status == 200)
    {
        document.getElementById("WelcomeUserResponse").innerHTML = ajaxrequest.responseText;
        }
    }
    ajaxrequest.open("POST", "/modules/register/welcome_user.php", true);
    ajaxrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajaxrequest.send("Email=" + email);
}
</script>
    
</head>
<body>

<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
  <div>
    <div class="container">
                    <a href="http://beta.wiapp.it"><img src="/img/tiles/apple-icon-152x152.png" width="70px" hspace="8" alt="Wi-APP"></a>
  </div>
  </div>
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span> 
			</a><a class="brand" href="/portal.php">Wi-APP</a>
			
			<div class="nav-collapse">
				<ul class="nav pull-right">
					
					<li class="">						
						<a href="/portal.php" style="color:#fff">
							                                            <i class="icon-info-sign "></i>
							<div text style="position:relative; margin: -22px 14px;"> Learn more about Wi-APP</div>
						</a>
					</li>
					
				</ul>
			</div><!--/.nav-collapse -->	
		</div> <!-- /container -->
	</div> <!-- /navbar-inner -->
</div> <!-- /navbar -->
<br><br>
</div> <!-- /login-extra -->

<div class="account-container">
	<div class="content clearfix">
	    
	    
		<form id="login" action="" method="post">
			<center><h1>Member Login</h1></center>		
			
			<div class="login-fields">
	<center><div id='WelcomeUserResponse'></div></center>			
	<center><?php //if(!isset($result)) echo "Please provide your details<br><br>";
	?></center>	
	<center><?php //if(isset($result)) echo "Oops, some errors occured.";
	?></center>			
	<center><?php //if(isset($result)) echo $result;
	?></center>
	<center><?php //if(!empty($form_errors)) echo show_errors($form_errors);
	?></center>			
				<br>
				<div class="field">
					<label for="Email">Email Address:</label>
					<input class="username-field" type="Email" id="loginEmail" name="loginEmail" value="<?php if(isset($_POST['loginEmail'])){ echo htmlentities ($_POST['loginEmail']); }else if(isset($_SESSION['registered'])){echo $_SESSION['registered'];};?>" required placeholder="Email" onblur="checkServer()" class="login"/>
				</div> <!-- /field -->
				
				<div class="field">					
					<label for="Password">Password:</label>
					<input class="password-field" type="Password" id="loginPassword" name="loginPassword" title="Minimum 7
characters, one number, one uppercase and one lowercase letter"
pattern="(?=^.{7,}$).*" value="" required placeholder="Password" class="login"/>
				</div> <!-- /field -->
			</div> <!-- /login-fields -->
			
			<div class="login-actions">
				
<!--				<span class="login-checkbox">
					<input id="Field" name="Field" type="checkbox" class="field login-checkbox" value="First Choice" tabindex="4" />
					<center><label class="choice" for="Field">Keep me signed in</label></center>
				</span>										-->
									
				<input button type="submit" name="loginBtn" value="Log In" class="button btn btn-default btn-medium">
			</div> <!-- .actions -->				
		</form>
		
		
		
	</div> <!-- /content -->
</div> <!-- /account-container -->
<!-- Text Under Box -->
<div class="login-extra">
	<center>Don't have an account? <a href="m.signup.php">Create your free account.</a></center>
	
</div> <!-- /login-extra -->

<div class="login-extra">
	<center><a href="#">Reset Password here</a>&nbspif you have forgotten it.</center>
</div> <!-- /login-extra -->


<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/signin.js"></script>

</body>

</html>