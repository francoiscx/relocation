<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/header.php';?>

<?php if(isset($_SESSION['id'])) header("location:/portal/connections.php");?>

<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    header("location: /portal/m.login.php");
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    header("location: /portal/m.login.php");

    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    header("location: /portal/m.login.php");

    }
else if (Detect::isComputer()) {
    $notmobile = 101;
    //echo 'Computer';
    header("location: /portal/login.php");


}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    header("location: /portal/login.php");
    
}

?>

