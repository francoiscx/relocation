<?php require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';?>

<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/m.header.php';
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/m.header.php';
    }
else if (Detect::isComputer()) {//browser reported as tablet device -- do something here
    //echo 'Computer';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/header.php';
}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/m.header.php';
}
?>
<!--------------- If redirects required place them below here --------------------->






<!--------------- If redirects required place them above here -------------------->
<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/m.navbar_top.php';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/cardi.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1cardi.css" rel="stylesheet">';}
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/m.navbar_top.php';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/carda.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1carda.css" rel="stylesheet">';}
    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/m.navbar_top.php';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/cardm.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1cardm.css" rel="stylesheet">';}
    }
else if (Detect::isComputer()) {//browser reported as tablet device -- do something here
    //echo 'Computer';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/navbar_top.php';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/card.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1card.css" rel="stylesheet">';}
}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/m.navbar_top.php';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/cardm.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1cardm.css" rel="stylesheet">';}
}
?>

    
<!-- Navbar Tabs -->  
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="index.php"><i class="icon-book"></i><span>Connections</span> </a> </li>
   <!--     <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-long-arrow-down"></i><span>Drops</span> <b class="caret"></b></a>  -->
   <!--       <ul class="dropdown-menu">   -->
        <!--    <li><a href="icons.php">Icons</a></li>  -->
          </ul>
        </li>
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>
<!-- /subnavbar -->



<div class="main">
	<div class="main-inner">
	    <div class="container">	
	      <div class="row">	      	
	      	<div class="span12">      			      		
	      		<div class="widget ">	      							
				<div class="widget-content">
						
				<label> <h3> </h3></label>	<br>	
						
						<div class="tabbable">
						<ul class="nav nav-tabs">
						  <li  class="active">
						    <a href="#cards" data-toggle="tab">Cards</a>
						  </li>
						  <li><a href="#ads" data-toggle="tab">Ads</a>
						  </li>
						  <li><a href="#shops" data-toggle="tab">Shops</a>
						  </li>
						  
						</ul>
						
						
						
<!-- ======================================================================================================================= -->						

						
						
							<div class="tab-content">
														
								<div class="tab-pane active" id="cards">							
								
									<form id="cards" class="form-vertical">
										<fieldset>
									
<br>


							
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/connections/cards.php' ?>							
							
	
		
		

							
							
										</fieldset>
									</form>
								
								</div>								
								
<!-- ======================================================================================================================= -->

								
								<div class="tab-pane" id="ads">								
								
									<form id="ads" class="form-vertical">
										<fieldset>
	
<br>	
	
											
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/connections/ads.php' ?>                                          
                         			
   
   
   
   
    
										</fieldset>
									</form>
								
								</div>								
								                                        
								
<!-- ======================================================================================================================= -->																
								
								
								<div class="tab-pane" id="shops">
								
									<form id="shops" class="form-vertical">
												
										
									<fieldset>
										
 <br>                                           
                                            
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/connections/shops.php' ?>                                          
                         			
   
   
   
   
    
										</fieldset>
									</form>
								
								</div>								
								                																						
											
<!---------------------------------------------------------------------------------------------------------------------------->
	
	                                           
				
									
									
									
								</div>
								
							</div>
						  
						  
						</div>
						
						
						
						
						
					</div> <!-- /widget-content -->
						
				</div> <!-- /widget -->
	      		
		    </div> <!-- /span8 -->
	      	
	      	
	      	
	      	
	      </div> <!-- /row -->
	
	    </div> <!-- /container -->
	    
	</div> <!-- /main-inner -->
    
</div> <!-- /main -->
    
    
<?php    
 
include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';
      
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/footer_bottom.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/scripts.php';