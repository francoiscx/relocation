<?php

include_once '/home/eipchpco/beta.wiapp.it/portal/required/header.php';
 		
include_once '/home/eipchpco/beta.wiapp.it/portal/required/navbar_top.php';

echo "<!-- Navbar Tabs -->  \n";
echo "<div class=\"subnavbar\">\n";
echo "  <div class=\"subnavbar-inner\">\n";
echo "    <div class=\"container\">\n";
echo "      <ul class=\"mainnav\">\n";
echo "        <li><a href=\"index.php\"><i class=\"icon-dashboard\"></i><span>Dashboard</span> </a> </li>\n";
echo "        <li><a href=\"reports.php\"><i class=\"icon-list-alt\"></i><span>Reports</span> </a> </li>\n";
echo "        <li><a href=\"guidely.php\"><i class=\"icon-facetime-video\"></i><span>App Tour</span> </a></li>\n";
echo "        <li><a href=\"charts.php\"><i class=\"icon-bar-chart\"></i><span>Charts</span> </a> </li>\n";
echo "        <li><a href=\"shortcodes.php\"><i class=\"icon-code\"></i><span>Shortcodes</span> </a> </li>\n";
echo "        <li class=\"dropdown\"><a href=\"javascript:;\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"> <i class=\"icon-long-arrow-down\"></i><span>Drops</span> <b class=\"caret\"></b></a>\n";
echo "          <ul class=\"dropdown-menu\">\n";
echo "            <li><a href=\"icons.php\">Icons</a></li>\n";
echo "            <li><a href=\"faq.php\">FAQ</a></li>\n";
echo "            <li class=\"active\"><a href=\"pricing.php\">Pricing Plans</a></li>\n";
echo "            <li><a href=\"login.php\">Login</a></li>\n";
echo "            <li><a href=\"signup.php\">Signup</a></li>\n";
echo "            <li><a href=\"error.php\">404</a></li>\n";
echo "          </ul>\n";
echo "        </li>\n";
echo "      </ul>\n";
echo "    </div>\n";
echo "    <!-- /container --> \n";
echo "  </div>\n";
echo "  <!-- /subnavbar-inner --> \n";
echo "</div>\n";
echo "<!-- /subnavbar -->\n";
echo "<div class=\"main\">\n";
echo "  <div class=\"main-inner\">\n";
echo "    <div class=\"container\">\n";
echo "      <div class=\"row\">";
    
?>
    
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	
	      <div class="row">
	      	
	      	<div class="span12">
	      		
	      		<div class="widget">
						
					<div class="widget-header">
						<i class="icon-th-large"></i>
						<h3>Choose Your Plan</h3>
					</div> <!-- /widget-header -->
					
					<div class="widget-content">
						
						<div class="pricing-plans plans-3">
							
						<div class="plan-container">
					        <div class="plan">
						        <div class="plan-header">
					                
						        	<div class="plan-title">
						        		First Agent	        		
					        		</div> <!-- /plan-title -->
					                
						            <div class="plan-price">
					                	$0<span class="term">For Life</span>
									</div> <!-- /plan-price -->
									
						        </div> <!-- /plan-header -->	        
						        
						        <div class="plan-features">
									<ul>
										<li><strong>Perfect</strong> for a small company looking to tackle  customer service across email.</li>
										<li>Easy to upgrade anytime</li>
										<li>Pay only what you need</li>
										<li>Chat support</li>
									</ul>
								</div> <!-- /plan-features -->
								
								<div class="plan-actions">				
									<a href="javascript:;" class="btn">Signup Now</a>				
								</div> <!-- /plan-actions -->
					
							</div> <!-- /plan -->
					    </div> <!-- /plan-container -->
					    
					    
					    
					    <div class="plan-container">
					        <div class="plan green">
						        <div class="plan-header">
					                
						        	<div class="plan-title">
						        		Flex Package	        		
					        		</div> <!-- /plan-title -->
					                
						            <div class="plan-price">
					                	$5<span class="term">Per Agent</span>
									</div> <!-- /plan-price -->
									
						        </div> <!-- /plan-header -->	          
						        
						        <div class="plan-features">
									<ul>					
										<li><strong>Perfect</strong> for mid size companies with round the clock support </li>
										<li>Flexible package</li>
										<li>Email & Chat support</li>
										<li>Multimedia support</li>
									</ul>
								</div> <!-- /plan-features -->
								
								<div class="plan-actions">				
									<a href="javascript:;" class="btn">Signup Now</a>				
								</div> <!-- /plan-actions -->
					
							</div> <!-- /plan -->
					    </div> <!-- /plan-container -->
					    
					    <div class="plan-container">
					        <div class="plan">
						        <div class="plan-header">
					                
						        	<div class="plan-title">
						        		Virtual Agent	        		
					        		</div> <!-- /plan-title -->
					                
						            <div class="plan-price">
					                	$30<span class="term">Per Month</span>
									</div> <!-- /plan-price -->
									
						        </div> <!-- /plan-header -->	       
						        
						        <div class="plan-features">
									<ul>
										<li><strong>Perfect</strong> for big companies with round the clock support and knwledge base.</li>
										<li>Easy to setup and use</li>
										<li>Mobile agent and multimedia support</li>
										<li>Universal inbox and cases</li>
									</ul>
								</div> <!-- /plan-features -->
								
								<div class="plan-actions">				
									<a href="javascript:;" class="btn">Signup Now</a>				
								</div> <!-- /plan-actions -->
					
							</div> <!-- /plan -->
							
					    </div> <!-- /plan-container -->
				
				
					</div> <!-- /pricing-plans -->
						
					</div> <!-- /widget-content -->
						
				</div> <!-- /widget -->					
				
		    </div> <!-- /span12 -->     	
	      	
<?php>
	      	
include_once '/home/eipchpco/beta.wiapp.it/portal/required/break_before_footer.php';    
    
include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';
      
include_once '/home/eipchpco/beta.wiapp.it/portal/required/footer_bottom.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/required/scripts.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/pagedata/index_data.php';


?>