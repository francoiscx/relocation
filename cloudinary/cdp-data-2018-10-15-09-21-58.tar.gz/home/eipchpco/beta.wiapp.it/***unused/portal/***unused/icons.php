<?php

include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/header.php';
 		
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/navbar_top.php';

echo "<!-- Navbar Tabs -->  \n";
echo "<div class=\"subnavbar\">\n";
echo "  <div class=\"subnavbar-inner\">\n";
echo "    <div class=\"container\">\n";
echo "      <ul class=\"mainnav\">\n";
echo "        <li><a href=\"index.php\"><i class=\"icon-dashboard\"></i><span>Dashboard</span> </a> </li>\n";
echo "        <li><a href=\"reports.php\"><i class=\"icon-list-alt\"></i><span>Reports</span> </a> </li>\n";
echo "        <li><a href=\"guidely.php\"><i class=\"icon-facetime-video\"></i><span>App Tour</span> </a></li>\n";
echo "        <li><a href=\"charts.php\"><i class=\"icon-bar-chart\"></i><span>Charts</span> </a> </li>\n";
echo "        <li><a href=\"shortcodes.php\"><i class=\"icon-code\"></i><span>Shortcodes</span> </a> </li>\n";
echo "        <li class=\"dropdown\"><a href=\"javascript:;\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"> <i class=\"icon-long-arrow-down\"></i><span>Drops</span> <b class=\"caret\"></b></a>\n";
echo "          <ul class=\"dropdown-menu\">\n";
echo "            <l class=\"active\"><a href=\"icons.php\">Icons</a></li>\n";
echo "            <li><a href=\"faq.php\">FAQ</a></li>\n";
echo "            <li><a href=\"pricing.php\">Pricing Plans</a></li>\n";
echo "            <li><a href=\"login.php\">Login</a></li>\n";
echo "            <li><a href=\"signup.php\">Signup</a></li>\n";
echo "            <li><a href=\"error.php\">404</a></li>\n";
echo "          </ul>\n";
echo "        </li>\n";
echo "      </ul>\n";
echo "    </div>\n";
echo "    <!-- /container --> \n";
echo "  </div>\n";
echo "  <!-- /subnavbar-inner --> \n";
echo "</div>\n";
echo "<!-- /subnavbar -->\n";
echo "<div class=\"main\">\n";
echo "  <div class=\"main-inner\">\n";
echo "    <div class=\"container\">\n";
echo "      <div class=\"row\">";

    
    
?>    
    
<div class="main">
	
	<div class="main-inner">

	    <div class="container">
	<div class="row all-icons">
    
    <div class="widget">
                            <div class="widget-header">
                                <i class="icon-bar-chart"></i>
                                <h3>
                                    Icons</h3>
                            </div>
                            <!-- /widget-header -->
                            <div class="widget-content">
                            
                              <div class="span3 ML0">
          <ul>
            
                <li style="line-height: 32px;"><i class="icon-large icon-glass
"></i> icon-glass
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-music
"></i> icon-music
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-search
"></i> icon-search
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-envelope
"></i> icon-envelope
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-heart
"></i> icon-heart
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-star
"></i> icon-star
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-star-empty
"></i> icon-star-empty
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-user
"></i> icon-user
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-film
"></i> icon-film
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-th-large
"></i> icon-th-large
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-th
"></i> icon-th
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-th-list
"></i> icon-th-list
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-ok
"></i> icon-ok
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-remove
"></i> icon-remove
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-zoom-in
"></i> icon-zoom-in
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-zoom-out
"></i> icon-zoom-out
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-off
"></i> icon-off
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-signal
"></i> icon-signal
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-cog
"></i> icon-cog
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-trash
"></i> icon-trash
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-home
"></i> icon-home
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-file
"></i> icon-file
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-time
"></i> icon-time
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-road
"></i> icon-road
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-download-alt
"></i> icon-download-alt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-download
"></i> icon-download
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-upload
"></i> icon-upload
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-inbox
"></i> icon-inbox
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-play-circle
"></i> icon-play-circle
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-repeat
"></i> icon-repeat
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-refresh
"></i> icon-refresh
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-list-alt
"></i> icon-list-alt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-lock
"></i> icon-lock
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-flag
"></i> icon-flag
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-headphones
"></i> icon-headphones
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-volume-off
"></i> icon-volume-off
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-volume-down
"></i> icon-volume-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-volume-up
"></i> icon-volume-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-qrcode
"></i> icon-qrcode
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-barcode
"></i> icon-barcode
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-tag
"></i> icon-tag
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-tags
"></i> icon-tags
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-book
"></i> icon-book
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-bookmark
"></i> icon-bookmark
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-print
"></i> icon-print
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-camera
"></i> icon-camera
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-font
"></i> icon-font
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-bold
"></i> icon-bold
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-italic
"></i> icon-italic
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-text-height
"></i> icon-text-height
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-text-width
"></i> icon-text-width
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-align-left
"></i> icon-align-left
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-align-center
"></i> icon-align-center
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-align-right
"></i> icon-align-right
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-align-justify
"></i> icon-align-justify
</li>
            
          </ul>
        </div>
    
        <div class="span3 ML0">
          <ul>
            
                <li style="line-height: 32px;"><i class="icon-large icon-list
"></i> icon-list
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-indent-left
"></i> icon-indent-left
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-indent-right
"></i> icon-indent-right
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-facetime-video
"></i> icon-facetime-video
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-picture
"></i> icon-picture
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-pencil
"></i> icon-pencil
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-map-marker
"></i> icon-map-marker
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-adjust
"></i> icon-adjust
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-tint
"></i> icon-tint
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-edit
"></i> icon-edit
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-share
"></i> icon-share
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-check
"></i> icon-check
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-move
"></i> icon-move
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-step-backward
"></i> icon-step-backward
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-fast-backward
"></i> icon-fast-backward
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-backward
"></i> icon-backward
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-play
"></i> icon-play
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-pause
"></i> icon-pause
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-stop
"></i> icon-stop
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-forward
"></i> icon-forward
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-fast-forward
"></i> icon-fast-forward
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-step-forward
"></i> icon-step-forward
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-eject
"></i> icon-eject
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-chevron-left
"></i> icon-chevron-left
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-chevron-right
"></i> icon-chevron-right
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-plus-sign
"></i> icon-plus-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-minus-sign
"></i> icon-minus-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-remove-sign
"></i> icon-remove-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-ok-sign
"></i> icon-ok-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-question-sign
"></i> icon-question-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-info-sign
"></i> icon-info-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-screenshot
"></i> icon-screenshot
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-remove-circle
"></i> icon-remove-circle
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-ok-circle
"></i> icon-ok-circle
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-ban-circle
"></i> icon-ban-circle
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-arrow-left
"></i> icon-arrow-left
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-arrow-right
"></i> icon-arrow-right
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-arrow-up
"></i> icon-arrow-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-arrow-down
"></i> icon-arrow-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-share-alt
"></i> icon-share-alt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-resize-full
"></i> icon-resize-full
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-resize-small
"></i> icon-resize-small
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-plus
"></i> icon-plus
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-minus
"></i> icon-minus
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-asterisk
"></i> icon-asterisk
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-exclamation-sign
"></i> icon-exclamation-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-gift
"></i> icon-gift
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-leaf
"></i> icon-leaf
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-fire
"></i> icon-fire
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-eye-open
"></i> icon-eye-open
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-eye-close
"></i> icon-eye-close
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-warning-sign
"></i> icon-warning-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-plane
"></i> icon-plane
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-calendar
"></i> icon-calendar
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-random
"></i> icon-random
</li>
            
          </ul>
        </div>
    
        <div class="span3">
          <ul>
            
                <li style="line-height: 32px;"><i class="icon-large icon-comment
"></i> icon-comment
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-magnet
"></i> icon-magnet
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-chevron-up
"></i> icon-chevron-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-chevron-down
"></i> icon-chevron-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-retweet
"></i> icon-retweet
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-shopping-cart
"></i> icon-shopping-cart
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-folder-close
"></i> icon-folder-close
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-folder-open
"></i> icon-folder-open
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-resize-vertical
"></i> icon-resize-vertical
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-resize-horizontal
"></i> icon-resize-horizontal
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-bar-chart
"></i> icon-bar-chart
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-twitter-sign
"></i> icon-twitter-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-facebook-sign
"></i> icon-facebook-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-camera-retro
"></i> icon-camera-retro
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-key
"></i> icon-key
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-cogs
"></i> icon-cogs
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-comments
"></i> icon-comments
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-thumbs-up
"></i> icon-thumbs-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-thumbs-down
"></i> icon-thumbs-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-star-half
"></i> icon-star-half
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-heart-empty
"></i> icon-heart-empty
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-signout
"></i> icon-signout
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-linkedin-sign
"></i> icon-linkedin-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-pushpin
"></i> icon-pushpin
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-external-link
"></i> icon-external-link
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-signin
"></i> icon-signin
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-trophy
"></i> icon-trophy
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-github-sign
"></i> icon-github-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-upload-alt
"></i> icon-upload-alt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-lemon
"></i> icon-lemon
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-phone
"></i> icon-phone
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-check-empty
"></i> icon-check-empty
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-bookmark-empty
"></i> icon-bookmark-empty
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-phone-sign
"></i> icon-phone-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-twitter
"></i> icon-twitter
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-facebook
"></i> icon-facebook
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-github
"></i> icon-github
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-unlock
"></i> icon-unlock
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-credit-card
"></i> icon-credit-card
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-rss
"></i> icon-rss
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-hdd
"></i> icon-hdd
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-bullhorn
"></i> icon-bullhorn
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-bell
"></i> icon-bell
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-certificate
"></i> icon-certificate
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-hand-right
"></i> icon-hand-right
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-hand-left
"></i> icon-hand-left
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-hand-up
"></i> icon-hand-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-hand-down
"></i> icon-hand-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-circle-arrow-left
"></i> icon-circle-arrow-left
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-circle-arrow-right
"></i> icon-circle-arrow-right
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-circle-arrow-up
"></i> icon-circle-arrow-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-circle-arrow-down
"></i> icon-circle-arrow-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-globe
"></i> icon-globe
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-wrench
"></i> icon-wrench
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-tasks
"></i> icon-tasks
</li>
            
          </ul>
        </div>
    
        <div class="span3 MR0">
          <ul>
            
                <li style="line-height: 32px;"><i class="icon-large icon-filter
"></i> icon-filter
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-briefcase
"></i> icon-briefcase
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-fullscreen
"></i> icon-fullscreen
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-group
"></i> icon-group
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-link
"></i> icon-link
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-cloud
"></i> icon-cloud
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-beaker
"></i> icon-beaker
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-cut
"></i> icon-cut
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-copy
"></i> icon-copy
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-paper-clip
"></i> icon-paper-clip
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-save
"></i> icon-save
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-sign-blank
"></i> icon-sign-blank
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-reorder
"></i> icon-reorder
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-list-ul
"></i> icon-list-ul
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-list-ol
"></i> icon-list-ol
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-strikethrough
"></i> icon-strikethrough
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-underline
"></i> icon-underline
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-table
"></i> icon-table
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-magic
"></i> icon-magic
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-truck
"></i> icon-truck
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-pinterest
"></i> icon-pinterest
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-pinterest-sign
"></i> icon-pinterest-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-google-plus-sign
"></i> icon-google-plus-sign
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-google-plus
"></i> icon-google-plus
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-money
"></i> icon-money
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-caret-down
"></i> icon-caret-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-caret-up
"></i> icon-caret-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-caret-left
"></i> icon-caret-left
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-caret-right
"></i> icon-caret-right
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-columns
"></i> icon-columns
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-sort
"></i> icon-sort
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-sort-down
"></i> icon-sort-down
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-sort-up
"></i> icon-sort-up
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-envelope-alt
"></i> icon-envelope-alt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-linkedin
"></i> icon-linkedin
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-undo
"></i> icon-undo
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-legal
"></i> icon-legal
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-dashboard
"></i> icon-dashboard
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-comment-alt
"></i> icon-comment-alt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-comments-alt
"></i> icon-comments-alt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-bolt
"></i> icon-bolt
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-sitemap
"></i> icon-sitemap
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-umbrella
"></i> icon-umbrella
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-paste
"></i> icon-paste
</li>
            
                <li style="line-height: 32px;"><i class="icon-large icon-user-md
"></i> icon-user-md
</li>
            
          </ul>
        </div>
        
                            </div>
    </div>
      
    
  </div> <!-- /row -->
	
	    </div> <!-- /container -->
    
	</div> <!-- /main-inner -->
	    
</div> <!-- /main -->
    
<?php

 
    
include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';
      
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/footer_bottom.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/scripts.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/pagedata/index_data.php';


?>

<script>

$(function () {
	
	$('.faq-list').goFaq ();

});

</script>
  </body>

</html>