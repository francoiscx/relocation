 </div>
 <!--Footer Bottom-->
 
<div class="footer">

   <div class="footer-inner">

     <div class="container">
      <div class="row">
        <div class="span12">Copyright © <?php echo date("Y"); ?>

         <a href="http://wi-app.com/">Wi-APP</a> All rights reserved.
        <?php if ($notmobile != 101) {echo'<br><br><br>';
        }?>
         

         
         </div>
        <!-- /span12 --> 
      </div>
      <!-- /row -->
     </div>
    <!-- /container --> 
    
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer -->