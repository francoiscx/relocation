<?php
$Page = "Quick Start";
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/header.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/navbar_top.php';
?>

<!-- Navbar Tabs -->  
<div class="subnavbar">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li><a href="index.php"><i class="icon-book"></i><span>Connections</span></a></li><!--
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-long-arrow-down"></i><span>Drops</span><b class="caret"></b></a>
          <ul class="dropdown-menu">   
            <li><a href="icons.php">Icons</a></li>
          </ul>
        </li>-->
      </ul>
    </div><!-- /container --> 
  </div><!-- /subnavbar-inner --> 
</div><!-- /subnavbar -->

<div class="main">
	<div class="main-inner">
	    <div class="container">	
	      	<div class="row">	      	
	      		<div class="span12">      			      		
	      	 		<div class="widget ">	      							
		     			<div class="widget-content">
				
				<label> <h3><?php echo $Page; ?></h3></label>
		

<?php if($notmobile == 101) { echo '<div class="tabbable">
 	<ul id="nav" class="nav nav-tabs">
 		<li class="active"><a href="#quickStart" data-toggle="tab">Quick Start</a></li>
 	</ul></div>';
 		}?>

	<!------------------->
	
						<div class="tab-content">
<!--===================================================================================================================-->
							<div class="tab-pane active" id="quickStart">														
								<tab id="quickStart">													

<div class="accordion" id="accordion0">
	<div class="accordion-group">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion0" href="#collapseQuickStartInfo">About Me <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="collapseQuickStartInfo" class="accordion-body collapse in">
			<div class="accordion-inner">
			

<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/gc_my_general_info.php';
?>
					
			</div>
		</div>
	</div>
								</tab>
							</div>
						</div>	
<!--=======================================================================================================================-->								

<!--=======================================================================================================================-->		


							    </tab>
							</div>
						</div>	

<!--=======================================================================================================================-->
                        

	<!------------------->
		    			</div> <!-- /widget-content -->
		 		    </div> <!-- /widget -->
	      	 	</div> <!-- /span12 -->
	      	</div> <!-- /row -->
	    </div> <!-- /container -->
	</div> <!-- /main-inner -->
</div> <!-- /main -->


<?php if ($notmobile != 101) {
  echo '<div class="botnav">
<div class="botnav-group" style="width:100%">
  <button style="width: 99.9%; font-size:14px" a href="#quickStart" data-toggle="tab">Quick Start</button>
</div>
</div>';
}?>
 
<?php if ($notmobile == 101) include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/footer_bottom.php';?>
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/scripts.php';?>	