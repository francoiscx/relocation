<?php

echo "<!--Calander-->           \n";
echo "          <div class=\"widget widget-nopad\">\n";
echo "            <div class=\"widget-header\"> <i class=\"icon-list-alt\"></i>\n";
echo "              <h3> Recent News</h3>\n";
echo "            </div>\n";
echo "            <!-- /widget-header -->\n";
echo "            <div class=\"widget-content\">\n";
echo "              <div id='calendar'>\n";
echo "              </div>\n";
echo "            </div>\n";
echo "            <!-- /widget-content --> \n";
echo "          </div>\n";
echo "          <!-- /widget -->\n";
echo "          <div class=\"widget\">\n";
echo "            <div class=\"widget-header\"> <i class=\"icon-file\"></i>\n";
echo "              <h3> Content</h3>\n";
echo "            </div>\n";
echo "            <!-- /widget-header -->";

?>
