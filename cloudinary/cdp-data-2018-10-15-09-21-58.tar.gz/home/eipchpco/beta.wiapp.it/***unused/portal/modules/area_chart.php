<?php

echo "<!--Area Chart-->                     \n";
echo "          <!-- /widget -->\n";
echo "          <div class=\"widget\">\n";
echo "            <div class=\"widget-header\"> <i class=\"icon-signal\"></i>\n";
echo "              <h3> Area Chart Example</h3>\n";
echo "            </div>\n";
echo "            <!-- /widget-header -->\n";
echo "            <div class=\"widget-content\">\n";
echo "              <canvas id=\"area-chart\" class=\"chart-holder\" height=\"250\" width=\"538\"> </canvas>\n";
echo "              <!-- /area-chart --> \n";
echo "            </div>\n";
echo "            <!-- /widget-content --> \n";
echo "          </div>";

?>
