<?php
if(!isset($email) && ($_SESSION['email'])) $email = $_SESSSION['email'];
if(!isset($_POST['Email'])) $email = ($_POST['Email']);

?>



<div class="register">		
				<div class="field">
					<label for="Firstname">First Name:</label>
					<input type="text" id="Firstname" name="Firstname" value="<?php if(isset($_POST['Firstname'])){ echo htmlentities ($_POST['Firstname']); }?>" required placeholder="First Name" title="Please provide only your first name" class="register" />
				</div> <!-- /field -->
				
				<div class="field">
					<label for="Lastname">Last Name:</label>	
					<input type="text" id="Lastname" name="Lastname" value="<?php if(isset($_POST['Lastname'])){ echo htmlentities ($_POST['Lastname']); }?>" required placeholder="Last Name" title="Please provide only your last name" class="register" />
				</div> <!-- /field -->
				
				
				<div class="field">
					<label for="Email">Email Address:</label>
					<input type="Email" id="Email" name="Email" value="<?php if(isset($_POST['Email'])){ echo htmlentities ($_POST['Email']); }else if(isset($_SESSION['notRegistered'])){echo $_SESSION['notRegistered'];};?>" required placeholder="Email" class="register" onpaste="return false" title="Please provide your valid email" onkeyup="checkServer()" />
				</div> <!-- /field -->
				
				<div class="field">
					<label for="Email_Confirm">Confirm Email:</label>
					<input type="email" id="Email_Confirm" name="Email_Confirm" value="<?php if(isset($_POST['Email_Confirm'])){ echo htmlentities ($_POST['Email_Confirm']); }?>" required placeholder="Confirm Email" class="register" onpaste="return false" title="Please confirm your valid email" onblur="confirmEmail()"/>
				</div> <!-- /field -->
				
				<div class="field">
					<label for="Password">Password:</label>
					<input type="Password" id="Password" name="Password" pattern="^(?=(.*[a-zA-Z].*){2,})(?=.*\d.*)(?=.*\W.*)[a-zA-Z0-9\S]{7,36}$" title="Use a combination of at least 7 letters numbers and punctuation marks" value="" required placeholder="Password" class="register"/>
				<?php if ($notmobile != 101) echo"<center><div style='font-size:7px; color:#42266E'>(Use a combo of at least 7 letters numbers & punctuation marks)</div></center>";
				?>
				</div> <!-- /field -->	
	


			 <div class="field">     
			
			    <span class="login-checkbox">
				    <input id="Terms" name="Terms" type="checkbox" class="field login-checkbox" value="Accept" />
				        <label class="choice" for="Terms">I accept and agree to the <div id=terms><a href="terms_conditions.php" value="Accept"><br>Terms & Conditions.</a></div></label>
			</div> <!-- /field -->
		</div>
	</div>

									
				<input button type="submit" name="signupBtn" value="Register" class="button btn btn-primary btn-medium" style="margin-top:35px"></button>
				
</div register>
			
			
			
<script type="text/javascript">
    function confirmEmail() {
        var email = document.getElementById("Email").value
        var email_confirm = document.getElementById("Email_Confirm").value
            if (email_confirm.length != 0) {
                                if (email != email_confirm) { 
                                alert('Email Not Matching!');
                                }
                    }
    }
</script>			
			
			
			
			
			
			
			
			
		