
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /extra-inner -->
</div>
<!-- /extra -->


<!--Footer Top--> 
<div class="extra">
  <div class="extra-inner">
    <div class="container">
      <div class="row">
                    <div class="span3">
                        <h4>About Wi-APP</h4>
                        <ul>
                            <li><a href="#">Wi-Card</a></li>
                            <li><a href="#">Wi-Ads</a></li>
                            <li><a href="#">Wi-Report</a></li>
                            <li><a href="#">Wi-Mall</a></li>
                            <li><a href="#">Wi-Shop</a></li>
                            <li><a href="#">Wi-Pay</a></li>
                        </ul>
                    </div>
                    <!-- /span3 -->
                    <div class="span3">
                        <h4>
                            Support</h4>
                        <ul>
                            <li><a href="#">Frequently Asked Questions</a></li>
                            <li><a href="#">Ask a Question</a></li>
                            <li><a href="#">Video Tutorial</a></li>
                            <li><a href="#">Feedback</a></li>
                        </ul>
                    </div>
                    <!-- /span3 -->
                    <div class="span3">
                        <h4>
                            Something Legal</h4>
                        <ul>
                            <li><a href="#">Read License</a></li>
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                        </ul>
                    </div>
                    <!-- /span3 -->
                    <div class=\"span3\">
                        <h4>
                            Employ our Services</h4>
                        <ul>
                            <li><a href="http://www.wi-app.com">Wi-ADS | Vehicles</a></li>
                            <li><a href="http://www.wi-app.com">Wi-ADS | Billboards</a></li>
                            <li><a href="http://www.wi-app.com">Wi-ADS | Lampposts</a></li>
                            <li><a href="http://www.wi-app.com">Wi-ADS | Bus Stops & Dustbins</a></li>
                        </ul>
                    </div>
                    <!-- /span3 -->
                </div>



    </div>
    <!-- /container -->
  </div>
  <!-- /footer-inner -->
