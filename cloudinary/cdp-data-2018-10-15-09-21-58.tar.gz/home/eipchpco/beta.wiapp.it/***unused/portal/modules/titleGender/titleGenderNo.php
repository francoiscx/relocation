 
    <div class="control-group">
  <label style="font-size:13px" for="dob-day" class="control-label">Gender</label>
  <div class="controls">

    <select name="gender" id="gender" type="text" required>
      <option value="">Gender</option>
      <option value="Male">Male</option>
      <option value="Female">Female</option>
    </select>
   
  </div>