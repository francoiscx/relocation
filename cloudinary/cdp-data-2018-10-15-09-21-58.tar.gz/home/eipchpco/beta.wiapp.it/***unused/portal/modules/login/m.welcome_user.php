<?php require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';?>

<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    $redirect = "'/portal/m.signup.php'";
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    $redirect = "'/portal/m.signup.php'";

    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    $redirect = "'/portal/m.signup.php'";

    }
else if (Detect::isComputer()) {//browser reported as tablet device -- do something here
    //echo 'Computer';
    $notmobile = 101;
    $redirect = "'/portal/login.php'";


}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    $redirect = "'/portal/m.signup.php'";
    
}

?>


<?php
//add database connection scripts
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

    $email = $_POST['Email'];
    $email = strtolower($email);
    
    //check
    if(denyDuplicate($email, $db)){
        
        
//check if user exist in database
	$sqlQuery = "SELECT * FROM users WHERE email = :Email";
	$statement = $db->prepare($sqlQuery);
	$statement->execute(array(':Email' => $email));
	
	
	while($row = $statement->fetch()){
		$id = $row['id'];
		$first_name = $row['first_name'];
		$user_email = $row['email'];
		
	}
	
	echo "<p style='color: #381D62; border solid gray;'> Hi " . $first_name . "! Welcome back.</p>";
        }else{  
	echo "<p style='color: #381D62!important; float:left'><u>" . $email . "</u></p><p style='float:right'> &nbspis not registered on Wi-APP. Please fix the typo or <a href=$redirect'>Register </a>a new acccount.</p>";
	$_SESSION['notRegistered'] = $email;
	}
	
?>







	                