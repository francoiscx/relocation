<!DOCTYPE HTML>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta content='width=device-width, maximum-scale=1.0, user-scalable=0' name='viewport'>
  <link rel="stylesheet" href="/portal/css/bootstrap-3.3.7.min.css">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <link href="https://file.myfontastic.com/KKqgH4SYhM9ooPCkVerp8m/icons.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

<?php
$Page = "Welcome to Wi-APP";
?>


<title>Wi-APP <?php if(isset($Page)) echo " | ";?> <?php echo $Page; ?></title> 


<?php require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';?>
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php' ?>
<?php if(!isset($_SESSION['id'])) header("location:/logout.php");?>
<?php if(isset($_SESSION['defaultVerification'])) header("location:/portal/connections.php");?>



<!--Home Screen Buttons-->
<link rel="shortcut icon" href="/portal/img/tiles/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" sizes="57x57" href="/portal/img/tiles/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/portal/img/tiles/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/portal/img/tiles/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/portal/img/tiles/apple-icon-76x76.png"> 
<link rel="apple-touch-icon" sizes="114x114" href="/portal/img/tiles/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/portal/img/tiles/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/portal/img/tiles/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/portal/img/tiles/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/portal/img/tiles/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="/portal/img/tiles/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/portal/img/tiles/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/portal/img/tiles/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/portal/img/tiles/favicon-16x16.png">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/portal/img/tiles/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff"><link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
<!-- <link href="/portal/css/font-awesome-4.1.0.min.css" rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet"> -->

<?php function is_bot($user_agent) {
 
    $botRegexPattern = "(googlebot\/|Googlebot\-Mobile|Googlebot\-Image|Google favicon|Mediapartners\-Google|bingbot|slurp|java|wget|curl|Commons\-HttpClient|Python\-urllib|libwww|httpunit|nutch|phpcrawl|msnbot|jyxobot|FAST\-WebCrawler|FAST Enterprise Crawler|biglotron|teoma|convera|seekbot|gigablast|exabot|ngbot|ia_archiver|GingerCrawler|webmon |httrack|webcrawler|grub\.org|UsineNouvelleCrawler|antibot|netresearchserver|speedy|fluffy|bibnum\.bnf|findlink|msrbot|panscient|yacybot|AISearchBot|IOI|ips\-agent|tagoobot|MJ12bot|dotbot|woriobot|yanga|buzzbot|mlbot|yandexbot|purebot|Linguee Bot|Voyager|CyberPatrol|voilabot|baiduspider|citeseerxbot|spbot|twengabot|postrank|turnitinbot|scribdbot|page2rss|sitebot|linkdex|Adidxbot|blekkobot|ezooms|dotbot|Mail\.RU_Bot|discobot|heritrix|findthatfile|europarchive\.org|NerdByNature\.Bot|sistrix crawler|ahrefsbot|Aboundex|domaincrawler|wbsearchbot|summify|ccbot|edisterbot|seznambot|ec2linkfinder|gslfbot|aihitbot|intelium_bot|facebookexternalhit|yeti|RetrevoPageAnalyzer|lb\-spider|sogou|lssbot|careerbot|wotbox|wocbot|ichiro|DuckDuckBot|lssrocketcrawler|drupact|webcompanycrawler|acoonbot|openindexspider|gnam gnam spider|web\-archive\-net\.com\.bot|backlinkcrawler|coccoc|integromedb|content crawler spider|toplistbot|seokicks\-robot|it2media\-domain\-crawler|ip\-web\-crawler\.com|siteexplorer\.info|elisabot|proximic|changedetection|blexbot|arabot|WeSEE:Search|niki\-bot|CrystalSemanticsBot|rogerbot|360Spider|psbot|InterfaxScanBot|Lipperhey SEO Service|CC Metadata Scaper|g00g1e\.net|GrapeshotCrawler|urlappendbot|brainobot|fr\-crawler|binlar|SimpleCrawler|Livelapbot|Twitterbot|cXensebot|smtbot|bnf\.fr_bot|A6\-Indexer|ADmantX|Facebot|Twitterbot|OrangeBot|memorybot|AdvBot|MegaIndex|SemanticScholarBot|ltx71|nerdybot|xovibot|BUbiNG|Qwantify|archive\.org_bot|Applebot|TweetmemeBot|crawler4j|findxbot|SemrushBot|yoozBot|lipperhey|y!j\-asr|Domain Re\-Animator Bot|AddThis)";
    return preg_match("/{$botRegexPattern}/", $user_agent);
 
}

   
   $geoplugin = unserialize( file_get_contents('http://www.geoplugin.net/php.gp?ip=' . $_SERVER['REMOTE_ADDR']) );
   $ipcountryCode = ($geoplugin['geoplugin_countryCode']);
   $ipcountry = ($geoplugin['geoplugin_countryName']);
   $ipregionCode = ($geoplugin['geoplugin_regionCode']);
   $ipregion = ($geoplugin['geoplugin_regionName']);
   $ipcity = ($geoplugin['geoplugin_city']);
   $ipcurrencyCode = ($geoplugin['geoplugin_currencyCode']);
   $ipcurrency = ($geoplugin['geoplugin_currencySymbol']);
   $ipcurrencySymbol = ($geoplugin['geoplugin_currencySymbol_UTF8']);
   $ipcurrencyConversion = ($geoplugin['geoplugin_currencyConverter']);
   
   $_SESSION['ipcountryCode'] = $ipcountryCode;
   $_SESSION['ipcountry'] = $ipcountry;
   $_SESSION['ipregionCode'] = $ipregionCode;
   $_SESSION['ipregion'] = $ipregion;
   $_SESSION['ipcity'] = $ipcity;
   $_SESSION['ipcurrencyCode'] = $ipcurrencyCode;
   $_SESSION['ipcurrency'] = $ipcurrency;
   $_SESSION['ipcurrencySymbol'] = $ipcurrencySymbol;
   $_SESSION['ipcurrencyConversion'] = $ipcurrencyConversion;
 
//  echo  $user_agent;
//  echo  $ipcountryCode;
//  echo  $ipcountry;
//  echo  $ipregionCode;
//  echo  $ipregion;
//  echo  $ipcity;
//  echo  $ipcurrencyCode;
//  echo  $ipcurrencySymbol;
//  echo  $ipcurrency;
//  echo  $ipcurrencyConversion;
?>



<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    echo '<link href="/portal/css/bootstrapi.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivei.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylei.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitchi.css" rel="stylesheet">';
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    echo '<link href="/portal/css/bootstrapa.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivea.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylea.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitcha.css" rel="stylesheet">';
    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    echo '<link href="/portal/css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivem.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylem.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitchm.css" rel="stylesheet">';
    }
else if (Detect::isComputer()) {
    $notmobile = 101;
    //echo 'Computer';
    echo '<link href="/portal/css/bootstrap.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsive.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/style.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitch.css" rel="stylesheet">';
}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    echo '<link href="/portal/css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivem.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylem.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitchm.css" rel="stylesheet">';
    
}

?>

    <![endif]-->
</head>


<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/navbar_top.php';
?>


<name="dob_day" id="dob_day">
<name="dob_month" id="dob_month">
<name="dob_year" id="dob_year">
<name="gender" id="gender">
<name="city" id="city">
<name="province" id="province">
<name="country" id="country">


<div class="main">
	<div class="main-inner">
	    <div class="container">	
	      	<div class="row">	      	
	      		<div class="span12">      			      		
				<div class="widget ">	      							
					<div class="widget-content" style="min-height:750px;">
					<h3>Dear <?php echo $_SESSION['firstname']; ?></h3>
		<div class="col-sm-7">
					<p>Welcome to Wi-APP and thank you for joining us on our journey.<br>
					As you might know, Wi-APP aims at improving the experience of making someone&apos;s acquaintance in both social and professional settings.<br><br>
					There is just a few things we want to confirm before we get started.<br>
					
<em>Please note that none of the following information will ever be made available by Wi-APP unless you expressly share it with someone.</em></p>
        </div>
        <div class="col-sm-12">
<form action="/portal/page/profile/account/mc/gl/data/func_defaultValidation.php" method="post" class="ajax">
    

    
    
    
<!--===================================================================================================================-->
<div class="accordion" id="accordion2">
	<div class="accordion-group">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">What is your gender?</a>
		</div>
		<div id="collapseTwo" class="accordion-body collapse in">
			<div class="accordion-inner">	
				
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/modules/titleGender/titleGenderNo.php';?>
				
			</div>	
		</div>
	</div>
</div>
<!--===================================================================================================================-->
    <div class="accordion-group">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">Do you live here?</a>
		</div>
		<div id="collapseThree" class="accordion-body collapse in">
			<div class="accordion-inner">

    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/modules/live/live.php';
    ?>				

	            </div>
	        </div>	
		</div>
	</div>
<!--===================================================================================================================-->
	<div class="accordion-group">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">When were you born?</a>
		</div>
		<div id="collapseOne" class="accordion-body collapse in">
			<div class="accordion-inner">

    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/modules/dob/dobN.php';
    ?>

		</div>
            <div class="accordion-group">
        		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOneTwo" style="color:#625280">Why we require your date of birth</a>
        		</div>
        		<div id="collapseOneTwo" class="accordion-body collapse">
        			<div class="accordion-inner">
                        <p>Wi-APP requires everyone to be at least 13 years old before they can create an account (in some jurisdictions, this age limit may be higher).<br><br> Creating an account with false info is a violation of our terms. This includes accounts registered on the behalf of someone under 13.
                        If your underage child created an account on Wi-APP, you can show them how to delete their account.
                        If you&apos;d like to report an account belonging to someone under 13, please fill out this form. Note that we&apos;ll promptly delete the account of any child under the age of 13 that&apos;s reported to us through this form.</p>
                    </div>
            	</div>
            </div>
        </div>
    </div>
<!--===================================================================================================================-->
	<div class="accordion-group">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseContact">Cell</a>
		</div>
		<div id="collapseContact" class="accordion-body collapse in">
			<div class="accordion-inner">
	<?php include_once '/home/eipchpco/beta.wiapp.it/portal/modules/contact/contact.php';
?>	
            </div>
		</div>
	</div>

<!--===================================================================================================================-->	

				<div class="col-sm-12">
					<div class="groupBtn">
       						<input type="submit" value="Save" class="button btn btn-primary btn-medium" float="right">	
					</div>
       			<div class="space"></div><div class="space"></div>
			</div>	
	    </div>
    </div>

</form>	
					


	<!------------------->
	
	

	
	
		    			</div> <!-- /widget-content -->
		 		 </div> <!-- /widget -->
	      	 	</div> <!-- /span12 -->
	      	</div> <!-- /row -->
	    </div> <!-- /container -->
	</div> <!-- /main-inner -->
</div> <!-- /main -->





    
 
<?php if ($notmobile == 101) include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';?>
      
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/footer_bottom.php';?>

<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/scripts.php';?>	


                                                          

                                                    
                                                      
                                                      
                         