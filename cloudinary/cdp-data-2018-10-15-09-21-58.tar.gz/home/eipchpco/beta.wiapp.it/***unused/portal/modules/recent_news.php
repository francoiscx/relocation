<?php

echo "<!--Recent News-->         \n";
echo "          <!-- /widget --> \n";
echo "          <div class=\"widget widget-nopad\">\n";
echo "            <div class=\"widget-header\"> <i class=\"icon-list-alt\"></i>\n";
echo "              <h3> Recent News</h3>\n";
echo "            </div>\n";
echo "            <!-- /widget-header -->\n";
echo "            <div class=\"widget-content\">\n";
echo "              <ul class=\"news-items\">\n";
echo "                <li>\n";
echo "                  \n";
echo "                  <div class=\"news-item-date\"> <span class=\"news-item-day\">29</span> <span class=\"news-item-month\">Aug</span> </div>\n";
echo "                  <div class=\"news-item-detail\"> <a href=\"http://www.wi-app.com\" class=\"news-item-title\" target=\"_blank\">Thursday Roundup # 40</a>\n";
echo "                    <p class=\"news-item-preview\"> This is our web design and development news series where we share our favorite design/development related articles, resources, tutorials and awesome freebies. </p>\n";
echo "                  </div>\n";
echo "                  \n";
echo "                </li>\n";
echo "                <li>\n";
echo "                  \n";
echo "                  <div class=\"news-item-date\"> <span class=\"news-item-day\">15</span> <span class=\"news-item-month\">Jun</span> </div>\n";
echo "                  <div class=\"news-item-detail\"> <a href=\"http://www.wi-app.com\" class=\"news-item-title\" target=\"_blank\">Retina Ready Responsive App Landing Page Website Template – App Landing</a>\n";
echo "                    <p class=\"news-item-preview\"> App Landing is a retina ready responsive app landing page website template perfect for software and application developers and small business owners looking to promote their iPhone, iPad, Android Apps and software products.</p>\n";
echo "                  </div>\n";
echo "                  \n";
echo "                </li>\n";
echo "                <li>\n";
echo "                  \n";
echo "                  <div class=\"news-item-date\"> <span class=\"news-item-day\">29</span> <span class=\"news-item-month\">Oct</span> </div>\n";
echo "                  <div class=\"news-item-detail\"> <a href=\"http://www.wi-app.com\" class=\"news-item-title\" target=\"_blank\">Open Source jQuery PHP Ajax Contact Form Templates With Captcha: Formify</a>\n";
echo "                    <p class=\"news-item-preview\"> Formify is a contribution to lessen the pain of creating contact forms. The collection contains six different forms that are commonly used. These open source contact forms can be customized as well to suit the need for your website/application.</p>\n";
echo "                  </div>\n";
echo "                  \n";
echo "                </li>\n";
echo "              </ul>\n";
echo "            </div>\n";
echo "            <!-- /widget-content --> \n";

?>
