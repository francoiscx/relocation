<?php

//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';


//process the form 
if(isset($_POST['signupBtn'])){
    //initialize an array to store any error message from the form
    $form_errors = array();
    
    //Form validation
    $required_fields = array('Firstname', 'Lastname', 'REmail', 'REmail_Confirm', 'Password' );

    //call the function to check empty field and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_empty_fields($required_fields));
  
    
    //Form validation
    $required = array('Terms');

    //call the function to check terms
    $form_errors = array_merge($form_errors, check_if_empty($required));


    //Fields that requires checking for minimum length
    $fields_to_check_length = array('Password' => 7);
    
    //Call the function to check minimum required length and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_min_length($fields_to_check_length));
    
    //email validation / merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_email($_POST));

    	//collect form data
    	$first_name = $_POST['Firstname'];
    	$last_name = $_POST['Lastname'];
    	$email = $_POST['REmail'];
    	$email_confirm = $_POST['REmail_Confirm'];
    	$password = $_POST['Password'];
  //  	$dob_day = $_POST['dob_day'];
  //  	$dob_month = $_POST['dob_month'];
  //  	$dob_year = $_POST['dob_year'];
    	$terms = $_POST['Terms'];
    	
  //		$dob = $_POST['dob_month'].'/'.$_POST['dob_day'].'/'.$_POST['dob_year'];

		//Fields to change Case to Name
		$first_name = name_field($first_name);
		$last_name = name_field($last_name);
		$email = strtolower($email);

	if(denyDuplicate($email, $db)){
	$_SESSION['email'] = $email;
	$result = report("That email is already in use; <br>You might want to try to <a href='/portal/login.php'>Login</a>");
	}
	//Check if errors is empty
    	else if(empty($form_errors)){

   // Hash password
   $hashed_password = password_hash($password, PASSWORD_DEFAULT); 

        try{

            //create SQL insert statement
            $sqlInsert = "INSERT INTO users (email, first_name, last_name, password, dob, terms, ip, registration_date)
              VALUES (:Email, :Firstname, :Lastname, :Password, :dob, :Terms, '(" . $_SERVER['REMOTE_ADDR'] . ")', now())";

            //use PDO prepared to sanitize data
            $statement = $db->prepare($sqlInsert);

            //add the data into the database
            $statement->execute(array(':Email' => $email, ':Firstname' => $first_name, ':Lastname' => $last_name, ':Password' => $hashed_password, ':dob' => $dob, ':Terms' => $terms));

            //check if one new row was created
            if($statement->rowCount() == 1){
                $result = "<p style='padding:20px; border: 1px solid gray; color: #381A64;'> <b>Welcome to Wi-APP $firstName!</b> <br><br>Please confirm your email address before attempting to Log In!</p>";      
            include_once '/home/eipchpco/beta.wiapp.it/portal/inc/signup_notification.php';
            }
            
            
        //check if one new row was created
		if($statement->rowCount() == 1){
			$result = report("Registration successfull", "Pass");
			$registered = 1 ;
			$_SESSION['new'] = 1;
		}
			
	}catch (PDOException $ex){
	    		$result = report("An error occured: ".$ex->getMessage());

	}
}else{
	if(count($form_errors) == 1){
	   $result = report("There was 1 error in the form<br>".$ex->getMessage(), "Fail");
	   
    }else{
	   $result = report("There were " .count($form_errors). " errors in the form <br>");

	  }
	  
	    
	}
  
}

?>