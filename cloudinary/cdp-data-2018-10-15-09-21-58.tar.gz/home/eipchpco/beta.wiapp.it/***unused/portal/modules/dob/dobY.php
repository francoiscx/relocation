
	<label style="font-size:13px">Date of Birth</label>
	<input id="dob" name="dob" name="Date of Birth" value="<?php echo $_SESSION['dob']; ?>" disabled>	
	


