<?php

switch ($ipcountryCode) {
    case "AF":
        $areaCode = "+93";
        break;
        	
    case "AX":
        $areaCode = "+";
        break;
        	
    case "AL":
        $areaCode = "+355";
        break;
        	
    case "DZ":
        $areaCode = "+213";
        break;
        	
    case "AS":
        $areaCode = "+1";
        break;
        	
    case "AD":
        $areaCode = "+376";
        break;
        	
    case "AO":
        $areaCode = "+244";
        break;
        	
    case "AI":
        $areaCode = "+1";
        break;
        	
    case "AQ":
        $areaCode = "+";
        break;
        	
    case "AG":
        $areaCode = "+1";
        break;
        	
    case "AR":
        $areaCode = "+54";
        break;
        	
    case "AM":
        $areaCode = "+374";
        break;
        	
    case "AW":
        $areaCode = "+297";
        break;
        	
    case "AU":
        $areaCode = "+61";
        break;
        	
    case "AT":
        $areaCode = "+43";
        break;
        	
    case "AZ":
        $areaCode = "+994";
        break;
        	
    case "BS":
        $areaCode = "+1";
        break;
        	
    case "BH":
        $areaCode = "+973";
        break;
        	
    case "BD":
        $areaCode = "+880";
        break;
        	
    case "BB":
        $areaCode = "+1";
        break;
        	
    case "BY":
        $areaCode = "+375";
        break;
        	
    case "BE":
        $areaCode = "+32";
        break;
        	
    case "BZ":
        $areaCode = "+501";
        break;
        	
    case "BJ":
        $areaCode = "+229";
        break;
        	
    case "BM":
        $areaCode = "+1";
        break;
        	
    case "BT":
        $areaCode = "+975";
        break;
        	
    case "BO":
        $areaCode = "+591";
        break;
        	
    case "BA":
        $areaCode = "+387";
        break;
        	
    case "BW":
        $areaCode = "+267";
        break;
        	
    case "BV":
        $areaCode = "+";
        break;
        	
    case "BR":
        $areaCode = "+55";
        break;
        	
    case "VG":
        $areaCode = "+";
        break;
        	
    case "IO":
        $areaCode = "+1";
        break;
        	
    case "BN":
        $areaCode = "+673";
        break;
        	
    case "BG":
        $areaCode = "+359";
        break;
        	
    case "BF":
        $areaCode = "+226";
        break;
        	
    case "BI":
        $areaCode = "+257";
        break;
        	
    case "KH":
        $areaCode = "+855";
        break;
        	
    case "CM":
        $areaCode = "+237";
        break;
        	
    case "CA":
        $areaCode = "+1";
        break;
        	
    case "CV":
        $areaCode = "+238";
        break;
        	
    case "KY":
        $areaCode = "+1";
        break;
        	
    case "CF":
        $areaCode = "+236";
        break;
        	
    case "TD":
        $areaCode = "+235";
        break;
        	
    case "CL":
        $areaCode = "+56";
        break;
        	
    case "CN":
        $areaCode = "+86";
        break;
        	
    case "HK":
        $areaCode = "+61";
        break;
        	
    case "MO":
        $areaCode = "+61";
        break;
        	
    case "CX":
        $areaCode = "+57";
        break;
        	
    case "CC":
        $areaCode = "+269";
        break;
        	
    case "CO":
        $areaCode = "+242";
        break;
        	
    case "KM":
        $areaCode = "+243";
        break;
        	
    case "CG":
        $areaCode = "+682";
        break;
        	
    case "CD":
        $areaCode = "+506";
        break;
        	
    case "CK":
        $areaCode = "+225";
        break;
        	
    case "CR":
        $areaCode = "+385";
        break;
        	
    case "CI":
        $areaCode = "+53";
        break;
        	
    case "HR":
        $areaCode = "+357";
        break;
        	
    case "CU":
        $areaCode = "+420";
        break;
        	
    case "CY":
        $areaCode = "+45";
        break;
        	
    case "CZ":
        $areaCode = "+253";
        break;
        	
    case "DK":
        $areaCode = "+1";
        break;
        	
    case "DJ":
        $areaCode = "+1";
        break;
        	
    case "DM":
        $areaCode = "+593";
        break;
        	
    case "DO":
        $areaCode = "+20";
        break;
        	
    case "EC":
        $areaCode = "+503";
        break;
        	
    case "EG":
        $areaCode = "+240";
        break;
        	
    case "SV":
        $areaCode = "+291";
        break;
        	
    case "GQ":
        $areaCode = "+372";
        break;
        	
    case "ER":
        $areaCode = "+251";
        break;
        	
    case "EE":
        $areaCode = "+500";
        break;
        	
    case "ET":
        $areaCode = "+298";
        break;
        	
    case "FK":
        $areaCode = "+679";
        break;
        	
    case "FO":
        $areaCode = "+358";
        break;
        	
    case "FJ":
        $areaCode = "+33";
        break;
        	
    case "FI":
        $areaCode = "+594";
        break;
        	
    case "FR":
        $areaCode = "+689";
        break;
        	
    case "GF":
        $areaCode = "+";
        break;
        	
    case "PF":
        $areaCode = "+241";
        break;
        	
    case "TF":
        $areaCode = "+220";
        break;
        	
    case "GA":
        $areaCode = "+995";
        break;
        	
    case "GM":
        $areaCode = "+49";
        break;
        	
    case "GE":
        $areaCode = "+233";
        break;
        	
    case "DE":
        $areaCode = "+350";
        break;
        	
    case "GH":
        $areaCode = "+30";
        break;
        	
    case "GI":
        $areaCode = "+299";
        break;
        	
    case "GR":
        $areaCode = "+1";
        break;
        	
    case "GL":
        $areaCode = "+590";
        break;
        	
    case "GD":
        $areaCode = "+1";
        break;
        	
    case "GP":
        $areaCode = "+502";
        break;
        	
    case "GU":
        $areaCode = "+";
        break;
        	
    case "GT":
        $areaCode = "+224";
        break;
        	
    case "GG":
        $areaCode = "+245";
        break;
        	
    case "GN":
        $areaCode = "+592";
        break;
        	
    case "GW":
        $areaCode = "+509";
        break;
        	
    case "GY":
        $areaCode = "+";
        break;
        	
    case "HT":
        $areaCode = "+379";
        break;
        	
    case "HM":
        $areaCode = "+504";
        break;
        	
    case "VA":
        $areaCode = "+852";
        break;
        	
    case "HN":
        $areaCode = "+36";
        break;
        	
    case "HU":
        $areaCode = "+354";
        break;
        	 
    case "IS":
        $areaCode = "+91";
        break; 
        	
    case "IN":
        $areaCode = "+62";
        break;
        	
    case "ID":
        $areaCode = "+98";
        break;
        	
    case "IR":
        $areaCode = "+964";
        break;
        	
    case "IQ":
        $areaCode = "+353";
        break;
        	
    case "IE":
        $areaCode = "+";
        break;
        	
    case "IM":
        $areaCode = "+972";
        break;
        	
    case "IL":
        $areaCode = "+39";
        break;
        	
    case "IT":
        $areaCode = "+1";
        break;
        	
    case "JM":
        $areaCode = "+81";
        break;
        	
    case "JP":
        $areaCode = "+";
        break;
        	
    case "JE":
        $areaCode = "+962";
        break;
        	
    case "JO":
        $areaCode = "+7";
        break;
        	
    case "KZ":
        $areaCode = "+254";
        break;
        	
    case "KE":
        $areaCode = "+686";
        break;
        	
    case "KI":
        $areaCode = "+580";
        break;
        	
    case "KP":
        $areaCode = "+82";
        break;
        	
    case "KR":
        $areaCode = "+965";
        break;
        	
    case "KW":
        $areaCode = "+996";
        break;
        	
    case "KG":
        $areaCode = "+856";
        break;
        	
    case "LA":
        $areaCode = "+371";
        break;
        	
    case "LV":
        $areaCode = "+961";
        break;
        	
    case "LB":
        $areaCode = "+266";
        break;
        	
    case "LS":
        $areaCode = "+231";
        break;
        	
    case "LR":
        $areaCode = "+218";
        break;
        	
    case "LY":
        $areaCode = "+423";
        break;
        	
    case "LI":
        $areaCode = "+370";
        break;
        	
    case "LT":
        $areaCode = "+352";
        break;
        	
    case "LU":
        $areaCode = "+853";
        break;
        	
    case "MK":
        $areaCode = "+389";
        break;
        	
    case "MG":
        $areaCode = "+261";
        break;
        	
    case "MW":
        $areaCode = "+265";
        break;
        	
    case "MY":
        $areaCode = "+60";
        break;
        	
    case "MV":
        $areaCode = "+960";
        break;
        	
    case "ML":
        $areaCode = "+223";
        break;
        	
    case "MT":
        $areaCode = "+356";
        break;
        	
    case "MH":
        $areaCode = "+692";
        break;
        	
    case "MQ":
        $areaCode = "+596";
        break;
        	
    case "MR":
        $areaCode = "+222";
        break;
        	
    case "MU":
        $areaCode = "+230";
        break;
        	
    case "YT":
        $areaCode = "+262";
        break;
        	
    case "MX":
        $areaCode = "+52";
        break;
        	
    case "FM":
        $areaCode = "+691";
        break;
        	
    case "MD":
        $areaCode = "+373";
        break;
        	
    case "MC":
        $areaCode = "+377";
        break;
        	
    case "MN":
        $areaCode = "+976";
        break;
        	
    case "ME":
        $areaCode = "+382";
        break;
        	
    case "MS":
        $areaCode = "+1";
        break;
        	
    case "MA":
        $areaCode = "+212";
        break;
        	
    case "MZ":
        $areaCode = "+258";
        break;
        	
    case "MM":
        $areaCode = "+95";
        break;
        	
    case "NA":
        $areaCode = "+264";
        break;
        	
    case "NR":
        $areaCode = "+674";
        break;
        	
    case "NP":
        $areaCode = "+977";
        break;
        	
    case "NL":
        $areaCode = "+31";
        break;
        	
    case "AN":
        $areaCode = "+599";
        break;
        	
    case "NC":
        $areaCode = "+687";
        break;
        	
    case "NZ":
        $areaCode = "+64";
        break;
        	
    case "NI":
        $areaCode = "+505";
        break;
        	
    case "NE":
        $areaCode = "+227";
        break;
        	
    case "NG":
        $areaCode = "+234";
        break;
        	
    case "NU":
        $areaCode = "+683";
        break;
        	
    case "NF":
        $areaCode = "+672";
        break;
        	
    case "MP":
        $areaCode = "+1";
        break;
        	
    case "NO":
        $areaCode = "+47";
        break;
        	
    case "OM":
        $areaCode = "+968";
        break;
        	
    case "PK":
        $areaCode = "+92";
        break;
        	
    case "PW":
        $areaCode = "+680";
        break;
        	
    case "PS":
        $areaCode = "+970";
        break;
        	
    case "PA":
        $areaCode = "+507";
        break;
        	
    case "PG":
        $areaCode = "+675";
        break;
        	
    case "PY":
        $areaCode = "+595";
        break;
        	
    case "PE":
        $areaCode = "+51";
        break;
        	
    case "PH":
        $areaCode = "+63";
        break;
        	
    case "PN":
        $areaCode = "+870";
        break;
        	
    case "PL":
        $areaCode = "+48";
        break;
        	
    case "PT":
        $areaCode = "+351";
        break;
        	
    case "PR":
        $areaCode = "+1";
        break;
        	
    case "QA":
        $areaCode = "+974";
        break;
        	
    case "RE":
        $areaCode = "+262";
        break;
        	
    case "RO":
        $areaCode = "+40";
        break;
        	
    case "RU":
        $areaCode = "+7";
        break;
        	
    case "RW":
        $areaCode = "+250";
        break;
        	
    case "BL":
        $areaCode = "+";
        break;
        	
    case "SH":
        $areaCode = "+290";
        break;
        	
    case "KN":
        $areaCode = "+1";
        break;
        	
    case "LC":
        $areaCode = "+1";
        break;
        	
    case "MF":
        $areaCode = "+";
        break;
        	
    case "PM":
        $areaCode = "+508";
        break;
        	
    case "VC":
        $areaCode = "+1";
        break;
        	
    case "WS":
        $areaCode = "+685";
        break;
        	
    case "SM":
        $areaCode = "+378";
        break;
        	
    case "ST":
        $areaCode = "+239";
        break;
        	
    case "SA":
        $areaCode = "+966";
        break;
        	
    case "SN":
        $areaCode = "+221";
        break;
        	
    case "RS":
        $areaCode = "+381";
        break;
        	
    case "SC":
        $areaCode = "+248";
        break;
        	
    case "SL":
        $areaCode = "+232";
        break;
        	
    case "SG":
        $areaCode = "+65";
        break;
        	
    case "SK":
        $areaCode = "+421";
        break;
        	
    case "SI":
        $areaCode = "+386";
        break;
        	
    case "SB":
        $areaCode = "+677";
        break;
        	
    case "SO":
        $areaCode = "+252";
        break;
        	
    case "ZA":
        $areaCode = "+27";
        break;
        	
    case "GS":
        $areaCode = "+34";
        break;
        	
    case "SS":
        $areaCode = "+";
        break;
        	
    case "ES":
        $areaCode = "+34";
        break;
        	
    case "LK":
        $areaCode = "+94";
        break;
        	
    case "SD":
        $areaCode = "+249";
        break;
        	
    case "SR":
        $areaCode = "+597";
        break;
        	
    case "SJ":
        $areaCode = "+47";
        break;
        	
    case "SZ":
        $areaCode = "+268";
        break;
        	
    case "SE":
        $areaCode = "+46";
        break;
        	
    case "CH":
        $areaCode = "+41";
        break;
        	
    case "SY":
        $areaCode = "+963";
        break;
        	
    case "TW":
        $areaCode = "+886";
        break;
        	
    case "TJ":
        $areaCode = "+992";
        break;
        	
    case "TZ":
        $areaCode = "+255";
        break;
        	
    case "TH":
        $areaCode = "+66";
        break;
        	
    case "TL":
        $areaCode = "+670";
        break;
        	
    case "TG":
        $areaCode = "+228";
        break;
        	
    case "TK":
        $areaCode = "+690";
        break;
        	
    case "TO":
        $areaCode = "+676";
        break;
        	
    case "TT":
        $areaCode = "+1";
        break;
        	
    case "TN":
        $areaCode = "+216";
        break;
        	
    case "TR":
        $areaCode = "+90";
        break;
        	
    case "TM":
        $areaCode = "+993";
        break;
        	
    case "TC":
        $areaCode = "+1";
        break;
        	
    case "TV":
        $areaCode = "+688";
        break;
        	
    case "UG":
        $areaCode = "+256";
        break;
        	
    case "UA":
        $areaCode = "+380";
        break;
        	
    case "AE":
        $areaCode = "+971";
        break;
        	
    case "GB":
        $areaCode = "+44";
        break;
        	
    case "US":
        $areaCode = "+1";
        break;
        	
    case "UM":
        $areaCode = "+598";
        break;
        	
    case "UY":
        $areaCode = "+";
        break;
        	
    case "UZ":
        $areaCode = "+998";
        break;
        	
    case "VU":
        $areaCode = "+678";
        break;
        	
    case "VE":
        $areaCode = "+58";
        break;
        	
    case "VN":
        $areaCode = "+84";
        break;
        	
    case "VI":
        $areaCode = "+1";
        break;
        	
    case "WF":
        $areaCode = "+681";
        break;
        	
    case "EH":
        $areaCode = "+";
        break;
        	
    case "YE":
        $areaCode = "+967";
        break;
        	
    case "ZM":
        $areaCode = "+260";
        break;
        	
    case "ZW":
        $areaCode = "+263";
        break;
    default:
        $areaCode = "+";    	
    case "VI":
        $areaCode = "+1";
        break;
        	
    case "WF":
        $areaCode = "+681";
        break;
        	
    case "EH":
        $areaCode = "+";
        break;
        	
    case "YE":
        $areaCode = "+967";
        break;
        	
    case "ZM":
        $areaCode = "+260";
        break;
        	
    case "ZW":
        $areaCode = "+263";
        break;
    default:
        $areaCode = "+";    	
}

?>