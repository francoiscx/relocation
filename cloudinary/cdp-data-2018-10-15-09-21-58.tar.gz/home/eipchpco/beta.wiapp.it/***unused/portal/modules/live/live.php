
				
				<p>Confirm or change this info in order to save you some time later.</p>
					<div>
						<label style="font-size:13px">City</label>
						<input type="text" id="city" name="city" value="<?php echo $ipcity; ?>" placeholder="City">
					</div>
			
					<div>
						<label style="font-size:13px">Province</label>
						<input type="text" id="province" name="province" value="<?php echo $ipregion; ?>" placeholder="Province">
					</div>

					<div>
						<label style="font-size:13px">Country</label>
						<input type="text" id="counrty" name="country" value="<?php echo $ipcountry; ?>" placeholder="Country">
					</div>
					
					