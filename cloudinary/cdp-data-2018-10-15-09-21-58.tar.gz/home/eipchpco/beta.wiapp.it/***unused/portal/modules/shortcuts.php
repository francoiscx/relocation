<?php

echo "<!--Shortcuts-->          \n";
echo "        <div class=\"span6\">\n";
echo "          <div class=\"widget\">\n";
echo "            <div class=\"widget-header\"> <i class=\"icon-bookmark\"></i>\n";
echo "              <h3>Important Shortcuts</h3>\n";
echo "            </div>\n";
echo "            <!-- /widget-header -->\n";
echo "            <div class=\"widget-content\">\n";
echo "              <div class=\"shortcuts\"> <a href=\"javascript:;\" class=\"shortcut\"><i class=\"shortcut-icon icon-list-alt\"></i><span\n";
echo "                                        class=\"shortcut-label\">Apps</span> </a><a href=\"javascript:;\" class=\"shortcut\"><i\n";
echo "                                            class=\"shortcut-icon icon-bookmark\"></i><span class=\"shortcut-label\">Bookmarks</span> </a><a href=\"javascript:;\" class=\"shortcut\"><i class=\"shortcut-icon icon-signal\"></i> <span class=\"shortcut-label\">Reports</span> </a><a href=\"javascript:;\" class=\"shortcut\"> <i class=\"shortcut-icon icon-comment\"></i><span class=\"shortcut-label\">Comments</span> </a><a href=\"javascript:;\" class=\"shortcut\"><i class=\"shortcut-icon icon-user\"></i><span\n";
echo "                                                class=\"shortcut-label\">Users</span> </a><a href=\"javascript:;\" class=\"shortcut\"><i\n";
echo "                                                    class=\"shortcut-icon icon-file\"></i><span class=\"shortcut-label\">Notes</span> </a><a href=\"javascript:;\" class=\"shortcut\"><i class=\"shortcut-icon icon-picture\"></i> <span class=\"shortcut-label\">Photos</span> </a><a href=\"javascript:;\" class=\"shortcut\"> <i class=\"shortcut-icon icon-tag\"></i><span class=\"shortcut-label\">Tags</span> </a> </div>\n";
echo "              <!-- /shortcuts --> \n";
echo "            </div>\n";
echo "            <!-- /widget-content --> \n";
echo "          </div>";

?>
