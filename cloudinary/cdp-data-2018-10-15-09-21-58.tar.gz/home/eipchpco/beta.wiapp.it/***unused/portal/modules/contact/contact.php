<?php
$gl_cellArea = "gl_cellArea";
$gl_cell = "gl_cell";
$gl_cell_perm = "gl_cell_perm";
$gl_cell_status = "gl_cell_status";
?>

<!-- Start of Textfield for gl_cell -->


<?php
$gl_cellArea = $_SESSION['gl_cellArea'];
$gl_cell = $_SESSION['gl_cell'];
?>
    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/modules/areaCode/areaCode.php';?>
    
<p>Provide a mobile number where you may be contacted.</p>

<div class="groupl">
	
	    <label style="font-size:13px"for="gl_cellArea"><fb-none class="icon-none" aria-hidden="true"></fb-none>Code&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspCell&nbsp<span><h5 id="gl_cell_result" style="float:right; color:#381A64"></h5></span></label>
	        <input class="c" type="text" id="gl_cellArea" name="gl_cellArea" value="<?php echo $areaCode; ?>">
            <input class="n" type="text" id="gl_cell" name="gl_cell" value="<?php echo $gl_cell; ?>">
           
<!-- End of Textfield for gl_cell -->

</div> <!-- /field -->

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gl_cell_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 5000);
</script>

<!-- End of Radio Buttons for gl_cell_perm -->
