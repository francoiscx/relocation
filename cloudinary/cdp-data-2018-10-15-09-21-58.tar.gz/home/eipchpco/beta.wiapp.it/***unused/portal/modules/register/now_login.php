  
    <?php require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';?>
<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    $redirect = "'/portal/m.login_new.php'";
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    $redirect = "'/portal/m.login_new.php'";

    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    $redirect = "'/portal/m.login_new.php'";

    }
else if (Detect::isComputer()) {//browser reported as tablet device -- do something here
    //echo 'Computer';
    $notmobile = 101;
    $redirect = "'/portal/login_new.php'";


}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    $redirect = "'/portal/m.login_new.php'";
    
}

?>


<?php if($notmobile == 101) echo "<center>After verifying your email address you may return here </a> to log in to your new account.</center>";?>
<?php if($notmobile != 101) echo "<center>After verifying your email address you may<br><a href=$redirect>click here </a> to log in to your new account.</center>";?>

