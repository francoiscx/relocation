<?php

echo "<!--Stats-->        \n";
echo "        <div class=\"span6\">\n";
echo "          <div class=\"widget widget-nopad\">\n";
echo "            <div class=\"widget-header\"> <i class=\"icon-list-alt\"></i>\n";
echo "              <h3> Today's Stats</h3>\n";
echo "            </div>\n";
echo "            <!-- /widget-header -->\n";
echo "            <div class=\"widget-content\">\n";
echo "              <div class=\"widget big-stats-container\">\n";
echo "                <div class=\"widget-content\">\n";
echo "                  <h6 class=\"bigstats\">A fully responsive premium quality admin template built on Twitter Bootstrap by <a href=\"http://www.wi-app.com\" target=\"_blank\">Wi-APP</a>.  These are some dummy lines to fill the area.</h6>\n";
echo "                  <div id=\"big_stats\" class=\"cf\">\n";
echo "                    <div class=\"stat\"> <i class=\"icon-anchor\"></i> <span class=\"value\">851</span> </div>\n";
echo "                    <!-- .stat -->\n";
echo "                    \n";
echo "                    <div class=\"stat\"> <i class=\"icon-thumbs-up-alt\"></i> <span class=\"value\">423</span> </div>\n";
echo "                    <!-- .stat -->\n";
echo "                    \n";
echo "                    <div class=\"stat\"> <i class=\"icon-twitter-sign\"></i> <span class=\"value\">922</span> </div>\n";
echo "                    <!-- .stat -->\n";
echo "                    \n";
echo "                    <div class=\"stat\"> <i class=\"icon-bullhorn\"></i> <span class=\"value\">25%</span> </div>\n";
echo "                    <!-- .stat --> \n";
echo "                  </div>\n";
echo "                </div>\n";
echo "                <!-- /widget-content --> \n";
echo "                \n";
echo "              </div>\n";
echo "            </div>\n";
echo "          </div>\n";
echo "          <!-- /widget -->";

?>
