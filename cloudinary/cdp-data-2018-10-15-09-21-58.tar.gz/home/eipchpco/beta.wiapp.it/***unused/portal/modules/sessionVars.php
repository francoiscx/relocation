if(isset($row['defaultVerification'])) $defaultVerification = $row['defaultVerification'];
		if(isset($row['first_name'])) $first_name = $row['first_name'];
		if(isset($row['middle_name'])) $middle_name = $row['middle_name'];
		if(isset($row['last_name'])) $last_name = $row['last_name'];
		if(isset($row['cell'])) $cell = $row['cell'];
		if(isset($row['dob'])) $dob = $row['dob'];
		if(isset($row['sc_cell'])) $sc_cell = $row['sc_cell'];
		if(isset($row['sc_whatsapp'])) $sc_whatsapp = $row['sc_whatsapp'];
		if(isset($row['sc_skype'])) $sc_skype = $row['sc_skype'];
		if(isset($row['gender'])) $gender = $row['gender'];
		if(isset($row['status'])) $status = $row['status'];
		
		$username = $first_name.'&nbsp'.$last_name;
		


		if(password_verify($password, $hashed_password)){
			$_SESSION['id'] = $id;
			$_SESSION['defaultVerification'] = $defaultVerification;
			$_SESSION['email'] = $email;
			if(isset($username)) $_SESSION['username'] = $username;
			if(isset($first_name)) $_SESSION['first_name'] = $first_name;
			if(isset($middle_name)) $_SESSION['middle_name'] = $middle_name;
			if(isset($last_name)) $_SESSION['last_name'] = $last_name; 
			if(isset($cell)) $_SESSION['cell'] = $cell;
			if(isset($dob)) $_SESSION['dob'] = $dob;
			if(isset($sc_cell)) $_SESSION['sc_cell'] = $sc_cell;
			if(isset($sc_whatsapp)) $_SESSION['sc_whatsapp'] = $sc_whatsapp;
			if(isset($sc_skype)) $_SESSION['sc_skype'] = $sc_skype;
			if(isset($gender)) $_SESSION['gender'] = $gender;
			if(isset($status)) $_SESSION['status'] = $status;	
			
			if(!isset($_SESSION['sc_cell'])) $_SESSION['sc_cell'] = $user_cell;
			if(!isset($_SESSION['sc_whatsapp'])) $_SESSION['sc_whatsapp'] = $user_cell;