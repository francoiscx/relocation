<?php require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';?>
<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    $redirect = "'/portal/m.login.php'";
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    $redirect = "'/portal/m.login.php'";

    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    $redirect = "'/portal/m.login.php'";

    }
else if (Detect::isComputer()) {//browser reported as tablet device -- do something here
    //echo 'Computer';
    $notmobile = 101;
    $redirect = "'/portal/login.php'";


}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    $redirect = "'/portal/m.login.php'";
    
}

?>

<?php
//On Register Page - Check if user exists then if they do provide message and link to Login page 

//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
    
    $email = $_POST['Email'];
    $email = strtolower($email);
    
    //check
    if(denyDuplicate($email, $db)){
	$_SESSION['registered'] = $email;
	echo "<h4>An account with: </h4><h4 style='color: #381A64; border solid gray;'>" . $email . "</h4><h4> is already in use. You might want to try to <a href=$redirect>login.</a></h4>";
	}
?>





