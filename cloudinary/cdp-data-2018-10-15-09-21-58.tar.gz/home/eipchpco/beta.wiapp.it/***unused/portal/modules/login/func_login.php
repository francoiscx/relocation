<?php require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';?>
<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Wi-APP | Login</title>
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
<link href="img/logo.png">
<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    echo '<link href="css/stylei.css" rel="stylesheet">';
    echo '<link href="css/pages/signini.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivei.min.css" rel="stylesheet">';

    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    echo '<link href="css/stylea.css" rel="stylesheet">';
    echo '<link href="css/pages/signina.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivea.min.css" rel="stylesheet">';
    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    echo '<link href="css/stylem.css" rel="stylesheet">';
    echo '<link href="css/pages/signinm.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivem.min.css" rel="stylesheet">';
    }
else if (Detect::isComputer()) {
    $notmobile = 101;
    //echo 'Computer';
    echo '<link href="css/style.css" rel="stylesheet">';
    echo '<link href="css/pages/signin.css" rel="stylesheet">';
    echo '<link href="https://file.myfontastic.com/KKqgH4SYhM9ooPCkVerp8m/icons.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsive.min.css" rel="stylesheet">';
}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    echo '<link href="css/stylem.css" rel="stylesheet">';
    echo '<link href="css/pages/signinm.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivem.min.css" rel="stylesheet">';    
}

?>


<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->


<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script>
function checkServer()
{
    var ajaxrequest;
    var email = document.getElementById("Email").value;
    
    if (window.XMLHttpRequest)
    {
        ajaxrequest = new XMLHttpRequest();
    } else {
        ajaxrequest = new ActiveXObject("Microsoft.XMLHTTP"); /// Older Browsers
    }
    
    ajaxrequest.onreadystatechange = function()
    {
        console.log(ajaxrequest);
    if (ajaxrequest.readyState == 4 && ajaxrequest.status == 200)
    {
        document.getElementById("WelcomeUserResponse").innerHTML = ajaxrequest.responseText;
        }
    }
    ajaxrequest.open("POST", "/portal/modules/register/welcome_user.php", true);
    ajaxrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajaxrequest.send("Email=" + email);
}
</script>


</head>
<body>


<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
  <div>
    <div class="container">
                       <a href="http://beta.wiapp.it"><img src="/portal/img/tiles/apple-icon-152x152.png" width="70px" hspace="5" alt="Wi-APP"></a>
 
 
 
 <form id="login" action="" method="post">
                           
                    <div style="float:right; margin-top: -75px;">
                        				<div class="field1" style="float:left; margin-top:25px; margin-right:5px;">
					                    <input style="width: 235px" type="Email" id="LEmail" name="LEmail" value="<?php if(isset($_POST['LEmail'])){ echo htmlentities ($_POST['LEmail']); }else if(isset($_SESSION['registered'])){echo $_SESSION['registered'];};?>" required placeholder="Email" onblur="checkServer()" class="login"/>
				    </div> <!-- /field -->
				
				                        <div class="field1" style="float:left; margin-top:25px">					
					<input type="Password" id="LPassword" name="LPassword" title="Minimum 7 characters, one number, one uppercase and one lowercase letter"  value="" required placeholder="Password" class="login"/> <!-- pattern="^(?=(.*[a-zA-Z].*){2,})(?=.*\d.*)(?=.*\W.*)[a-zA-Z0-9\S]{7,36}$"-->
				</div> <!-- /field -->
                    <button type="submit" name="loginBtn" style="float:right; color:white; font-size: 40px; border-style: none!important; width:10px; background:none; margin-top: 22px; margin-right: 42px; "><i class="fa icon-sign-in"></i></button>
                    
</form>
				
            </div>  
                       
            <div id='WelcomeUserResponse'></div>           
                       
                       
                       
                       
                       
                       
                       
                       
                       
  </div>
  </div>
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
    
    		  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span> 
                  
                  	</a><a class="brand" href="/portal/index.php">Wi-APP</a>
<?php			
include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/func_signup.php';
?>
			<div class="nav-collapse">
				<ul class="nav pull-right">
					 
					
					<li class="">						
						<a href="/info/index.php" class="">
							<i class="icon-info-circle" style="line-height: 22px!important;"></i>
							
							Learn more about Wi-APP
						</a>
						
					</li>
				</ul>
				
			</div><!--/.nav-collapse -->	
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->

<div class="account-container">
	
	<div class="content clearfix">
	
		
		<form id="register method="post" action="" >
		
<?php if(isset($registered)) echo "<h1>Account Created!</h1>";						
	else if (isset($result)) echo "<h1>Oops! Some fixes required.</h1>";
	else echo "<h2>Don't have an account?</h2>";?>		
	<div id='UserAvailResponse'></div>
	<div class="login-fields">
			
			
	
<?php if(isset($result)) echo $result;?>
<?php if(!empty($form_errors)) echo show_errors($form_errors);?>	
	
<?php if(!isset($result)) echo "<h3>Create one here, it's free</h3><br>";?>			
				
<?php if(!isset($result)) include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/register.php';?>

		</form>
		











<script type="text/javascript">
    function confirmEmail() {
        var email = document.getElementById("Email").value
        var email_confirm = document.getElementById("Email_Confirm").value
            if (email_confirm.length != 0) {
                                if (email != email_confirm) { 
                                alert('Email Not Matching!');
                                }
                    }
    }
</script>


<script>
    // Register onpaste on inputs and textareas in browsers that don't
    // natively support it.
(function () {
    var onload = window.onload;

    window.onload = function () {
        if (typeof onload == "function") {
            onload.apply(this, arguments);
        }

        var fields = [];
        var inputs = document.getElementsByTagName("input");
        var textareas = document.getElementsByTagName("textarea");

        for (var i = 0; i < inputs.length; i++) {
            fields.push(inputs[i]);
        }

        for (var i = 0; i < textareas.length; i++) {
            fields.push(textareas[i]);
        }

        for (var i = 0; i < fields.length; i++) {
            var field = fields[i];

            if (typeof field.onpaste != "function" && !!field.getAttribute("onpaste")) {
                field.onpaste = eval("(function () { " + field.getAttribute("onpaste") + " })");
            }

            if (typeof field.onpaste == "function") {
                var oninput = field.oninput;

                field.oninput = function () {
                    if (typeof oninput == "function") {
                        oninput.apply(this, arguments);
                    }

                    if (typeof this.previousValue == "undefined") {
                        this.previousValue = this.value;
                    }

                    var pasted = (Math.abs(this.previousValue.length - this.value.length) > 1 && this.value != "");

                    if (pasted && !this.onpaste.apply(this, arguments)) {
                        this.value = this.previousValue;
                    }

                    this.previousValue = this.value;
                };

                if (field.addEventListener) {
                    field.addEventListener("input", field.oninput, false);
                } else if (field.attachEvent) {
                    field.attachEvent("oninput", field.oninput);
                }
            }
        }
    }
})();
</script>


<script>
function checkServer()
{
    var ajaxrequest;
    var email = document.getElementById("Email").value;
    
    
    if (window.XMLHttpRequest)
    {
        ajaxrequest = new XMLHttpRequest();
    } else {
        ajaxrequest = new ActiveXObject("Microsoft.XMLHTTP"); /// Older Browsers
    }
    
    
    ajaxrequest.onreadystatechange = function()
    {
        console.log(ajaxrequest);
    if (ajaxrequest.readyState == 4 && ajaxrequest.status == 200)
    {
        document.getElementById("UserAvailResponse").innerHTML = ajaxrequest.responseText;
        }
    }
    ajaxrequest.open("POST", "/portal/modules/login/check_if_user_exists.php", true);
    ajaxrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajaxrequest.send("Email=" + email);
}
</script>		
		

		

	


<!-- Text Under Box -->
<div class="login-extra">
<?php if(isset($registered)) include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/now_login.php';
else if (isset($result)) echo "<a href=\"javascript:history.go(-1)\">GO BACK</a>";
else include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/have_account.php';?>
</div> <!-- /login-extra -->

			</div> <!-- .actions -->

</div> <!-- /account-container -->

<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/break_before_footer.php';?>
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';?>
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/footer_bottom.php';?>

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/signin.js"></script>

</body>

					
 </html>