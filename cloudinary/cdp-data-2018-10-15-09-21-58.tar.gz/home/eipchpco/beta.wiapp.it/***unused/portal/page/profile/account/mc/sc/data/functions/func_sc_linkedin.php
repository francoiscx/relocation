<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$sc_linkedin = $_POST['sc_linkedin'];

//process the form if the button is clicked
if (isset($_POST['sc_linkedin'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE social_card SET sc_linkedin =:sc_linkedin WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_linkedin' => $sc_linkedin, ':userID' => $userID));

                    $sc_linkedin_result = "Success";
                    $_SESSION['sc_linkedin'] = $sc_linkedin;
                    
                 }catch (PDOException $ex){
                $sc_linkedin_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO social_card (userID, sc_linkedin)
                        VALUES (:userID, :sc_linkedin)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':sc_linkedin' => $sc_linkedin));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $sc_linkedin_result = "Success";
                }
   
                    $sc_linkedin_result = "Success";
                    
                    $_SESSION['sc_linkedin'] = $sc_linkedin;
                }
            }catch (PDOException $ex){
                $sc_linkedin_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $sc_linkedin_result
?>

