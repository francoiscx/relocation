<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gc_lastname_status = $_POST['gc_lastname_status'];

//process the form if the button is clicked
if (isset($_POST['gc_lastname_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlgc_lastname_statusQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgc_lastname_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgc_lastname_statusUpdate = "UPDATE general_card SET gc_lastname_status =:gc_lastname_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgc_lastname_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_lastname_status' => $gc_lastname_status, ':userID' => $userID));

                    $gc_lastname_status_result = 'gc_lastname_status';
                    $_SESSION['gc_lastname_status'] = $gc_lastname_status;
                
                 }catch (PDOException $ex){
                $gc_lastname_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlgc_lastname_statusInsert = "INSERT INTO general_card (userID, gc_lastname_status)
                    VALUES (:userID, :gc_lastname_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgc_lastname_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gc_lastname_status' => $gc_lastname_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gc_lastname_status_result = 'gc_lastname_status';
                    $_SESSION['gc_lastname_status'] = $gc_lastname_status;
	    	        }
                }
            }catch (PDOException $ex){
                $gc_lastname_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($gc_lastname_status == gc_lastnameactive) echo "gc_lastnameactive";
 else if ($gc_lastname_status != gc_lastnameactive) echo "gc_lastnamepassive";

?>