<?php
$gc_age = "gc_age";
$gc_age_perm = "gc_age_perm";
$gc_age_status = "gc_age_status";
?>


<div  id="gc_age_status"></div>

<!-- Start of Textfield for gc_age -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_age: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_age = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_age(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_age(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_age').donetypinggc_age(function(){
  	var gc_age = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_age.php",
        method:"POST",
        data:{gc_age:gc_age},
        success: function(data){
      	$('#gc_age_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_age = $_SESSION['gc_age'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="gc_age"><fb-none class="icon-none" aria-hidden="true"></fb-none>Age&nbsp<span><h5 id="gc_age_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="gc_age" name="gc_age" value="<?php echo $gc_age; ?>">
            
<!-- End of Textfield for gc_age -->






<!-- Start of Radio Buttons for gc_age_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_age_perm"]').click(function(){
  	var gc_age_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_age_perm.php",
        method:"POST",
        data:{gc_age_perm:gc_age_perm},
        success: function(data){
      	$('#gc_age_result').html(data);
      }
    });
  });
});
</script>

<?php

$gc_age_perm = $_SESSION['gc_age_perm'];
switch ($gc_age_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_age_perm_pub" name="gc_age_perm" checked="checked" value="Public">
                <label for="gc_age_perm_pub" id="gc_age_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_age_perm_req" name="gc_age_perm" value="Request">
                <label for="gc_age_perm_req" id="gc_age_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_age_perm_pri" name="gc_age_perm" value="Private">
                <label for="gc_age_perm_pri" id="gc_age_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_age_perm_pub" name="gc_age_perm" value="Public">
                <label for="gc_age_perm_pub" id="gc_age_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_age_perm_req" name="gc_age_perm" checked="checked" value="Request">
                <label for="gc_age_perm_req" id="gc_age_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_age_perm_pri" name="gc_age_perm" value="Private">
                <label for="gc_age_perm_pri" id="gc_age_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_age_perm_pub" name="gc_age_perm" value="Public">
                <label for="gc_age_perm_pub" id="gc_age_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_age_perm_req" name="gc_age_perm" value="Request">
                <label for="gc_age_perm_req" id="gc_age_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_age_perm_pri" name="gc_age_perm" checked="checked" value="Private">
                <label for="gc_age_perm_pri" id="gc_age_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_age_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 5e2);
</script>
</div>
<!-- End of Radio Buttons for gc_age_perm -->