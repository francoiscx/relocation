<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gen_gender_perm = $_POST['gen_gender_perm'];

//process the form if the button is clicked
if (isset($_POST['gen_gender_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlgen_gender_permQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgen_gender_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgen_gender_permUpdate = "UPDATE professional_card SET gen_gender_perm =:gen_gender_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgen_gender_permUpdate);

                    //execute the statement
                    $statement->execute(array(':gen_gender_perm' => $gen_gender_perm, ':userID' => $userID));

                    $gen_gender_result = "Update Successful";
                    $_SESSION['gen_gender_perm'] = $gen_gender_perm;
                
                 }catch (PDOException $ex){
                $gen_gender_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlgen_gender_permInsert = "INSERT INTO professional_card (userID, gen_gender_perm)
                    VALUES (:userID, :gen_gender_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgen_gender_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gen_gender_perm' => $gen_gender_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gen_gender_result = "Card created";
                    $_SESSION['gen_gender_perm'] = $gen_gender_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $gen_gender_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $gen_gender_result
?>