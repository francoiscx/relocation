<!-- Start of Radio Buttons for pc_youtube_status -->
<div class="groupl">

<?php

$pc_youtube_status = $_SESSION['pc_youtube_status'];

if(!isset($pc_youtube_status)) {$pc_youtube_status = 'pc_youtubepassive'; }



//echo $pc_youtube_status;

switch ($pc_youtube_status) {
    case "pc_youtubeactive":
        echo "
<div>

    <div class='pc_youtube_selection' id='pc_youtubeactive'>
    <a class='pc_youtube_selectionSwitch' href='#pc_youtubepassive'><input type='radio' id='pc_youtube_status_on' name='pc_youtube_status' value='pc_youtubepassive' hidden> 
    <label for='pc_youtube_status_on' class='pc_youtube_Check'>
     <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_youtube_selection' id='pc_youtubepassive'>
    <a class='pc_youtube_selectionSwitch' href='#pc_youtubeactive'><input type='radio' id='pc_youtube_status_off' name='pc_youtube_status' value='pc_youtubeactive' hidden>
    <label for='pc_youtube_status_off' class='pc_youtube_Check'>
    <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_youtube_status').on('click', function () {
        check = $('#pc_youtube_status').prop('checked');
        
        if (check) {
            if ($('.pc_youtube_Check i').hasClass('icon-check-square')) {
                $('.pc_youtube_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_youtube_Check i').hasClass('icon-square-o')) {
                $('.pc_youtube_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_youtube_status = $('#pc_youtubeactive, #pc_youtubepassive').hide();
$('#pc_youtubeactive').show();
$('#pc_youtubepassive').hide();
$('.pc_youtube_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_youtube_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_youtubepassive":
        echo "
<div>

  <div class='pc_youtube_selection' id='pc_youtubepassive'>
    <a class='pc_youtube_selectionSwitch' href='#pc_youtubeactive'><input type='radio' id='pc_youtube_status_off' name='pc_youtube_status' value='pc_youtubeactive' hidden>
    <label for='pc_youtube_status_off' class='pc_youtube_Check'>
    <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_youtube_selection' id='pc_youtubeactive'>
    <a class='pc_youtube_selectionSwitch' href='#pc_youtubepassive'><input type='radio' id='pc_youtube_status_on' name='pc_youtube_status' value='pc_youtubepassive' hidden>
    <label for='pc_youtube_status_on' class='pc_youtube_Check'>
     <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_youtube_status').on('click', function () {
        check = $('#pc_youtube_status').prop('checked');
        
        if (check) {
            if ($('.pc_youtube_Check i').hasClass('icon-square-o')) {
                $('.pc_youtube_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_youtube_Check i').hasClass('icon-check-square')) {
                $('.pc_youtube_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_youtube_status = $('#pc_youtubeactive, #pc_youtubepassive').hide();
$('#pc_youtubeactive').hide();
$('#pc_youtubepassive').show();
$('.pc_youtube_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_youtube_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_youtube_selection' id='pc_youtubepassive'>
    <a class='pc_youtube_selectionSwitch' href='#pc_youtubeactive'><input type='radio' id='pc_youtube_status_off' name='pc_youtube_status' value='pc_youtubeactive' hidden>
    <label for='pc_youtube_status_off' class='pc_youtube_Check'>
    <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_youtube_selection' id='pc_youtubeactive'>
    <a class='pc_youtube_selectionSwitch' href='#pc_youtubepassive'><input type='radio' id='pc_youtube_status_on' name='pc_youtube_status' value='pc_youtubepassive' hidden>
    <label for='pc_youtube_status_on' class='pc_youtube_Check'>
     <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_youtube_status').on('click', function () {
        check = $('#pc_youtube_status').prop('checked');
        
        if (check) {
            if ($('.pc_youtube_Check i').hasClass('icon-square-o')) {
                $('.pc_youtube_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_youtube_Check i').hasClass('icon-check-square')) {
                $('.pc_youtube_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_youtube_status = $('#pc_youtubeactive, #pc_youtubepassive').hide();
$('#pc_youtubeactive').hide();
$('#pc_youtubepassive').show();
$('.pc_youtube_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_youtube_status.hide();
    $(href).show();
})
});
</script>


";
}


?>














</div>