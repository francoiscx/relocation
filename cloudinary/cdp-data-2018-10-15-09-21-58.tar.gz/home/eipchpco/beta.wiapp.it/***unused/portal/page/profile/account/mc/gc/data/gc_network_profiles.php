<?php
$gc_facebook_status = $_SESSION['gc_facebook_status'];
$gc_twitter_status = $_SESSION['gc_twitter_status'];
$gc_googleP_status = $_SESSION['gc_googleP_status'];
?>



<form id="gc_network_handles" method="post" action="" autocomplete="off">   

	<div>	

	    
	    <div id="gc_facebook_field" class="groupl2" <?php if($gc_facebook_status == 'gc_facebookactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
									    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_facebook.php';?>							
	    </div>
	    
		<div id="gc_twitter_field" class="groupl2" <?php if($gc_twitter_status == 'gc_twitteractive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_twitter.php'; ?> 
	    </div>
	    
		<div id="gc_googleP_field" class="groupl2" <?php if($gc_googleP_status == 'gc_googlePactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_googleP.php'; ?>
	    </div>
	    
</div>
									
</form>




<script>
$(document).ready(function(){
	$('input[name=\'gc_facebook_status\']').click(function(){
  	var gc_facebook_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_facebook_status.php',
        method:'POST',
        data:{gc_facebook_status:gc_facebook_status},
        success: function(gc_facebookresponse){
                    gc_facebook_status_result = gc_facebookresponse;
                    console.log(gc_facebook_status_result);
                    
                    if (gc_facebook_status_result == 'gc_facebookactive')
                        $("#gc_facebook_field").show();
                    else    
                        $("#gc_facebook_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_twitter_status\']').click(function(){
  	var gc_twitter_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_twitter_status.php',
        method:'POST',
        data:{gc_twitter_status:gc_twitter_status},
        success: function(gc_twitterresponse){
                    gc_twitter_status_result = gc_twitterresponse;
                    console.log(gc_twitter_status_result);
                    
                    if (gc_twitter_status_result == 'gc_twitteractive')
                        $("#gc_twitter_field").show();
                    else    
                        $("#gc_twitter_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_googleP_status\']').click(function(){
  	var gc_googleP_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_googleP_status.php',
        method:'POST',
        data:{gc_googleP_status:gc_googleP_status},
        success: function(gc_googlePresponse){
                    gc_googleP_status_result = gc_googlePresponse;
                    console.log(gc_googleP_status_result);
                    
                    if (gc_googleP_status_result == 'gc_googlePactive')
                        $("#gc_googleP_field").show();
                    else    
                        $("#gc_googleP_field").hide();
                  } 
        });
  });
});
</script>




