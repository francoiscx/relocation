<!-- Start of Radio Buttons for sc_twitter_status -->
<div class="groupl">

<?php

$sc_twitter_status = $_SESSION['sc_twitter_status'];

if(!isset($sc_twitter_status)) {$sc_twitter_status = 'sc_twitterpassive'; }



//echo $sc_twitter_status;

switch ($sc_twitter_status) {
    case "sc_twitteractive":
        echo "
<div>

    <div class='sc_twitter_selection' id='sc_twitteractive'>
    <a class='sc_twitter_selectionSwitch' href='#sc_twitterpassive'><input type='radio' id='sc_twitter_status_on' name='sc_twitter_status' value='sc_twitterpassive' hidden> 
    <label for='sc_twitter_status_on' class='sc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='sc_twitter_selection' id='sc_twitterpassive'>
    <a class='sc_twitter_selectionSwitch' href='#sc_twitteractive'><input type='radio' id='sc_twitter_status_off' name='sc_twitter_status' value='sc_twitteractive' hidden>
    <label for='sc_twitter_status_off' class='sc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#sc_twitter_status').on('click', function () {
        check = $('#sc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.sc_twitter_Check i').hasClass('icon-check-square')) {
                $('.sc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.sc_twitter_Check i').hasClass('icon-square-o')) {
                $('.sc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_twitter_status = $('#sc_twitteractive, #sc_twitterpassive').hide();
$('#sc_twitteractive').show();
$('#sc_twitterpassive').hide();
$('.sc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_twitter_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "sc_twitterpassive":
        echo "
<div>

  <div class='sc_twitter_selection' id='sc_twitterpassive'>
    <a class='sc_twitter_selectionSwitch' href='#sc_twitteractive'><input type='radio' id='sc_twitter_status_off' name='sc_twitter_status' value='sc_twitteractive' hidden>
    <label for='sc_twitter_status_off' class='sc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='sc_twitter_selection' id='sc_twitteractive'>
    <a class='sc_twitter_selectionSwitch' href='#sc_twitterpassive'><input type='radio' id='sc_twitter_status_on' name='sc_twitter_status' value='sc_twitterpassive' hidden>
    <label for='sc_twitter_status_on' class='sc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#sc_twitter_status').on('click', function () {
        check = $('#sc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.sc_twitter_Check i').hasClass('icon-square-o')) {
                $('.sc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.sc_twitter_Check i').hasClass('icon-check-square')) {
                $('.sc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_twitter_status = $('#sc_twitteractive, #sc_twitterpassive').hide();
$('#sc_twitteractive').hide();
$('#sc_twitterpassive').show();
$('.sc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_twitter_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='sc_twitter_selection' id='sc_twitterpassive'>
    <a class='sc_twitter_selectionSwitch' href='#sc_twitteractive'><input type='radio' id='sc_twitter_status_off' name='sc_twitter_status' value='sc_twitteractive' hidden>
    <label for='sc_twitter_status_off' class='sc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='sc_twitter_selection' id='sc_twitteractive'>
    <a class='sc_twitter_selectionSwitch' href='#sc_twitterpassive'><input type='radio' id='sc_twitter_status_on' name='sc_twitter_status' value='sc_twitterpassive' hidden>
    <label for='sc_twitter_status_on' class='sc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#sc_twitter_status').on('click', function () {
        check = $('#sc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.sc_twitter_Check i').hasClass('icon-square-o')) {
                $('.sc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.sc_twitter_Check i').hasClass('icon-check-square')) {
                $('.sc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_twitter_status = $('#sc_twitteractive, #sc_twitterpassive').hide();
$('#sc_twitteractive').hide();
$('#sc_twitterpassive').show();
$('.sc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_twitter_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>