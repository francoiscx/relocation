<!-- Start of Radio Buttons for pc_pinterest_status -->
<div class="groupl">

<?php

$pc_pinterest_status = $_SESSION['pc_pinterest_status'];

if(!isset($pc_pinterest_status)) {$pc_pinterest_status = 'pc_pinterestpassive'; }



//echo $pc_pinterest_status;

switch ($pc_pinterest_status) {
    case "pc_pinterestactive":
        echo "
<div>

    <div class='pc_pinterest_selection' id='pc_pinterestactive'>
    <a class='pc_pinterest_selectionSwitch' href='#pc_pinterestpassive'><input type='radio' id='pc_pinterest_status_on' name='pc_pinterest_status' value='pc_pinterestpassive' hidden> 
    <label for='pc_pinterest_status_on' class='pc_pinterest_Check'>
     <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_pinterest_selection' id='pc_pinterestpassive'>
    <a class='pc_pinterest_selectionSwitch' href='#pc_pinterestactive'><input type='radio' id='pc_pinterest_status_off' name='pc_pinterest_status' value='pc_pinterestactive' hidden>
    <label for='pc_pinterest_status_off' class='pc_pinterest_Check'>
    <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_pinterest_status').on('click', function () {
        check = $('#pc_pinterest_status').prop('checked');
        
        if (check) {
            if ($('.pc_pinterest_Check i').hasClass('icon-check-square')) {
                $('.pc_pinterest_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_pinterest_Check i').hasClass('icon-square-o')) {
                $('.pc_pinterest_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_pinterest_status = $('#pc_pinterestactive, #pc_pinterestpassive').hide();
$('#pc_pinterestactive').show();
$('#pc_pinterestpassive').hide();
$('.pc_pinterest_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_pinterest_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_pinterestpassive":
        echo "
<div>

  <div class='pc_pinterest_selection' id='pc_pinterestpassive'>
    <a class='pc_pinterest_selectionSwitch' href='#pc_pinterestactive'><input type='radio' id='pc_pinterest_status_off' name='pc_pinterest_status' value='pc_pinterestactive' hidden>
    <label for='pc_pinterest_status_off' class='pc_pinterest_Check'>
    <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_pinterest_selection' id='pc_pinterestactive'>
    <a class='pc_pinterest_selectionSwitch' href='#pc_pinterestpassive'><input type='radio' id='pc_pinterest_status_on' name='pc_pinterest_status' value='pc_pinterestpassive' hidden>
    <label for='pc_pinterest_status_on' class='pc_pinterest_Check'>
     <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_pinterest_status').on('click', function () {
        check = $('#pc_pinterest_status').prop('checked');
        
        if (check) {
            if ($('.pc_pinterest_Check i').hasClass('icon-square-o')) {
                $('.pc_pinterest_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_pinterest_Check i').hasClass('icon-check-square')) {
                $('.pc_pinterest_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_pinterest_status = $('#pc_pinterestactive, #pc_pinterestpassive').hide();
$('#pc_pinterestactive').hide();
$('#pc_pinterestpassive').show();
$('.pc_pinterest_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_pinterest_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_pinterest_selection' id='pc_pinterestpassive'>
    <a class='pc_pinterest_selectionSwitch' href='#pc_pinterestactive'><input type='radio' id='pc_pinterest_status_off' name='pc_pinterest_status' value='pc_pinterestactive' hidden>
    <label for='pc_pinterest_status_off' class='pc_pinterest_Check'>
    <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_pinterest_selection' id='pc_pinterestactive'>
    <a class='pc_pinterest_selectionSwitch' href='#pc_pinterestpassive'><input type='radio' id='pc_pinterest_status_on' name='pc_pinterest_status' value='pc_pinterestpassive' hidden>
    <label for='pc_pinterest_status_on' class='pc_pinterest_Check'>
     <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_pinterest_status').on('click', function () {
        check = $('#pc_pinterest_status').prop('checked');
        
        if (check) {
            if ($('.pc_pinterest_Check i').hasClass('icon-square-o')) {
                $('.pc_pinterest_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_pinterest_Check i').hasClass('icon-check-square')) {
                $('.pc_pinterest_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_pinterest_status = $('#pc_pinterestactive, #pc_pinterestpassive').hide();
$('#pc_pinterestactive').hide();
$('#pc_pinterestpassive').show();
$('.pc_pinterest_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_pinterest_status.hide();
    $(href).show();
})
});
</script>


";
}


?>


</div>