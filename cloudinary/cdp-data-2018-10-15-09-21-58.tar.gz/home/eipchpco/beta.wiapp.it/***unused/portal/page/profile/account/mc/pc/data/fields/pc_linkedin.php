<?php
$pc_linkedin = "pc_linkedin";
$pc_linkedin_perm = "pc_linkedin_perm";
$pc_linkedin_status = "pc_linkedin_status";
?>


<div  id="pc_linkedin_status"></div>

<!-- Start of Textfield for pc_linkedin -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_linkedin: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypingpc_linkedin = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_linkedin(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_linkedin(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_linkedin').donetypingpc_linkedin(function(){
  	var pc_linkedin = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_linkedin.php",
        method:"POST",
        data:{pc_linkedin:pc_linkedin},
        success: function(data){
      	$('#pc_linkedin_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_linkedin = $_SESSION['pc_linkedin'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="pc_linkedin"><fb-linkedin class="icon-linkedin-square" aria-hidden="true"></fb-linkedin>linkedin.com/in/&nbsp<span><h5 id="pc_linkedin_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_linkedin" name="pc_linkedin" value="<?php echo $pc_linkedin; ?>">
            
<!-- End of Textfield for pc_linkedin -->






<!-- Start of Radio Buttons for pc_linkedin_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_linkedin_perm"]').click(function(){
  	var pc_linkedin_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_linkedin_perm.php",
        method:"POST",
        data:{pc_linkedin_perm:pc_linkedin_perm},
        success: function(data){
      	$('#pc_linkedin_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_linkedin_perm = $_SESSION['pc_linkedin_perm'];
switch ($pc_linkedin_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_linkedin_perm_pub" name="pc_linkedin_perm" checked="checked" value="Public">
                <label for="pc_linkedin_perm_pub" id="pc_linkedin_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_linkedin_perm_req" name="pc_linkedin_perm" value="Request">
                <label for="pc_linkedin_perm_req" id="pc_linkedin_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_linkedin_perm_pri" name="pc_linkedin_perm" value="Private">
                <label for="pc_linkedin_perm_pri" id="pc_linkedin_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_linkedin_perm_pub" name="pc_linkedin_perm" value="Public">
                <label for="pc_linkedin_perm_pub" id="pc_linkedin_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_linkedin_perm_req" name="pc_linkedin_perm" checked="checked" value="Request">
                <label for="pc_linkedin_perm_req" id="pc_linkedin_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_linkedin_perm_pri" name="pc_linkedin_perm" value="Private">
                <label for="pc_linkedin_perm_pri" id="pc_linkedin_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_linkedin_perm_pub" name="pc_linkedin_perm" value="Public">
                <label for="pc_linkedin_perm_pub" id="pc_linkedin_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_linkedin_perm_req" name="pc_linkedin_perm" value="Request">
                <label for="pc_linkedin_perm_req" id="pc_linkedin_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_linkedin_perm_pri" name="pc_linkedin_perm" checked="checked" value="Private">
                <label for="pc_linkedin_perm_pri" id="pc_linkedin_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_linkedin_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 1e3);
</script>
</div>
<!-- End of Radio Buttons for pc_linkedin_perm -->