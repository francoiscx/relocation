
<?php $_SESSION['gc_firstname'] = 'Francois'; ?>
<?php $firstname = $_SESSION['gc_firstname']; ?>
<?php $flip = 'yes';?>



<div class="centre">
    <section class="cardContainer">
            <div class="card">
            <div class="front">
                <container>    
                    <div>
                        <?php if($flip == 'yes') echo'  <button  onclick="flip()" class="rotateimg" style"z-index:200"><i class="icon-forward"></i></button> ';?>
                    </div>
                    <h1>Hello</h1>
                </container>
            </div>
            </div>
    </section>
    
    
    <section class="cardContainer" style="margin-top:-300px">        
            <div class="card">
            <div class="back">
                <div>
            <?php if($flip == 'yes') echo'  <button  onclick="flip()" class="rotateimg" style"z-index:200"><i class="icon-forward"></i></button> ';?>
                </div>
                    <h1>Bye</h1>
            </div>
    </section>
</div>



<script>
    function flip() {
    $('.card').toggleClass('flipped');
}
</script>


