<?php
$pc_reddit = "pc_reddit";
$pc_reddit_perm = "pc_reddit_perm";
$pc_reddit_status = "pc_reddit_status";
?>

<!-- Start of Textfield for pc_reddit -->
<div class="groupl">
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_reddit: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_reddit = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_reddit(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_reddit(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_reddit').donetypingpc_reddit(function(){
  	var pc_reddit = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_reddit.php",
        method:"POST",
        data:{pc_reddit:pc_reddit},
        success: function(data){
      	$('#pc_reddit_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_reddit = $_SESSION['pc_reddit'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_reddit">Reddit&nbsp<span><h5 id="pc_reddit_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_reddit" name="pc_reddit" value="<?php echo $pc_reddit; ?>">
            
<!-- End of Textfield for pc_reddit -->






<!-- Start of Radio Buttons for pc_reddit_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_reddit_perm"]').click(function(){
  	var pc_reddit_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_reddit_perm.php",
        method:"POST",
        data:{pc_reddit_perm:pc_reddit_perm},
        success: function(data){
      	$('#pc_reddit_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_reddit_perm = $_SESSION['pc_reddit_perm'];
switch ($pc_reddit_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_reddit_perm_pub" name="pc_reddit_perm" checked="checked" value="Public">
                <label for="pc_reddit_perm_pub" id="pc_reddit_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_reddit_perm_req" name="pc_reddit_perm" value="Request">
                <label for="pc_reddit_perm_req" id="pc_reddit_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_reddit_perm_pri" name="pc_reddit_perm" value="Private">
                <label for="pc_reddit_perm_pri" id="pc_reddit_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_reddit_perm_pub" name="pc_reddit_perm" value="Public">
                <label for="pc_reddit_perm_pub" id="pc_reddit_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_reddit_perm_req" name="pc_reddit_perm" checked="checked" value="Request">
                <label for="pc_reddit_perm_req" id="pc_reddit_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_reddit_perm_pri" name="pc_reddit_perm" value="Private">
                <label for="pc_reddit_perm_pri" id="pc_reddit_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_reddit_perm_pub" name="pc_reddit_perm" value="Public">
                <label for="pc_reddit_perm_pub" id="pc_reddit_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_reddit_perm_req" name="pc_reddit_perm" value="Request">
                <label for="pc_reddit_perm_req" id="pc_reddit_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_reddit_perm_pri" name="pc_reddit_perm" checked="checked" value="Private">
                <label for="pc_reddit_perm_pri" id="pc_reddit_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_reddit_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>
</div>
<!-- End of Radio Buttons for pc_reddit_perm -->
