
<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#myProfessionalInfo">My Professional Details <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="myProfessionalInfo" class="accordion-body collapse">
    	
			    
			    <p class="help-block">Select the networks you have a profile for and that you wish to share on your professional card.</p>	


						<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_firstname.php'; echo '</div>';
						?>
										
						<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_middlename.php'; echo '</div>';
						?>
										
						<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_lastname.php'; echo '</div>'; 
						?>
										
						<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_nickname.php'; echo '</div>'; 
						?>
						
	    				<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_gender.php'; echo '</div>'; 
	    				?>
										
						<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_age.php'; echo '</div>'; 
						?>
										
						<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_position.php'; echo '</div>'; 
						?>
										
						<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_officenumber.php'; echo '</div>'; 
						?>
										
						<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_cell.php'; echo '</div>'; 
						?>
										
						<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_whatsapp.php'; echo '</div>'; 
						?>
									
						<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_email.php'; echo '</div>'; 
						?>
										
						<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_pa.php'; echo '</div>'; 
						?>


		</div>
	</div>		



<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#myProfessionalNetworks">My Professional Networks <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="myProfessionalNetworks" class="accordion-body collapse">	

            <p class="help-block">Please provide your info you wish to share on your profesional card. <input type="text" placeholder="Filter Social Networks" id="filterPC" style="float:right; padding-top:10px"/>
<div style="clear:both;"></div></p>	

	
			

		<div class="select-catpc" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_linkedin_status.php';
	                    ?>
					</div>
					<span class="namepc">LinkedIn</span>
                        <p class="categorypc">Community</p>
		</div>


		<div class="select-catpc" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_facebook_status.php';
	                    ?>
					</div>
					<span class="namepc">facebook</span>
                        <p class="categorypc">Community</p>
		</div>

		
		
		<div class="select-catpc" catname="Blogging" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_twitter_status.php';
	                    ?>
					</div>
					<span class="namepc">Twitter</span>
                        <p class="categorypc">Blogging</p>
		</div>

		
		
		<div class="select-catpc" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_googleP_status.php';
	                    ?>
					</div>
					<span class="namepc">google+</span>
                        <p class="categorypc">Community</p>
		</div>
            
		<div class="select-catpc" catname="Video" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_youtube_status.php';
	                    ?>
					</div>
					<span class="namepc">YouTube</span>
                        <p class="categorypc">Video</p>
		</div>
		
		<div class="select-catpc" catname="Photo" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_instagram_status.php';
	                    ?>
					</div>
					<span class="namepc">Instagram</span>
                        <p class="categorypc">Photo</p>
		</div>
            
		<div class="select-catpc" catname="Photo" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_pinterest_status.php';
	                    ?>
					</div>
					<span class="namepc">Pinterest</span>
                        <p class="categorypc">Photo</p>
		</div>
            
		<div class="select-catpc" catname="Photo" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_flickr_status.php';
	                    ?>
					</div>
					<span class="namepc">flickr</span>
                        <p class="categorypc">Photo</p>
		</div>			
				
 
<script>
document.getElementById("filterPC").oninput=function(){
  var matcher = new RegExp(document.getElementById("filterPC").value, "gi");
  for (var i=0;i<document.getElementsByClassName("select-catpc").length;i++) {
    if (matcher.test(document.getElementsByClassName("namepc")[i].innerHTML) || matcher.test(document.getElementsByClassName("categorypc")[i].innerHTML)) {
      document.getElementsByClassName("select-catpc")[i].style.display="inline-block";
    } else {
      document.getElementsByClassName("select-catpc")[i].style.display="none";
    }
      
  }
}
</script>

<div style="clear:both;"></div></p>	


                        
                        <hr/>				
				                <?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/pc_network_profiles.php';?>				
	

	
					
		    </div>	
		</div>
	</div>	
</div>	



