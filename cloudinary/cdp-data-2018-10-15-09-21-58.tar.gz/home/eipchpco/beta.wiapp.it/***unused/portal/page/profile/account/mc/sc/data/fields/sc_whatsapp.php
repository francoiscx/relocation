<?php
$sc_whatsappArea = "sc_whatsappArea";
$sc_whatsapp = "sc_whatsapp";
$sc_whatsapp_perm = "sc_whatsapp_perm";
$sc_whatsapp_status = "sc_whatsapp_status";
?>

<!-- Start of Textfield for sc_whatsapp -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_whatsappArea: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingsc_whatsappArea = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_whatsappArea(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_whatsappArea(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_whatsappArea').donetypingsc_whatsappArea(function(){
  	var sc_whatsappArea = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_whatsappArea.php",
        method:"POST",
        data:{sc_whatsappArea:sc_whatsappArea},
        success: function(data){
      	$('#sc_whatsapp_result').html(data);
      }
    });  
});

});
</script>



<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_whatsapp: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypingsc_whatsapp = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_whatsapp(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_whatsapp(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_whatsapp').donetypingsc_whatsapp(function(){
  	var sc_whatsapp = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_whatsapp.php",
        method:"POST",
        data:{sc_whatsapp:sc_whatsapp},
        success: function(data){
      	$('#sc_whatsapp_result').html(data);
      }
    });  
});

});
</script>

<?php
$sc_whatsappArea = $_SESSION['sc_whatsappArea'];
$sc_whatsapp = $_SESSION['sc_whatsapp'];
?>

    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px"for="sc_whatsappArea"><fb-none class="icon-none" aria-hidden="true"></fb-none>Whatsapp&nbsp<span><h5 id="sc_whatsapp_result" style="float:right; color:#381A64"></h5></span></label>
	        <input class="c" type="text" id="sc_whatsappArea" name="sc_whatsappArea" value="<?php echo $sc_whatsappArea; ?>">
            <input class="n" type="text" id="sc_whatsapp" name="sc_whatsapp" value="<?php echo $sc_whatsapp; ?>">
           
<!-- End of Textfield for sc_whatsapp -->






<!-- Start of Radio Buttons for sc_whatsapp_perm -->

<script>
$(document).ready(function(){
	$('input[name="sc_whatsapp_perm"]').click(function(){
  	var sc_whatsapp_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_sc_whatsapp_perm.php",
        method:"POST",
        data:{sc_whatsapp_perm:sc_whatsapp_perm},
        success: function(data){
      	$('#sc_whatsapp_result').html(data);
      }
    });
  });
});
</script>

<?php

$sc_whatsapp_perm = $_SESSION['sc_whatsapp_perm'];
switch ($sc_whatsapp_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_whatsapp_perm_pub" name="sc_whatsapp_perm" checked="checked" value="Public">
                <label for="sc_whatsapp_perm_pub" id="sc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_whatsapp_perm_req" name="sc_whatsapp_perm" value="Request">
                <label for="sc_whatsapp_perm_req" id="sc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_whatsapp_perm_pri" name="sc_whatsapp_perm" value="Private">
                <label for="sc_whatsapp_perm_pri" id="sc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_whatsapp_perm_pub" name="sc_whatsapp_perm" value="Public">
                <label for="sc_whatsapp_perm_pub" id="sc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_whatsapp_perm_req" name="sc_whatsapp_perm" checked="checked" value="Request">
                <label for="sc_whatsapp_perm_req" id="sc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_whatsapp_perm_pri" name="sc_whatsapp_perm" value="Private">
                <label for="sc_whatsapp_perm_pri" id="sc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_whatsapp_perm_pub" name="sc_whatsapp_perm" value="Public">
                <label for="sc_whatsapp_perm_pub" id="sc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_whatsapp_perm_req" name="sc_whatsapp_perm" value="Request">
                <label for="sc_whatsapp_perm_req" id="sc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_whatsapp_perm_pri" name="sc_whatsapp_perm" checked="checked" value="Private">
                <label for="sc_whatsapp_perm_pri" id="sc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
}

?>

    </div> <!-- /field -->


<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#sc_whatsapp_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for sc_whatsapp_perm -->
