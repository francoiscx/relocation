<?php
$pc_company_incdate = "pc_company_incdate";
$pc_company_incdate_perm = "pc_company_incdate_perm";
$pc_company_incdate_status = "pc_company_incdate_status";
?>

<!-- Start of Textfield for pc_company_incdate -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_company_incdate: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_company_incdate = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_company_incdate(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_company_incdate(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_company_incdate').donetypingpc_company_incdate(function(){
  	var pc_company_incdate = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_company_incdate.php",
        method:"POST",
        data:{pc_company_incdate:pc_company_incdate},
        success: function(data){
      	$('#pc_company_incdate_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_company_incdate = $_SESSION['pc_company_incdate'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_company_incdate">Date of Incorporation&nbsp<span><h5 id="pc_company_incdate_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_company_incdate" name="pc_company_incdate" value="<?php echo $pc_company_incdate; ?>">
            
<!-- End of Textfield for pc_company_incdate -->






<!-- Start of Radio Buttons for pc_company_incdate_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_company_incdate_perm"]').click(function(){
  	var pc_company_incdate_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_company_incdate_perm.php",
        method:"POST",
        data:{pc_company_incdate_perm:pc_company_incdate_perm},
        success: function(data){
      	$('#pc_company_incdate_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_company_incdate_perm = $_SESSION['pc_company_incdate_perm'];
switch ($pc_company_incdate_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_company_incdate_perm_pub" name="pc_company_incdate_perm" checked="checked" value="Public">
                <label for="pc_company_incdate_perm_pub" id="pc_company_incdate_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_company_incdate_perm_req" name="pc_company_incdate_perm" value="Request">
                <label for="pc_company_incdate_perm_req" id="pc_company_incdate_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_company_incdate_perm_pri" name="pc_company_incdate_perm" value="Private">
                <label for="pc_company_incdate_perm_pri" id="pc_company_incdate_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_company_incdate_perm_pub" name="pc_company_incdate_perm" value="Public">
                <label for="pc_company_incdate_perm_pub" id="pc_company_incdate_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_company_incdate_perm_req" name="pc_company_incdate_perm" checked="checked" value="Request">
                <label for="pc_company_incdate_perm_req" id="pc_company_incdate_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_company_incdate_perm_pri" name="pc_company_incdate_perm" value="Private">
                <label for="pc_company_incdate_perm_pri" id="pc_company_incdate_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_company_incdate_perm_pub" name="pc_company_incdate_perm" value="Public">
                <label for="pc_company_incdate_perm_pub" id="pc_company_incdate_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_company_incdate_perm_req" name="pc_company_incdate_perm" value="Request">
                <label for="pc_company_incdate_perm_req" id="pc_company_incdate_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_company_incdate_perm_pri" name="pc_company_incdate_perm" checked="checked" value="Private">
                <label for="pc_company_incdate_perm_pri" id="pc_company_incdate_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_company_incdate_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for pc_company_incdate_perm -->
