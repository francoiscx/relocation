<?php
$gc_whatsappArea = "gc_whatsappArea";
$gc_whatsapp = "gc_whatsapp";
$gc_whatsapp_perm = "gc_whatsapp_perm";
$gc_whatsapp_status = "gc_whatsapp_status";
?>

<!-- Start of Textfield for gc_whatsapp -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_whatsappArea: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypinggc_whatsappArea = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_whatsappArea(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_whatsappArea(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_whatsappArea').donetypinggc_whatsappArea(function(){
  	var gc_whatsappArea = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_gc_whatsappArea.php",
        method:"POST",
        data:{gc_whatsappArea:gc_whatsappArea},
        success: function(data){
      	$('#gc_whatsapp_result').html(data);
      }
    });  
});

});
</script>



<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_whatsapp: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_whatsapp = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_whatsapp(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_whatsapp(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_whatsapp').donetypinggc_whatsapp(function(){
  	var gc_whatsapp = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_gc_whatsapp.php",
        method:"POST",
        data:{gc_whatsapp:gc_whatsapp},
        success: function(data){
      	$('#gc_whatsapp_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_whatsappArea = $_SESSION['gc_whatsappArea'];
$gc_whatsapp = $_SESSION['gc_whatsapp'];
?>

    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px"for="gc_whatsappArea"><fb-none class="icon-none" aria-hidden="true"></fb-none>Whatsapp&nbsp<span><h5 id="gc_whatsapp_result" style="float:right; color:#381A64"></h5></span></label>
	        <input class="c" type="text" id="gc_whatsappArea" name="gc_whatsappArea" value="<?php echo $gc_whatsappArea; ?>">
            <input class="n" type="text" id="gc_whatsapp" name="gc_whatsapp" value="<?php echo $gc_whatsapp; ?>">
           
<!-- End of Textfield for gc_whatsapp -->






<!-- Start of Radio Buttons for gc_whatsapp_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_whatsapp_perm"]').click(function(){
  	var gc_whatsapp_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_whatsapp_perm.php",
        method:"POST",
        data:{gc_whatsapp_perm:gc_whatsapp_perm},
        success: function(data){
      	$('#gc_whatsapp_result').html(data);
      }
    });
  });
});
</script>

<?php

$gc_whatsapp_perm = $_SESSION['gc_whatsapp_perm'];
switch ($gc_whatsapp_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_whatsapp_perm_pub" name="gc_whatsapp_perm" checked="checked" value="Public">
                <label for="gc_whatsapp_perm_pub" id="gc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_whatsapp_perm_req" name="gc_whatsapp_perm" value="Request">
                <label for="gc_whatsapp_perm_req" id="gc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_whatsapp_perm_pri" name="gc_whatsapp_perm" value="Private">
                <label for="gc_whatsapp_perm_pri" id="gc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_whatsapp_perm_pub" name="gc_whatsapp_perm" value="Public">
                <label for="gc_whatsapp_perm_pub" id="gc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_whatsapp_perm_req" name="gc_whatsapp_perm" checked="checked" value="Request">
                <label for="gc_whatsapp_perm_req" id="gc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_whatsapp_perm_pri" name="gc_whatsapp_perm" value="Private">
                <label for="gc_whatsapp_perm_pri" id="gc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_whatsapp_perm_pub" name="gc_whatsapp_perm" value="Public">
                <label for="gc_whatsapp_perm_pub" id="gc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_whatsapp_perm_req" name="gc_whatsapp_perm" value="Request">
                <label for="gc_whatsapp_perm_req" id="gc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_whatsapp_perm_pri" name="gc_whatsapp_perm" checked="checked" value="Private">
                <label for="gc_whatsapp_perm_pri" id="gc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
}

?>

    </div> <!-- /field -->


<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_whatsapp_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for gc_whatsapp_perm -->
