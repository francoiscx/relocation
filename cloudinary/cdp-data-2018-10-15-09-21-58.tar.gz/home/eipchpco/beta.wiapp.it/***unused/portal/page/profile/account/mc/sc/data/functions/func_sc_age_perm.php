<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$sc_age_perm = $_POST['sc_age_perm'];

//process the form if the button is clicked
if (isset($_POST['sc_age_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlsc_age_permQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlsc_age_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlsc_age_permUpdate = "UPDATE social_card SET sc_age_perm =:sc_age_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlsc_age_permUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_age_perm' => $sc_age_perm, ':userID' => $userID));

                    $sc_age_result = "Success";
                    $_SESSION['sc_age_perm'] = $sc_age_perm;
                
                 }catch (PDOException $ex){
                $sc_age_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlsc_age_permInsert = "INSERT INTO social_card (userID, sc_age_perm)
                    VALUES (:userID, :sc_age_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlsc_age_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':sc_age_perm' => $sc_age_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $sc_age_result = "Success";
                    $_SESSION['sc_age_perm'] = $sc_age_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $sc_age_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $sc_age_result
?>