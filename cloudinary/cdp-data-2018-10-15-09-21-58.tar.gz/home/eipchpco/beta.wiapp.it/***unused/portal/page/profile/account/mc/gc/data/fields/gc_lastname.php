<?php
$gc_lastname = "gc_lastname";
$gc_lastname_perm = "gc_lastname_perm";
$gc_lastname_status = "gc_lastname_status";
?>


<div  id="gc_lastname_status"></div>

<!-- Start of Textfield for gc_lastname -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_lastname: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_lastname = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_lastname(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_lastname(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_lastname').donetypinggc_lastname(function(){
  	var gc_lastname = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_lastname.php",
        method:"POST",
        data:{gc_lastname:gc_lastname},
        success: function(data){
      	$('#gc_lastname_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_lastname = $_SESSION['gc_lastname'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="gc_lastname"><fb-none class="icon-none" aria-hidden="true"></fb-none>Surname&nbsp<span><h5 id="gc_lastname_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="gc_lastname" name="gc_lastname" value="<?php echo $gc_lastname; ?>">
            
<!-- End of Textfield for gc_lastname -->






<!-- Start of Radio Buttons for gc_lastname_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_lastname_perm"]').click(function(){
  	var gc_lastname_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_lastname_perm.php",
        method:"POST",
        data:{gc_lastname_perm:gc_lastname_perm},
        success: function(data){
      	$('#gc_lastname_result').html(data);
      }
    });
  });
});
</script>





<?php

$gc_lastname_perm = $_SESSION['gc_lastname_perm'];
switch ($gc_lastname_perm) {
    case "Public":
        echo '<div class="switch-one switch-1 switch-candyone">
                <input type="radio" class="radio" id="gc_lastname_perm_pub" name="gc_lastname_perm" checked="checked" value="Public">
                <label for="gc_lastname_perm_pub" id="gc_lastname_perm_pub">Public</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-one switch-1 switch-candyone">
                <input type="radio" class="radio" id="gc_lastname_perm_pub" name="gc_lastname_perm" checked="checked" value="Public">
                <label for="gc_lastname_perm_pub" id="gc_lastname_perm_pub">Public</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_lastname_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 5e2);
</script>
</div>
<!-- End of Radio Buttons for gc_lastname_perm -->