<?php
//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

//process the form if the reset password button is clicked
if (isset($_POST['ws_street_name'])) {
    //initialize an array to store any error message from the form
    $form_errors = array();

    //check if error array is empty, if yes process form data and insert record
    if(empty($form_errors)){
        //collect form data and store in variables
        $email = $_SESSION['email'];
        
        $ws_street_name = $_POST['ws_street_name'];
        $ws_number      = $_POST['ws_number'];
        $ws_suburb      = $_POST['ws_suburb'];
        $ws_city        = $_POST['ws_city'];
        $ws_province    = $_POST['ws_province'];
        $ws_country     = $_POST['ws_country']; 
        
        	//Fields to change Case to Name
		$ws_street_name = name_field($ws_street_name);
		$ws_suburb 	= name_field($ws_suburb);		
		$ws_city 	= name_field($ws_city);
		$ws_province 	= name_field($ws_province);
		$ws_country 	= name_field($ws_country);
        
        //check if user is old enough
        if(!isset($_POST['ws_street_name'])) {
            $result = "Please provide the full information";
        }else{
            try{
                //create SQL select statement to verify if email address input exist in the database
                $sqlQuery = "SELECT email FROM users WHERE email =:email";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':email' => $email));

                //check if record exist
                if($statement->rowCount() == 1){

                    //SQL statement to update info
                    $sqlUpdate = "UPDATE users SET ws_street_name =:ws_street_name, ws_number =:ws_number, ws_suburb =:ws_suburb, ws_city =:ws_city, ws_province =:ws_province, ws_country =:ws_country WHERE email=:email";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':ws_street_name' => $ws_street_name, ':ws_number' => $ws_number, ':ws_suburb' => $ws_suburb, ':ws_city' => $ws_city, ':ws_province' => $ws_province, ':ws_country' => $ws_country, ':email' => $email));

                    $result = "Your details was successfully updated";
			if(isset($ws_street_name)) $_SESSION['ws_street_name'] = $ws_street_name;
			if(isset($ws_number))      $_SESSION['ws_number']      = $ws_number;
			if(isset($ws_suburb))      $_SESSION['ws_suburb']      = $ws_suburb;
			if(isset($ws_city))        $_SESSION['ws_city']        = $ws_city; 
			if(isset($ws_province))    $_SESSION['ws_province']    = $ws_province;	
			if(isset($ws_country))     $_SESSION['ws_country']     = $ws_ws_country;
                }
                else{
                    $result = "The email address provided does not exist in our database, please try again";
                }
            }catch (PDOException $ex){
                $result = "An error occurred: ".$ex->getMessage();
            }
        }
    }
    else{
        if(count($form_errors) == 1){
            $result = "There was 1 error in the form";
        }else{
            $result = "There were " .count($form_errors). " errors in the form";
        }
    }
}
?>
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>