<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$gc_homenumber = $_POST['gc_homenumber'];

//process the form if the button is clicked
if (isset($_POST['gc_homenumber'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE general_card SET gc_homenumber =:gc_homenumber WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_homenumber' => $gc_homenumber, ':userID' => $userID));

                    $gc_homenumber_result = "Success";
                    $_SESSION['gc_homenumber'] = $gc_homenumber;
                    
                 }catch (PDOException $ex){
                $gc_homenumber_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO general_card (userID, gc_homenumber)
                        VALUES (:userID, :gc_homenumber)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':gc_homenumber' => $gc_homenumber));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $gc_homenumber_result = "Success";
                }
   
                    $gc_homenumber_result = "Card was created";
                    
                    $_SESSION['gc_homenumber'] = $gc_homenumber;
                }
            }catch (PDOException $ex){
                $gc_homenumber_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $gc_homenumber_result
?>

