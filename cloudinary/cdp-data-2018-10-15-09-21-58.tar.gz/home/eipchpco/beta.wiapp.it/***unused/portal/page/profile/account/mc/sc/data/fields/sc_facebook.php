<?php
$sc_facebook = "sc_facebook";
$sc_facebook_perm = "sc_facebook_perm";
$sc_facebook_status = "sc_facebook_status";
?>


<div  id="sc_facebook_status"></div>

<!-- Start of Textfield for sc_facebook -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_facebook: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypingsc_facebook = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_facebook(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_facebook(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_facebook').donetypingsc_facebook(function(){
  	var sc_facebook = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_facebook.php",
        method:"POST",
        data:{sc_facebook:sc_facebook},
        success: function(data){
      	$('#sc_facebook_result').html(data);
      }
    });  
});

});
</script>

<?php
$sc_facebook = $_SESSION['sc_facebook'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="sc_facebook"><fb-facebook class="icon-facebook-square" aria-hidden="true"></fb-facebook>facebook.com/&nbsp<span><h5 id="sc_facebook_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="sc_facebook" name="sc_facebook" value="<?php echo $sc_facebook; ?>"> 
            
<!-- End of Textfield for sc_facebook -->






<!-- Start of Radio Buttons for sc_facebook_perm -->

<script>
$(document).ready(function(){
	$('input[name="sc_facebook_perm"]').click(function(){
  	var sc_facebook_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_facebook_perm.php",
        method:"POST",
        data:{sc_facebook_perm:sc_facebook_perm},
        success: function(data){
      	$('#sc_facebook_result').html(data);
      }
    });
  });
});
</script>

<?php

$sc_facebook_perm = $_SESSION['sc_facebook_perm'];
switch ($sc_facebook_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_facebook_perm_pub" name="sc_facebook_perm" checked="checked" value="Public">
                <label for="sc_facebook_perm_pub" id="sc_facebook_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_facebook_perm_req" name="sc_facebook_perm" value="Request">
                <label for="sc_facebook_perm_req" id="sc_facebook_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_facebook_perm_pri" name="sc_facebook_perm" value="Private">
                <label for="sc_facebook_perm_pri" id="sc_facebook_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_facebook_perm_pub" name="sc_facebook_perm" value="Public">
                <label for="sc_facebook_perm_pub" id="sc_facebook_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_facebook_perm_req" name="sc_facebook_perm" checked="checked" value="Request">
                <label for="sc_facebook_perm_req" id="sc_facebook_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_facebook_perm_pri" name="sc_facebook_perm" value="Private">
                <label for="sc_facebook_perm_pri" id="sc_facebook_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_facebook_perm_pub" name="sc_facebook_perm" value="Public">
                <label for="sc_facebook_perm_pub" id="sc_facebook_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_facebook_perm_req" name="sc_facebook_perm" value="Request">
                <label for="sc_facebook_perm_req" id="sc_facebook_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_facebook_perm_pri" name="sc_facebook_perm" checked="checked" value="Private">
                <label for="sc_facebook_perm_pri" id="sc_facebook_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#sc_facebook_result").text(texts[count]);
    count < 2 ? count++ : count = 0;
}
setInterval(changeText, 2e3);
</script>
</div>
<!-- End of Radio Buttons for sc_facebook_perm -->