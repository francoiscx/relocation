<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$sc_pinterest_status = $_POST['sc_pinterest_status'];

//process the form if the button is clicked
if (isset($_POST['sc_pinterest_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlsc_pinterest_statusQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlsc_pinterest_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlsc_pinterest_statusUpdate = "UPDATE social_card SET sc_pinterest_status =:sc_pinterest_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlsc_pinterest_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_pinterest_status' => $sc_pinterest_status, ':userID' => $userID));

                    $sc_pinterest_status_result = 'sc_pinterest_status';
                    $_SESSION['sc_pinterest_status'] = $sc_pinterest_status;
                
                 }catch (PDOException $ex){
                $sc_pinterest_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlsc_pinterest_statusInsert = "INSERT INTO social_card (userID, sc_pinterest_status)
                    VALUES (:userID, :sc_pinterest_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlsc_pinterest_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':sc_pinterest_status' => $sc_pinterest_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $sc_pinterest_status_result = 'sc_pinterest_status';
                    $_SESSION['sc_pinterest_status'] = $sc_pinterest_status;
	    	        }
                }
            }catch (PDOException $ex){
                $sc_pinterest_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($sc_pinterest_status == sc_pinterestactive) echo "sc_pinterestactive";
 else if ($sc_pinterest_status != sc_pinterestactive) echo "sc_pinterestpassive";

?>