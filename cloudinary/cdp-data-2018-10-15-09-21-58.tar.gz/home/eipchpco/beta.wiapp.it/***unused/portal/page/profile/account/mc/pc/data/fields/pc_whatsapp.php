<?php
$pc_whatsapp = "pc_whatsapp";
$pc_whatsapp_perm = "pc_whatsapp_perm";
$pc_whatsapp_status = "pc_whatsapp_status";
?>

<!-- Start of Textfield for pc_whatsapp -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_whatsapp: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_whatsapp = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_whatsapp(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_whatsapp(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_whatsapp').donetypingpc_whatsapp(function(){
  	var pc_whatsapp = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_whatsapp.php",
        method:"POST",
        data:{pc_whatsapp:pc_whatsapp},
        success: function(data){
      	$('#pc_whatsapp_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_whatsapp = $_SESSION['pc_whatsapp'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_whatsapp">Whatsapp Number&nbsp<span><h5 id="pc_whatsapp_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_whatsapp" name="pc_whatsapp" value="<?php echo $pc_whatsapp; ?>">
            
<!-- End of Textfield for pc_whatsapp -->






<!-- Start of Radio Buttons for pc_whatsapp_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_whatsapp_perm"]').click(function(){
  	var pc_whatsapp_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_whatsapp_perm.php",
        method:"POST",
        data:{pc_whatsapp_perm:pc_whatsapp_perm},
        success: function(data){
      	$('#pc_whatsapp_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_whatsapp_perm = $_SESSION['pc_whatsapp_perm'];
switch ($pc_whatsapp_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_whatsapp_perm_pub" name="pc_whatsapp_perm" checked="checked" value="Public">
                <label for="pc_whatsapp_perm_pub" id="pc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_whatsapp_perm_req" name="pc_whatsapp_perm" value="Request">
                <label for="pc_whatsapp_perm_req" id="pc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_whatsapp_perm_pri" name="pc_whatsapp_perm" value="Private">
                <label for="pc_whatsapp_perm_pri" id="pc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_whatsapp_perm_pub" name="pc_whatsapp_perm" value="Public">
                <label for="pc_whatsapp_perm_pub" id="pc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_whatsapp_perm_req" name="pc_whatsapp_perm" checked="checked" value="Request">
                <label for="pc_whatsapp_perm_req" id="pc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_whatsapp_perm_pri" name="pc_whatsapp_perm" value="Private">
                <label for="pc_whatsapp_perm_pri" id="pc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_whatsapp_perm_pub" name="pc_whatsapp_perm" value="Public">
                <label for="pc_whatsapp_perm_pub" id="pc_whatsapp_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_whatsapp_perm_req" name="pc_whatsapp_perm" value="Request">
                <label for="pc_whatsapp_perm_req" id="pc_whatsapp_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_whatsapp_perm_pri" name="pc_whatsapp_perm" checked="checked" value="Private">
                <label for="pc_whatsapp_perm_pri" id="pc_whatsapp_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_whatsapp_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for pc_whatsapp_perm -->
