<!-- Start of Radio Buttons for gc_cell_status -->
<div class="groupl">

<?php

$gc_cell_status = $_SESSION['gc_cell_status'];

if(!isset($gc_cell_status)) {$gc_cell_status = 'gc_cellpassive'; }



//echo $gc_cell_status;

switch ($gc_cell_status) {
    case "gc_cellactive":
        echo "
<div>

    <div class='gc_cell_selection' id='gc_cellactive'>
    <a class='gc_cell_selectionSwitch' href='#gc_cellpassive'><input type='radio' id='gc_cell_status_on' name='gc_cell_status' value='gc_cellpassive' hidden> 
    <label for='gc_cell_status_on' class='gc_cell_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Cell
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_cell_selection' id='gc_cellpassive'>
    <a class='gc_cell_selectionSwitch' href='#gc_cellactive'><input type='radio' id='gc_cell_status_off' name='gc_cell_status' value='gc_cellactive' hidden>
    <label for='gc_cell_status_off' class='gc_cell_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Cell
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_cell_status').on('click', function () {
        check = $('#gc_cell_status').prop('checked');
        
        if (check) {
            if ($('.gc_cell_Check i').hasClass('icon-check-square')) {
                $('.gc_cell_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_cell_Check i').hasClass('icon-square-o')) {
                $('.gc_cell_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_cell_status = $('#gc_cellactive, #gc_cellpassive').hide();
$('#gc_cellactive').show();
$('#gc_cellpassive').hide();
$('.gc_cell_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_cell_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_cellpassive":
        echo "
<div>

  <div class='gc_cell_selection' id='gc_cellpassive'>
    <a class='gc_cell_selectionSwitch' href='#gc_cellactive'><input type='radio' id='gc_cell_status_off' name='gc_cell_status' value='gc_cellactive' hidden>
    <label for='gc_cell_status_off' class='gc_cell_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Cell
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_cell_selection' id='gc_cellactive'>
    <a class='gc_cell_selectionSwitch' href='#gc_cellpassive'><input type='radio' id='gc_cell_status_on' name='gc_cell_status' value='gc_cellpassive' hidden>
    <label for='gc_cell_status_on' class='gc_cell_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Cell
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_cell_status').on('click', function () {
        check = $('#gc_cell_status').prop('checked');
        
        if (check) {
            if ($('.gc_cell_Check i').hasClass('icon-square-o')) {
                $('.gc_cell_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_cell_Check i').hasClass('icon-check-square')) {
                $('.gc_cell_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_cell_status = $('#gc_cellactive, #gc_cellpassive').hide();
$('#gc_cellactive').hide();
$('#gc_cellpassive').show();
$('.gc_cell_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_cell_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_cell_selection' id='gc_cellpassive'>
    <a class='gc_cell_selectionSwitch' href='#gc_cellactive'><input type='radio' id='gc_cell_status_off' name='gc_cell_status' value='gc_cellactive' hidden>
    <label for='gc_cell_status_off' class='gc_cell_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Cell
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_cell_selection' id='gc_cellactive'>
    <a class='gc_cell_selectionSwitch' href='#gc_cellpassive'><input type='radio' id='gc_cell_status_on' name='gc_cell_status' value='gc_cellpassive' hidden>
    <label for='gc_cell_status_on' class='gc_cell_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Cell
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_cell_status').on('click', function () {
        check = $('#gc_cell_status').prop('checked');
        
        if (check) {
            if ($('.gc_cell_Check i').hasClass('icon-square-o')) {
                $('.gc_cell_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_cell_Check i').hasClass('icon-check-square')) {
                $('.gc_cell_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_cell_status = $('#gc_cellactive, #gc_cellpassive').hide();
$('#gc_cellactive').hide();
$('#gc_cellpassive').show();
$('.gc_cell_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_cell_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>