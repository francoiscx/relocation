<?php
$pc_flickr = "pc_flickr";
$pc_flickr_perm = "pc_flickr_perm";
$pc_flickr_status = "pc_flickr_status";
?>


<div  id="pc_flickr_status"></div>

<!-- Start of Textfield for pc_flickr -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_flickr: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_flickr = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_flickr(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_flickr(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_flickr').donetypingpc_flickr(function(){
  	var pc_flickr = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_flickr.php",
        method:"POST",
        data:{pc_flickr:pc_flickr},
        success: function(data){
      	$('#pc_flickr_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_flickr = $_SESSION['pc_flickr'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="pc_flickr"><fb-flickr class="icon-flickr" aria-hidden="true"></fb-flickr>flickr.com/photos/&nbsp<span><h5 id="pc_flickr_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_flickr" name="pc_flickr" value="<?php echo $pc_flickr; ?>">
            
<!-- End of Textfield for pc_flickr -->






<!-- Start of Radio Buttons for pc_flickr_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_flickr_perm"]').click(function(){
  	var pc_flickr_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_flickr_perm.php",
        method:"POST",
        data:{pc_flickr_perm:pc_flickr_perm},
        success: function(data){
      	$('#pc_flickr_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_flickr_perm = $_SESSION['pc_flickr_perm'];
switch ($pc_flickr_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_flickr_perm_pub" name="pc_flickr_perm" checked="checked" value="Public">
                <label for="pc_flickr_perm_pub" id="pc_flickr_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_flickr_perm_req" name="pc_flickr_perm" value="Request">
                <label for="pc_flickr_perm_req" id="pc_flickr_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_flickr_perm_pri" name="pc_flickr_perm" value="Private">
                <label for="pc_flickr_perm_pri" id="pc_flickr_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_flickr_perm_pub" name="pc_flickr_perm" value="Public">
                <label for="pc_flickr_perm_pub" id="pc_flickr_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_flickr_perm_req" name="pc_flickr_perm" checked="checked" value="Request">
                <label for="pc_flickr_perm_req" id="pc_flickr_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_flickr_perm_pri" name="pc_flickr_perm" value="Private">
                <label for="pc_flickr_perm_pri" id="pc_flickr_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_flickr_perm_pub" name="pc_flickr_perm" value="Public">
                <label for="pc_flickr_perm_pub" id="pc_flickr_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_flickr_perm_req" name="pc_flickr_perm" value="Request">
                <label for="pc_flickr_perm_req" id="pc_flickr_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_flickr_perm_pri" name="pc_flickr_perm" checked="checked" value="Private">
                <label for="pc_flickr_perm_pri" id="pc_flickr_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_flickr_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 300);
</script>
</div>
<!-- End of Radio Buttons for pc_flickr_perm -->