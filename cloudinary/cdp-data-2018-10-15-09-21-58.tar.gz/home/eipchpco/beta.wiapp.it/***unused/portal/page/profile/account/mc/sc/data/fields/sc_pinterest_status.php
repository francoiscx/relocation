<!-- Start of Radio Buttons for sc_pinterest_status -->
<div class="groupl">

<?php

$sc_pinterest_status = $_SESSION['sc_pinterest_status'];

if(!isset($sc_pinterest_status)) {$sc_pinterest_status = 'sc_pinterestpassive'; }



//echo $sc_pinterest_status;

switch ($sc_pinterest_status) {
    case "sc_pinterestactive":
        echo "
<div>

    <div class='sc_pinterest_selection' id='sc_pinterestactive'>
    <a class='sc_pinterest_selectionSwitch' href='#sc_pinterestpassive'><input type='radio' id='sc_pinterest_status_on' name='sc_pinterest_status' value='sc_pinterestpassive' hidden> 
    <label for='sc_pinterest_status_on' class='sc_pinterest_Check'>
     <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='sc_pinterest_selection' id='sc_pinterestpassive'>
    <a class='sc_pinterest_selectionSwitch' href='#sc_pinterestactive'><input type='radio' id='sc_pinterest_status_off' name='sc_pinterest_status' value='sc_pinterestactive' hidden>
    <label for='sc_pinterest_status_off' class='sc_pinterest_Check'>
    <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#sc_pinterest_status').on('click', function () {
        check = $('#sc_pinterest_status').prop('checked');
        
        if (check) {
            if ($('.sc_pinterest_Check i').hasClass('icon-check-square')) {
                $('.sc_pinterest_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.sc_pinterest_Check i').hasClass('icon-square-o')) {
                $('.sc_pinterest_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_pinterest_status = $('#sc_pinterestactive, #sc_pinterestpassive').hide();
$('#sc_pinterestactive').show();
$('#sc_pinterestpassive').hide();
$('.sc_pinterest_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_pinterest_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "sc_pinterestpassive":
        echo "
<div>

  <div class='sc_pinterest_selection' id='sc_pinterestpassive'>
    <a class='sc_pinterest_selectionSwitch' href='#sc_pinterestactive'><input type='radio' id='sc_pinterest_status_off' name='sc_pinterest_status' value='sc_pinterestactive' hidden>
    <label for='sc_pinterest_status_off' class='sc_pinterest_Check'>
    <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='sc_pinterest_selection' id='sc_pinterestactive'>
    <a class='sc_pinterest_selectionSwitch' href='#sc_pinterestpassive'><input type='radio' id='sc_pinterest_status_on' name='sc_pinterest_status' value='sc_pinterestpassive' hidden>
    <label for='sc_pinterest_status_on' class='sc_pinterest_Check'>
     <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#sc_pinterest_status').on('click', function () {
        check = $('#sc_pinterest_status').prop('checked');
        
        if (check) {
            if ($('.sc_pinterest_Check i').hasClass('icon-square-o')) {
                $('.sc_pinterest_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.sc_pinterest_Check i').hasClass('icon-check-square')) {
                $('.sc_pinterest_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_pinterest_status = $('#sc_pinterestactive, #sc_pinterestpassive').hide();
$('#sc_pinterestactive').hide();
$('#sc_pinterestpassive').show();
$('.sc_pinterest_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_pinterest_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='sc_pinterest_selection' id='sc_pinterestpassive'>
    <a class='sc_pinterest_selectionSwitch' href='#sc_pinterestactive'><input type='radio' id='sc_pinterest_status_off' name='sc_pinterest_status' value='sc_pinterestactive' hidden>
    <label for='sc_pinterest_status_off' class='sc_pinterest_Check'>
    <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='sc_pinterest_selection' id='sc_pinterestactive'>
    <a class='sc_pinterest_selectionSwitch' href='#sc_pinterestpassive'><input type='radio' id='sc_pinterest_status_on' name='sc_pinterest_status' value='sc_pinterestpassive' hidden>
    <label for='sc_pinterest_status_on' class='sc_pinterest_Check'>
     <fa-pinterest class='icon-pinterest-square' aria-hidden='true'></fa-pinterest>Pinterest
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#sc_pinterest_status').on('click', function () {
        check = $('#sc_pinterest_status').prop('checked');
        
        if (check) {
            if ($('.sc_pinterest_Check i').hasClass('icon-square-o')) {
                $('.sc_pinterest_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.sc_pinterest_Check i').hasClass('icon-check-square')) {
                $('.sc_pinterest_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_pinterest_status = $('#sc_pinterestactive, #sc_pinterestpassive').hide();
$('#sc_pinterestactive').hide();
$('#sc_pinterestpassive').show();
$('.sc_pinterest_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_pinterest_status.hide();
    $(href).show();
})
});
</script>


";
}


?>


</div>