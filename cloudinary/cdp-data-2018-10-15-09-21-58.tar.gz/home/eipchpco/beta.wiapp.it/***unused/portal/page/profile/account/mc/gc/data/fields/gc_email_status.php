<!-- Start of Radio Buttons for gc_email_status -->
<div class="groupl">

<?php

$gc_email_status = $_SESSION['gc_email_status'];

if(!isset($gc_email_status)) {$gc_email_status = 'gc_emailpassive'; }



//echo $gc_email_status;

switch ($gc_email_status) {
    case "gc_emailactive":
        echo "
<div>

    <div class='gc_email_selection' id='gc_emailactive'>
    <a class='gc_email_selectionSwitch' href='#gc_emailpassive'><input type='radio' id='gc_email_status_on' name='gc_email_status' value='gc_emailpassive' hidden> 
    <label for='gc_email_status_on' class='gc_email_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Email
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_email_selection' id='gc_emailpassive'>
    <a class='gc_email_selectionSwitch' href='#gc_emailactive'><input type='radio' id='gc_email_status_off' name='gc_email_status' value='gc_emailactive' hidden>
    <label for='gc_email_status_off' class='gc_email_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Email
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_email_status').on('click', function () {
        check = $('#gc_email_status').prop('checked');
        
        if (check) {
            if ($('.gc_email_Check i').hasClass('icon-check-square')) {
                $('.gc_email_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_email_Check i').hasClass('icon-square-o')) {
                $('.gc_email_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_email_status = $('#gc_emailactive, #gc_emailpassive').hide();
$('#gc_emailactive').show();
$('#gc_emailpassive').hide();
$('.gc_email_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_email_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_emailpassive":
        echo "
<div>

  <div class='gc_email_selection' id='gc_emailpassive'>
    <a class='gc_email_selectionSwitch' href='#gc_emailactive'><input type='radio' id='gc_email_status_off' name='gc_email_status' value='gc_emailactive' hidden>
    <label for='gc_email_status_off' class='gc_email_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Email
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_email_selection' id='gc_emailactive'>
    <a class='gc_email_selectionSwitch' href='#gc_emailpassive'><input type='radio' id='gc_email_status_on' name='gc_email_status' value='gc_emailpassive' hidden>
    <label for='gc_email_status_on' class='gc_email_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Email
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_email_status').on('click', function () {
        check = $('#gc_email_status').prop('checked');
        
        if (check) {
            if ($('.gc_email_Check i').hasClass('icon-square-o')) {
                $('.gc_email_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_email_Check i').hasClass('icon-check-square')) {
                $('.gc_email_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_email_status = $('#gc_emailactive, #gc_emailpassive').hide();
$('#gc_emailactive').hide();
$('#gc_emailpassive').show();
$('.gc_email_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_email_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_email_selection' id='gc_emailpassive'>
    <a class='gc_email_selectionSwitch' href='#gc_emailactive'><input type='radio' id='gc_email_status_off' name='gc_email_status' value='gc_emailactive' hidden>
    <label for='gc_email_status_off' class='gc_email_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Email
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_email_selection' id='gc_emailactive'>
    <a class='gc_email_selectionSwitch' href='#gc_emailpassive'><input type='radio' id='gc_email_status_on' name='gc_email_status' value='gc_emailpassive' hidden>
    <label for='gc_email_status_on' class='gc_email_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Email
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_email_status').on('click', function () {
        check = $('#gc_email_status').prop('checked');
        
        if (check) {
            if ($('.gc_email_Check i').hasClass('icon-square-o')) {
                $('.gc_email_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_email_Check i').hasClass('icon-check-square')) {
                $('.gc_email_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_email_status = $('#gc_emailactive, #gc_emailpassive').hide();
$('#gc_emailactive').hide();
$('#gc_emailpassive').show();
$('.gc_email_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_email_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>