<?php
$gc_homenumberArea = "gc_homenumberArea";
$gc_homenumber = "gc_homenumber";
$gc_homenumber_perm = "gc_homenumber_perm";
$gc_homenumber_status = "gc_homenumber_status";
?>

<!-- Start of Textfield for gc_homenumber -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_homenumberArea: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypinggc_homenumberArea = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_homenumberArea(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_homenumberArea(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_homenumberArea').donetypinggc_homenumberArea(function(){
  	var gc_homenumberArea = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_gc_homenumberArea.php",
        method:"POST",
        data:{gc_homenumberArea:gc_homenumberArea},
        success: function(data){
      	$('#gc_homenumber_result').html(data);
      }
    });  
});

});
</script>



<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_homenumber: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_homenumber = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_homenumber(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_homenumber(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_homenumber').donetypinggc_homenumber(function(){
  	var gc_homenumber = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_gc_homenumber.php",
        method:"POST",
        data:{gc_homenumber:gc_homenumber},
        success: function(data){
      	$('#gc_homenumber_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_homenumberArea = $_SESSION['gc_homenumberArea'];
$gc_homenumber = $_SESSION['gc_homenumber'];
?>

    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px"for="gc_homenumberArea"><fb-none class="icon-none" aria-hidden="true"></fb-none>Landline&nbsp<span><h5 id="gc_homenumber_result" style="float:right; color:#381A64"></h5></span></label>
	        <input class="c" type="text" id="gc_homenumberArea" name="gc_homenumberArea" value="<?php echo $gc_homenumberArea; ?>">
            <input class="n" type="text" id="gc_homenumber" name="gc_homenumber" value="<?php echo $gc_homenumber; ?>">
           
<!-- End of Textfield for gc_homenumber -->






<!-- Start of Radio Buttons for gc_homenumber_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_homenumber_perm"]').click(function(){
  	var gc_homenumber_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_homenumber_perm.php",
        method:"POST",
        data:{gc_homenumber_perm:gc_homenumber_perm},
        success: function(data){
      	$('#gc_homenumber_result').html(data);
      }
    });
  });
});
</script>

<?php

$gc_homenumber_perm = $_SESSION['gc_homenumber_perm'];
switch ($gc_homenumber_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_homenumber_perm_pub" name="gc_homenumber_perm" checked="checked" value="Public">
                <label for="gc_homenumber_perm_pub" id="gc_homenumber_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_homenumber_perm_req" name="gc_homenumber_perm" value="Request">
                <label for="gc_homenumber_perm_req" id="gc_homenumber_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_homenumber_perm_pri" name="gc_homenumber_perm" value="Private">
                <label for="gc_homenumber_perm_pri" id="gc_homenumber_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_homenumber_perm_pub" name="gc_homenumber_perm" value="Public">
                <label for="gc_homenumber_perm_pub" id="gc_homenumber_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_homenumber_perm_req" name="gc_homenumber_perm" checked="checked" value="Request">
                <label for="gc_homenumber_perm_req" id="gc_homenumber_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_homenumber_perm_pri" name="gc_homenumber_perm" value="Private">
                <label for="gc_homenumber_perm_pri" id="gc_homenumber_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_homenumber_perm_pub" name="gc_homenumber_perm" value="Public">
                <label for="gc_homenumber_perm_pub" id="gc_homenumber_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_homenumber_perm_req" name="gc_homenumber_perm" value="Request">
                <label for="gc_homenumber_perm_req" id="gc_homenumber_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_homenumber_perm_pri" name="gc_homenumber_perm" checked="checked" value="Private">
                <label for="gc_homenumber_perm_pri" id="gc_homenumber_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
}

?>

    </div> <!-- /field -->


<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_homenumber_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for gc_homenumber_perm -->
