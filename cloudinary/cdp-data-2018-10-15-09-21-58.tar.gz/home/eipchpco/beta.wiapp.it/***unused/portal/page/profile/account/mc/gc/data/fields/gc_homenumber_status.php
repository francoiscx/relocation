<!-- Start of Radio Buttons for gc_homenumber_status -->
<div class="groupl">

<?php

$gc_homenumber_status = $_SESSION['gc_homenumber_status'];

if(!isset($gc_homenumber_status)) {$gc_homenumber_status = 'gc_homenumberpassive'; }



//echo $gc_homenumber_status;

switch ($gc_homenumber_status) {
    case "gc_homenumberactive":
        echo "
<div>

    <div class='gc_homenumber_selection' id='gc_homenumberactive'>
    <a class='gc_homenumber_selectionSwitch' href='#gc_homenumberpassive'><input type='radio' id='gc_homenumber_status_on' name='gc_homenumber_status' value='gc_homenumberpassive' hidden> 
    <label for='gc_homenumber_status_on' class='gc_homenumber_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Landline
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_homenumber_selection' id='gc_homenumberpassive'>
    <a class='gc_homenumber_selectionSwitch' href='#gc_homenumberactive'><input type='radio' id='gc_homenumber_status_off' name='gc_homenumber_status' value='gc_homenumberactive' hidden>
    <label for='gc_homenumber_status_off' class='gc_homenumber_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Landline
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_homenumber_status').on('click', function () {
        check = $('#gc_homenumber_status').prop('checked');
        
        if (check) {
            if ($('.gc_homenumber_Check i').hasClass('icon-check-square')) {
                $('.gc_homenumber_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_homenumber_Check i').hasClass('icon-square-o')) {
                $('.gc_homenumber_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_homenumber_status = $('#gc_homenumberactive, #gc_homenumberpassive').hide();
$('#gc_homenumberactive').show();
$('#gc_homenumberpassive').hide();
$('.gc_homenumber_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_homenumber_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_homenumberpassive":
        echo "
<div>

  <div class='gc_homenumber_selection' id='gc_homenumberpassive'>
    <a class='gc_homenumber_selectionSwitch' href='#gc_homenumberactive'><input type='radio' id='gc_homenumber_status_off' name='gc_homenumber_status' value='gc_homenumberactive' hidden>
    <label for='gc_homenumber_status_off' class='gc_homenumber_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Landline
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_homenumber_selection' id='gc_homenumberactive'>
    <a class='gc_homenumber_selectionSwitch' href='#gc_homenumberpassive'><input type='radio' id='gc_homenumber_status_on' name='gc_homenumber_status' value='gc_homenumberpassive' hidden>
    <label for='gc_homenumber_status_on' class='gc_homenumber_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Landline
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_homenumber_status').on('click', function () {
        check = $('#gc_homenumber_status').prop('checked');
        
        if (check) {
            if ($('.gc_homenumber_Check i').hasClass('icon-square-o')) {
                $('.gc_homenumber_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_homenumber_Check i').hasClass('icon-check-square')) {
                $('.gc_homenumber_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_homenumber_status = $('#gc_homenumberactive, #gc_homenumberpassive').hide();
$('#gc_homenumberactive').hide();
$('#gc_homenumberpassive').show();
$('.gc_homenumber_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_homenumber_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_homenumber_selection' id='gc_homenumberpassive'>
    <a class='gc_homenumber_selectionSwitch' href='#gc_homenumberactive'><input type='radio' id='gc_homenumber_status_off' name='gc_homenumber_status' value='gc_homenumberactive' hidden>
    <label for='gc_homenumber_status_off' class='gc_homenumber_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Landline
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_homenumber_selection' id='gc_homenumberactive'>
    <a class='gc_homenumber_selectionSwitch' href='#gc_homenumberpassive'><input type='radio' id='gc_homenumber_status_on' name='gc_homenumber_status' value='gc_homenumberpassive' hidden>
    <label for='gc_homenumber_status_on' class='gc_homenumber_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Landline
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_homenumber_status').on('click', function () {
        check = $('#gc_homenumber_status').prop('checked');
        
        if (check) {
            if ($('.gc_homenumber_Check i').hasClass('icon-square-o')) {
                $('.gc_homenumber_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_homenumber_Check i').hasClass('icon-check-square')) {
                $('.gc_homenumber_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_homenumber_status = $('#gc_homenumberactive, #gc_homenumberpassive').hide();
$('#gc_homenumberactive').hide();
$('#gc_homenumberpassive').show();
$('.gc_homenumber_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_homenumber_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>