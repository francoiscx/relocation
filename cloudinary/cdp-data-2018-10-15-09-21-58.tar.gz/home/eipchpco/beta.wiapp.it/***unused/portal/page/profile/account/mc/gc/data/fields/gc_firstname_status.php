<!-- Start of Radio Buttons for gc_firstname_status -->
<div class="groupl">

<?php

$gc_firstname_status = $_SESSION['gc_firstname_status'];

if(!isset($gc_firstname_status)) {$gc_firstname_status = 'gc_firstnamepassive'; }



//echo $gc_firstname_status;

switch ($gc_firstname_status) {
    case "gc_firstnameactive":
        echo "
<div>

    <div class='gc_firstname_selection' id='gc_firstnameactive'>
    <a class='gc_firstname_selectionSwitch' href='#gc_firstnamepassive'><input type='radio' id='gc_firstname_status_on' name='gc_firstname_status' value='gc_firstnamepassive' hidden> 
    <label for='gc_firstname_status_on' class='gc_firstname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>First name
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_firstname_selection' id='gc_firstnamepassive'>
    <a class='gc_firstname_selectionSwitch' href='#gc_firstnameactive'><input type='radio' id='gc_firstname_status_off' name='gc_firstname_status' value='gc_firstnameactive' hidden>
    <label for='gc_firstname_status_off' class='gc_firstname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>First name
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_firstname_status').on('click', function () {
        check = $('#gc_firstname_status').prop('checked');
        
        if (check) {
            if ($('.gc_firstname_Check i').hasClass('icon-check-square')) {
                $('.gc_firstname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_firstname_Check i').hasClass('icon-square-o')) {
                $('.gc_firstname_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_firstname_status = $('#gc_firstnameactive, #gc_firstnamepassive').hide();
$('#gc_firstnameactive').show();
$('#gc_firstnamepassive').hide();
$('.gc_firstname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_firstname_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_firstnamepassive":
        echo "
<div>

  <div class='gc_firstname_selection' id='gc_firstnamepassive'>
    <a class='gc_firstname_selectionSwitch' href='#gc_firstnameactive'><input type='radio' id='gc_firstname_status_off' name='gc_firstname_status' value='gc_firstnameactive' hidden>
    <label for='gc_firstname_status_off' class='gc_firstname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>First name
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_firstname_selection' id='gc_firstnameactive'>
    <a class='gc_firstname_selectionSwitch' href='#gc_firstnamepassive'><input type='radio' id='gc_firstname_status_on' name='gc_firstname_status' value='gc_firstnamepassive' hidden>
    <label for='gc_firstname_status_on' class='gc_firstname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>First name
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_firstname_status').on('click', function () {
        check = $('#gc_firstname_status').prop('checked');
        
        if (check) {
            if ($('.gc_firstname_Check i').hasClass('icon-square-o')) {
                $('.gc_firstname_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_firstname_Check i').hasClass('icon-check-square')) {
                $('.gc_firstname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_firstname_status = $('#gc_firstnameactive, #gc_firstnamepassive').hide();
$('#gc_firstnameactive').hide();
$('#gc_firstnamepassive').show();
$('.gc_firstname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_firstname_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_firstname_selection' id='gc_firstnamepassive'>
    <a class='gc_firstname_selectionSwitch' href='#gc_firstnameactive'><input type='radio' id='gc_firstname_status_off' name='gc_firstname_status' value='gc_firstnameactive' hidden>
    <label for='gc_firstname_status_off' class='gc_firstname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>First name
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_firstname_selection' id='gc_firstnameactive'>
    <a class='gc_firstname_selectionSwitch' href='#gc_firstnamepassive'><input type='radio' id='gc_firstname_status_on' name='gc_firstname_status' value='gc_firstnamepassive' hidden>
    <label for='gc_firstname_status_on' class='gc_firstname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>First name
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_firstname_status').on('click', function () {
        check = $('#gc_firstname_status').prop('checked');
        
        if (check) {
            if ($('.gc_firstname_Check i').hasClass('icon-square-o')) {
                $('.gc_firstname_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_firstname_Check i').hasClass('icon-check-square')) {
                $('.gc_firstname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_firstname_status = $('#gc_firstnameactive, #gc_firstnamepassive').hide();
$('#gc_firstnameactive').hide();
$('#gc_firstnamepassive').show();
$('.gc_firstname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_firstname_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>