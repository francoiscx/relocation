<!-- Start of Radio Buttons for pc_company_facebook_status -->
<div class="groupl">

<?php

$pc_company_facebook_status = $_SESSION['pc_company_facebook_status'];

if(!isset($pc_company_facebook_status)) {$pc_company_facebook_status = 'pc_company_facebookpassive'; }



//echo $pc_company_facebook_status;

switch ($pc_company_facebook_status) {
    case "pc_company_facebookactive":
        echo "
<div>

    <div class='pc_company_facebook_selection' id='pc_company_facebookactive'>
    <a class='pc_company_facebook_selectionSwitch' href='#pc_company_facebookpassive'><input type='radio' id='pc_company_facebook_status_on' name='pc_company_facebook_status' value='pc_company_facebookpassive' hidden> 
    <label for='pc_company_facebook_status_on' class='pc_company_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_company_facebook_selection' id='pc_company_facebookpassive'>
    <a class='pc_company_facebook_selectionSwitch' href='#pc_company_facebookactive'><input type='radio' id='pc_company_facebook_status_off' name='pc_company_facebook_status' value='pc_company_facebookactive' hidden>
    <label for='pc_company_facebook_status_off' class='pc_company_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_facebook_status').on('click', function () {
        check = $('#pc_company_facebook_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_facebook_Check i').hasClass('icon-check-square')) {
                $('.pc_company_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_company_facebook_Check i').hasClass('icon-square-o')) {
                $('.pc_company_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_facebook_status = $('#pc_company_facebookactive, #pc_company_facebookpassive').hide();
$('#pc_company_facebookactive').show();
$('#pc_company_facebookpassive').hide();
$('.pc_company_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_facebook_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_company_facebookpassive":
        echo "
<div>

  <div class='pc_company_facebook_selection' id='pc_company_facebookpassive'>
    <a class='pc_company_facebook_selectionSwitch' href='#pc_company_facebookactive'><input type='radio' id='pc_company_facebook_status_off' name='pc_company_facebook_status' value='pc_company_facebookactive' hidden>
    <label for='pc_company_facebook_status_off' class='pc_company_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_company_facebook_selection' id='pc_company_facebookactive'>
    <a class='pc_company_facebook_selectionSwitch' href='#pc_company_facebookpassive'><input type='radio' id='pc_company_facebook_status_on' name='pc_company_facebook_status' value='pc_company_facebookpassive' hidden>
    <label for='pc_company_facebook_status_on' class='pc_company_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_facebook_status').on('click', function () {
        check = $('#pc_company_facebook_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_facebook_Check i').hasClass('icon-square-o')) {
                $('.pc_company_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_company_facebook_Check i').hasClass('icon-check-square')) {
                $('.pc_company_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_facebook_status = $('#pc_company_facebookactive, #pc_company_facebookpassive').hide();
$('#pc_company_facebookactive').hide();
$('#pc_company_facebookpassive').show();
$('.pc_company_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_facebook_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_company_facebook_selection' id='pc_company_facebookpassive'>
    <a class='pc_company_facebook_selectionSwitch' href='#pc_company_facebookactive'><input type='radio' id='pc_company_facebook_status_off' name='pc_company_facebook_status' value='pc_company_facebookactive' hidden>
    <label for='pc_company_facebook_status_off' class='pc_company_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_company_facebook_selection' id='pc_company_facebookactive'>
    <a class='pc_company_facebook_selectionSwitch' href='#pc_company_facebookpassive'><input type='radio' id='pc_company_facebook_status_on' name='pc_company_facebook_status' value='pc_company_facebookpassive' hidden>
    <label for='pc_company_facebook_status_on' class='pc_company_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_company_facebook_status').on('click', function () {
        check = $('#pc_company_facebook_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_facebook_Check i').hasClass('icon-square-o')) {
                $('.pc_company_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_company_facebook_Check i').hasClass('icon-check-square')) {
                $('.pc_company_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_facebook_status = $('#pc_company_facebookactive, #pc_company_facebookpassive').hide();
$('#pc_company_facebookactive').hide();
$('#pc_company_facebookpassive').show();
$('.pc_company_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_facebook_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>