<!-- Start of Radio Buttons for pc_company_googleP_status -->
<div class="groupl">

<?php

$pc_company_googleP_status = $_SESSION['pc_company_googleP_status'];

if(!isset($pc_company_googleP_status)) {$pc_company_googleP_status = 'pc_company_googlePpassive'; }



//echo $pc_company_googleP_status;

switch ($pc_company_googleP_status) {
    case "pc_company_googlePactive":
        echo "
<div>

    <div class='pc_company_googleP_selection' id='pc_company_googlePactive'>
    <a class='pc_company_googleP_selectionSwitch' href='#pc_company_googlePpassive'><input type='radio' id='pc_company_googleP_status_on' name='pc_company_googleP_status' value='pc_company_googlePpassive' hidden> 
    <label for='pc_company_googleP_status_on' class='pc_company_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_company_googleP_selection' id='pc_company_googlePpassive'>
    <a class='pc_company_googleP_selectionSwitch' href='#pc_company_googlePactive'><input type='radio' id='pc_company_googleP_status_off' name='pc_company_googleP_status' value='pc_company_googlePactive' hidden>
    <label for='pc_company_googleP_status_off' class='pc_company_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_googleP_status').on('click', function () {
        check = $('#pc_company_googleP_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_googleP_Check i').hasClass('icon-check-square')) {
                $('.pc_company_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_company_googleP_Check i').hasClass('icon-square-o')) {
                $('.pc_company_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_googleP_status = $('#pc_company_googlePactive, #pc_company_googlePpassive').hide();
$('#pc_company_googlePactive').show();
$('#pc_company_googlePpassive').hide();
$('.pc_company_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_googleP_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_company_googlePpassive":
        echo "
<div>

  <div class='pc_company_googleP_selection' id='pc_company_googlePpassive'>
    <a class='pc_company_googleP_selectionSwitch' href='#pc_company_googlePactive'><input type='radio' id='pc_company_googleP_status_off' name='pc_company_googleP_status' value='pc_company_googlePactive' hidden>
    <label for='pc_company_googleP_status_off' class='pc_company_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_company_googleP_selection' id='pc_company_googlePactive'>
    <a class='pc_company_googleP_selectionSwitch' href='#pc_company_googlePpassive'><input type='radio' id='pc_company_googleP_status_on' name='pc_company_googleP_status' value='pc_company_googlePpassive' hidden>
    <label for='pc_company_googleP_status_on' class='pc_company_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_googleP_status').on('click', function () {
        check = $('#pc_company_googleP_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_googleP_Check i').hasClass('icon-square-o')) {
                $('.pc_company_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_company_googleP_Check i').hasClass('icon-check-square')) {
                $('.pc_company_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_googleP_status = $('#pc_company_googlePactive, #pc_company_googlePpassive').hide();
$('#pc_company_googlePactive').hide();
$('#pc_company_googlePpassive').show();
$('.pc_company_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_googleP_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_company_googleP_selection' id='pc_company_googlePpassive'>
    <a class='pc_company_googleP_selectionSwitch' href='#pc_company_googlePactive'><input type='radio' id='pc_company_googleP_status_off' name='pc_company_googleP_status' value='pc_company_googlePactive' hidden>
    <label for='pc_company_googleP_status_off' class='pc_company_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_company_googleP_selection' id='pc_company_googlePactive'>
    <a class='pc_company_googleP_selectionSwitch' href='#pc_company_googlePpassive'><input type='radio' id='pc_company_googleP_status_on' name='pc_company_googleP_status' value='pc_company_googlePpassive' hidden>
    <label for='pc_company_googleP_status_on' class='pc_company_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_company_googleP_status').on('click', function () {
        check = $('#pc_company_googleP_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_googleP_Check i').hasClass('icon-square-o')) {
                $('.pc_company_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_company_googleP_Check i').hasClass('icon-check-square')) {
                $('.pc_company_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_googleP_status = $('#pc_company_googlePactive, #pc_company_googlePpassive').hide();
$('#pc_company_googlePactive').hide();
$('#pc_company_googlePpassive').show();
$('.pc_company_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_googleP_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>