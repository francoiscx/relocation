<?php
$pc_pa = "pc_pa";
$pc_pa_perm = "pc_pa_perm";
$pc_pa_status = "pc_pa_status";
?>

<!-- Start of Textfield for pc_pa -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_pa: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_pa = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_pa(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_pa(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_pa').donetypingpc_pa(function(){
  	var pc_pa = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_pa.php",
        method:"POST",
        data:{pc_pa:pc_pa},
        success: function(data){
      	$('#pc_pa_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_pa = $_SESSION['pc_pa'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_pa">Personal Assistant&nbsp<span><h5 id="pc_pa_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_pa" name="pc_pa" value="<?php echo $pc_pa; ?>">
            
<!-- End of Textfield for pc_pa -->






<!-- Start of Radio Buttons for pc_pa_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_pa_perm"]').click(function(){
  	var pc_pa_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_pa_perm.php",
        method:"POST",
        data:{pc_pa_perm:pc_pa_perm},
        success: function(data){
      	$('#pc_pa_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_pa_perm = $_SESSION['pc_pa_perm'];
switch ($pc_pa_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_pa_perm_pub" name="pc_pa_perm" checked="checked" value="Public">
                <label for="pc_pa_perm_pub" id="pc_pa_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_pa_perm_req" name="pc_pa_perm" value="Request">
                <label for="pc_pa_perm_req" id="pc_pa_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_pa_perm_pri" name="pc_pa_perm" value="Private">
                <label for="pc_pa_perm_pri" id="pc_pa_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_pa_perm_pub" name="pc_pa_perm" value="Public">
                <label for="pc_pa_perm_pub" id="pc_pa_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_pa_perm_req" name="pc_pa_perm" checked="checked" value="Request">
                <label for="pc_pa_perm_req" id="pc_pa_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_pa_perm_pri" name="pc_pa_perm" value="Private">
                <label for="pc_pa_perm_pri" id="pc_pa_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_pa_perm_pub" name="pc_pa_perm" value="Public">
                <label for="pc_pa_perm_pub" id="pc_pa_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_pa_perm_req" name="pc_pa_perm" value="Request">
                <label for="pc_pa_perm_req" id="pc_pa_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_pa_perm_pri" name="pc_pa_perm" checked="checked" value="Private">
                <label for="pc_pa_perm_pri" id="pc_pa_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_pa_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for pc_pa_perm -->
