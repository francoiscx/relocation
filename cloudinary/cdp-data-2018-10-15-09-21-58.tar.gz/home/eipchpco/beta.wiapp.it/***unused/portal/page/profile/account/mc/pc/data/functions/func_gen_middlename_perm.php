<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gen_middlename_perm = $_POST['gen_middlename_perm'];

//process the form if the button is clicked
if (isset($_POST['gen_middlename_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlgen_middlename_permQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgen_middlename_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgen_middlename_permUpdate = "UPDATE professional_card SET gen_middlename_perm =:gen_middlename_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgen_middlename_permUpdate);

                    //execute the statement
                    $statement->execute(array(':gen_middlename_perm' => $gen_middlename_perm, ':userID' => $userID));

                    $gen_middlename_result = "Update Successful";
                    $_SESSION['gen_middlename_perm'] = $gen_middlename_perm;
                
                 }catch (PDOException $ex){
                $gen_middlename_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlgen_middlename_permInsert = "INSERT INTO professional_card (userID, gen_middlename_perm)
                    VALUES (:userID, :gen_middlename_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgen_middlename_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gen_middlename_perm' => $gen_middlename_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gen_middlename_result = "Card created";
                    $_SESSION['gen_middlename_perm'] = $gen_middlename_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $gen_middlename_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $gen_middlename_result
?>