<p class="help-block">To easily build your Wi-CARDS provide your information.</p>

<form action="/portal/page/profile/account/mc/gl/data/func_about_me.php" method="post" class="ajax">	

	<div>	

		<div class="groupl">
			<div>											
			<label style="font-size:13px">First Name</label>
			<input type="text" id="u_first_name" name="u_first_name" value="<?php echo $_SESSION['first_name']; ?>" placeholder="First Name" required>				
			</div> 
			<div>											
			<label style="font-size:13px">Middle Name(s)</label>
			<input type="text" id="u_middle_name" name="u_middle_name" value="<?php echo $_SESSION['middle_name']; ?>" placeholder="Middle Name(s) if applicable">				
			</div>																			
			<div>											
			<label style="font-size:13px">Last Name</label>
			<input type="text" id="u_last_name" name="u_last_name" value="<?php echo $_SESSION['last_name']; ?>" placeholder="Last Name" required>
			</div>
		</div>										

		<div class="groupl">				
			<div>											
			<label style="font-size:13px">Email Address</label>
			<input type="text" id="email" name="email" value="<?php echo $_SESSION['email']; ?>" placeholder="Email" disabled>
			</div>					
			<div>
			<label style="font-size:13px">Cell</label>
			<input type="text" id="Cell" name="Cell" value="<?php echo $_SESSION['cell']; ?>" required placeholder="Cell" required>
			</div>						
		</div>
										
		<div class="groupl">
			<div>
			<label style="font-size:13px">Date of Birth</label>
			<input id="dob" name="dob" name="Date of Birth" value="<?php echo $_SESSION['dob']; ?>" disabled>
			</div>
		</div>											
	
		<div class="groupl">						
			<div>
  			<label style="font-size:13px">Gender</label>
    			<select name="u_gender" id="u_gender" type="text" required>
   			<option value="<?php if(isset($_SESSION['gender'])) echo $_SESSION['gender'];
						else echo '';
						?>">
				       <?php if(isset($_SESSION['gender'])) echo $_SESSION['gender'];
						else echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp--- Please select ---";?></option>  												
      			<option value="Male">Male</option>
      			<option value="Female">Female</option>
    			</select>   										
  			</div>
  											 
			<div>
  			<label style="font-size:13px">Relationship Status</label>
    			<select name="u_status" id="u_status" type="text">
      			<option value="<?php if(isset($_SESSION['status'])) echo $_SESSION['status'];
      						else echo '';
      						?>">
      					<?php if(isset($_SESSION['status'])) echo $_SESSION['status'];
						else echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp--- Please select ---";?></option>
			<option value="Not Interested">Not Interested</option>
      			<option value="Single">Single</option>     												
      			<option value="Dating">Dating</option>
      			<option value="In Relationship">In Relationship</option>
      			<option value="Engaged">Engaged</option>
      			<option value="Married">Married</option>
      			<option value="Divorced">Divorced</option>
    			</select>
		</div> 
		
	</form>	

 	    </div>	    
 	            <div class="col-sm-10">
					<div class="groupBtn">
       						<input type="submit" value="Save" class="button btn btn-primary btn-medium" float="right">	
					</div>	
				</div>
													

 