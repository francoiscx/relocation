<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$sc_flickr_status = $_POST['sc_flickr_status'];

//process the form if the button is clicked
if (isset($_POST['sc_flickr_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlsc_flickr_statusQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlsc_flickr_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlsc_flickr_statusUpdate = "UPDATE social_card SET sc_flickr_status =:sc_flickr_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlsc_flickr_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_flickr_status' => $sc_flickr_status, ':userID' => $userID));

                    $sc_flickr_status_result = '$sc_flickr_status';
                    $_SESSION['sc_flickr_status'] = $sc_flickr_status;
                
                 }catch (PDOException $ex){
                $sc_flickr_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlsc_flickr_statusInsert = "INSERT INTO social_card (userID, sc_flickr_status)
                    VALUES (:userID, :sc_flickr_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlsc_flickr_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':sc_flickr_status' => $sc_flickr_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $sc_flickr_status_result = '$sc_flickr_status';
                    $_SESSION['sc_flickr_status'] = $sc_flickr_status;
	    	        }
                }
            }catch (PDOException $ex){
                $sc_flickr_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($sc_flickr_status == sc_flickractive) echo "sc_flickractive";
 else if ($sc_flickr_status != sc_flickractive) echo "sc_flickrpassive";

?>