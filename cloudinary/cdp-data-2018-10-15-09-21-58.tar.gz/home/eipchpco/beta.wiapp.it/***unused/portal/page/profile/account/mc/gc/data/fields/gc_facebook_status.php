<!-- Start of Radio Buttons for gc_facebook_status -->
<div class="groupl">

<?php

$gc_facebook_status = $_SESSION['gc_facebook_status'];

if(!isset($gc_facebook_status)) {$gc_facebook_status = 'gc_facebookpassive'; }



//echo $gc_facebook_status;

switch ($gc_facebook_status) {
    case "gc_facebookactive":
        echo "
<div>

    <div class='gc_facebook_selection' id='gc_facebookactive'>
    <a class='gc_facebook_selectionSwitch' href='#gc_facebookpassive'><input type='radio' id='gc_facebook_status_on' name='gc_facebook_status' value='gc_facebookpassive' hidden> 
    <label for='gc_facebook_status_on' class='gc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_facebook_selection' id='gc_facebookpassive'>
    <a class='gc_facebook_selectionSwitch' href='#gc_facebookactive'><input type='radio' id='gc_facebook_status_off' name='gc_facebook_status' value='gc_facebookactive' hidden>
    <label for='gc_facebook_status_off' class='gc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_facebook_status').on('click', function () {
        check = $('#gc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.gc_facebook_Check i').hasClass('icon-check-square')) {
                $('.gc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_facebook_Check i').hasClass('icon-square-o')) {
                $('.gc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_facebook_status = $('#gc_facebookactive, #gc_facebookpassive').hide();
$('#gc_facebookactive').show();
$('#gc_facebookpassive').hide();
$('.gc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_facebook_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_facebookpassive":
        echo "
<div>

  <div class='gc_facebook_selection' id='gc_facebookpassive'>
    <a class='gc_facebook_selectionSwitch' href='#gc_facebookactive'><input type='radio' id='gc_facebook_status_off' name='gc_facebook_status' value='gc_facebookactive' hidden>
    <label for='gc_facebook_status_off' class='gc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_facebook_selection' id='gc_facebookactive'>
    <a class='gc_facebook_selectionSwitch' href='#gc_facebookpassive'><input type='radio' id='gc_facebook_status_on' name='gc_facebook_status' value='gc_facebookpassive' hidden>
    <label for='gc_facebook_status_on' class='gc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_facebook_status').on('click', function () {
        check = $('#gc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.gc_facebook_Check i').hasClass('icon-square-o')) {
                $('.gc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_facebook_Check i').hasClass('icon-check-square')) {
                $('.gc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_facebook_status = $('#gc_facebookactive, #gc_facebookpassive').hide();
$('#gc_facebookactive').hide();
$('#gc_facebookpassive').show();
$('.gc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_facebook_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_facebook_selection' id='gc_facebookpassive'>
    <a class='gc_facebook_selectionSwitch' href='#gc_facebookactive'><input type='radio' id='gc_facebook_status_off' name='gc_facebook_status' value='gc_facebookactive' hidden>
    <label for='gc_facebook_status_off' class='gc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_facebook_selection' id='gc_facebookactive'>
    <a class='gc_facebook_selectionSwitch' href='#gc_facebookpassive'><input type='radio' id='gc_facebook_status_on' name='gc_facebook_status' value='gc_facebookpassive' hidden>
    <label for='gc_facebook_status_on' class='gc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_facebook_status').on('click', function () {
        check = $('#gc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.gc_facebook_Check i').hasClass('icon-square-o')) {
                $('.gc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_facebook_Check i').hasClass('icon-check-square')) {
                $('.gc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_facebook_status = $('#gc_facebookactive, #gc_facebookpassive').hide();
$('#gc_facebookactive').hide();
$('#gc_facebookpassive').show();
$('.gc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_facebook_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>