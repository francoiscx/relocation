<!-- Start of Radio Buttons for sc_youtube_status -->
<div class="groupl">

<?php

$sc_youtube_status = $_SESSION['sc_youtube_status'];

if(!isset($sc_youtube_status)) {$sc_youtube_status = 'sc_youtubepassive'; }



//echo $sc_youtube_status;

switch ($sc_youtube_status) {
    case "sc_youtubeactive":
        echo "
<div>

    <div class='sc_youtube_selection' id='sc_youtubeactive'>
    <a class='sc_youtube_selectionSwitch' href='#sc_youtubepassive'><input type='radio' id='sc_youtube_status_on' name='sc_youtube_status' value='sc_youtubepassive' hidden> 
    <label for='sc_youtube_status_on' class='sc_youtube_Check'>
     <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='sc_youtube_selection' id='sc_youtubepassive'>
    <a class='sc_youtube_selectionSwitch' href='#sc_youtubeactive'><input type='radio' id='sc_youtube_status_off' name='sc_youtube_status' value='sc_youtubeactive' hidden>
    <label for='sc_youtube_status_off' class='sc_youtube_Check'>
    <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#sc_youtube_status').on('click', function () {
        check = $('#sc_youtube_status').prop('checked');
        
        if (check) {
            if ($('.sc_youtube_Check i').hasClass('icon-check-square')) {
                $('.sc_youtube_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.sc_youtube_Check i').hasClass('icon-square-o')) {
                $('.sc_youtube_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_youtube_status = $('#sc_youtubeactive, #sc_youtubepassive').hide();
$('#sc_youtubeactive').show();
$('#sc_youtubepassive').hide();
$('.sc_youtube_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_youtube_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "sc_youtubepassive":
        echo "
<div>

  <div class='sc_youtube_selection' id='sc_youtubepassive'>
    <a class='sc_youtube_selectionSwitch' href='#sc_youtubeactive'><input type='radio' id='sc_youtube_status_off' name='sc_youtube_status' value='sc_youtubeactive' hidden>
    <label for='sc_youtube_status_off' class='sc_youtube_Check'>
    <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='sc_youtube_selection' id='sc_youtubeactive'>
    <a class='sc_youtube_selectionSwitch' href='#sc_youtubepassive'><input type='radio' id='sc_youtube_status_on' name='sc_youtube_status' value='sc_youtubepassive' hidden>
    <label for='sc_youtube_status_on' class='sc_youtube_Check'>
     <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#sc_youtube_status').on('click', function () {
        check = $('#sc_youtube_status').prop('checked');
        
        if (check) {
            if ($('.sc_youtube_Check i').hasClass('icon-square-o')) {
                $('.sc_youtube_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.sc_youtube_Check i').hasClass('icon-check-square')) {
                $('.sc_youtube_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_youtube_status = $('#sc_youtubeactive, #sc_youtubepassive').hide();
$('#sc_youtubeactive').hide();
$('#sc_youtubepassive').show();
$('.sc_youtube_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_youtube_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='sc_youtube_selection' id='sc_youtubepassive'>
    <a class='sc_youtube_selectionSwitch' href='#sc_youtubeactive'><input type='radio' id='sc_youtube_status_off' name='sc_youtube_status' value='sc_youtubeactive' hidden>
    <label for='sc_youtube_status_off' class='sc_youtube_Check'>
    <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='sc_youtube_selection' id='sc_youtubeactive'>
    <a class='sc_youtube_selectionSwitch' href='#sc_youtubepassive'><input type='radio' id='sc_youtube_status_on' name='sc_youtube_status' value='sc_youtubepassive' hidden>
    <label for='sc_youtube_status_on' class='sc_youtube_Check'>
     <fa-youtube class='icon-youtube-square' aria-hidden='true'></fa-youtube>YouTube
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#sc_youtube_status').on('click', function () {
        check = $('#sc_youtube_status').prop('checked');
        
        if (check) {
            if ($('.sc_youtube_Check i').hasClass('icon-square-o')) {
                $('.sc_youtube_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.sc_youtube_Check i').hasClass('icon-check-square')) {
                $('.sc_youtube_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_youtube_status = $('#sc_youtubeactive, #sc_youtubepassive').hide();
$('#sc_youtubeactive').hide();
$('#sc_youtubepassive').show();
$('.sc_youtube_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_youtube_status.hide();
    $(href).show();
})
});
</script>


";
}


?>














</div>