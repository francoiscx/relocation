<!-- Start of Radio Buttons for gc_age_status -->
<div class="groupl">

<?php

$gc_age_status = $_SESSION['gc_age_status'];

if(!isset($gc_age_status)) {$gc_age_status = 'gc_agepassive'; }



//echo $gc_age_status;

switch ($gc_age_status) {
    case "gc_ageactive":
        echo "
<div>

    <div class='gc_age_selection' id='gc_ageactive'>
    <a class='gc_age_selectionSwitch' href='#gc_agepassive'><input type='radio' id='gc_age_status_on' name='gc_age_status' value='gc_agepassive' hidden> 
    <label for='gc_age_status_on' class='gc_age_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Age
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_age_selection' id='gc_agepassive'>
    <a class='gc_age_selectionSwitch' href='#gc_ageactive'><input type='radio' id='gc_age_status_off' name='gc_age_status' value='gc_ageactive' hidden>
    <label for='gc_age_status_off' class='gc_age_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Age
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_age_status').on('click', function () {
        check = $('#gc_age_status').prop('checked');
        
        if (check) {
            if ($('.gc_age_Check i').hasClass('icon-check-square')) {
                $('.gc_age_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_age_Check i').hasClass('icon-square-o')) {
                $('.gc_age_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_age_status = $('#gc_ageactive, #gc_agepassive').hide();
$('#gc_ageactive').show();
$('#gc_agepassive').hide();
$('.gc_age_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_age_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_agepassive":
        echo "
<div>

  <div class='gc_age_selection' id='gc_agepassive'>
    <a class='gc_age_selectionSwitch' href='#gc_ageactive'><input type='radio' id='gc_age_status_off' name='gc_age_status' value='gc_ageactive' hidden>
    <label for='gc_age_status_off' class='gc_age_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Age
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_age_selection' id='gc_ageactive'>
    <a class='gc_age_selectionSwitch' href='#gc_agepassive'><input type='radio' id='gc_age_status_on' name='gc_age_status' value='gc_agepassive' hidden>
    <label for='gc_age_status_on' class='gc_age_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Age
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_age_status').on('click', function () {
        check = $('#gc_age_status').prop('checked');
        
        if (check) {
            if ($('.gc_age_Check i').hasClass('icon-square-o')) {
                $('.gc_age_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_age_Check i').hasClass('icon-check-square')) {
                $('.gc_age_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_age_status = $('#gc_ageactive, #gc_agepassive').hide();
$('#gc_ageactive').hide();
$('#gc_agepassive').show();
$('.gc_age_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_age_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_age_selection' id='gc_agepassive'>
    <a class='gc_age_selectionSwitch' href='#gc_ageactive'><input type='radio' id='gc_age_status_off' name='gc_age_status' value='gc_ageactive' hidden>
    <label for='gc_age_status_off' class='gc_age_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Age
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_age_selection' id='gc_ageactive'>
    <a class='gc_age_selectionSwitch' href='#gc_agepassive'><input type='radio' id='gc_age_status_on' name='gc_age_status' value='gc_agepassive' hidden>
    <label for='gc_age_status_on' class='gc_age_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Age
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_age_status').on('click', function () {
        check = $('#gc_age_status').prop('checked');
        
        if (check) {
            if ($('.gc_age_Check i').hasClass('icon-square-o')) {
                $('.gc_age_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_age_Check i').hasClass('icon-check-square')) {
                $('.gc_age_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_age_status = $('#gc_ageactive, #gc_agepassive').hide();
$('#gc_ageactive').hide();
$('#gc_agepassive').show();
$('.gc_age_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_age_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>