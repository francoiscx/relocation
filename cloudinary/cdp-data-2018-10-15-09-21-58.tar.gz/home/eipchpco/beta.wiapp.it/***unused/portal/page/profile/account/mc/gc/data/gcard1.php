
<div class="card1container">
      <div class="card">
        <figure class="front">
          <img src="http://www.jboeijenga.nl/img/front.jpg" alt="front">
          <div class="caption">
            <h2>john <span>doe</span></h2>
            <p>Web Developer</p>
          </div>			
        </figure>
       </div>
       
       <div class="card">
        <figure class="back">
           <img src="http://www.jboeijenga.nl/img/back.jpg" alt="back">
            <div class="caption">
              <dl>
                <dt>Phone</dt>
                <dd>012 345 6789</dd>
                <dt>Email</dt>
                <dd>johndoe@gmail.com</dd>
                <dt>Web</dt>
                <dd>www.johndoe.com</dd>
              </dl>
            </div>
        </figure>
      </div>
    </div>

<script>
    $('.card').click(function(){
  $(this).toggleClass('flipped');
});
</script>