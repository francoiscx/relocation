<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gc_firstname_status = $_POST['gc_firstname_status'];

//process the form if the button is clicked
if (isset($_POST['gc_firstname_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlgc_firstname_statusQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgc_firstname_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgc_firstname_statusUpdate = "UPDATE general_card SET gc_firstname_status =:gc_firstname_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgc_firstname_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_firstname_status' => $gc_firstname_status, ':userID' => $userID));

                    $gc_firstname_status_result = 'gc_firstname_status';
                    $_SESSION['gc_firstname_status'] = $gc_firstname_status;
                
                 }catch (PDOException $ex){
                $gc_firstname_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlgc_firstname_statusInsert = "INSERT INTO general_card (userID, gc_firstname_status)
                    VALUES (:userID, :gc_firstname_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgc_firstname_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gc_firstname_status' => $gc_firstname_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gc_firstname_status_result = 'gc_firstname_status';
                    $_SESSION['gc_firstname_status'] = $gc_firstname_status;
	    	        }
                }
            }catch (PDOException $ex){
                $gc_firstname_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($gc_firstname_status == gc_firstnameactive) echo "gc_firstnameactive";
 else if ($gc_firstname_status != gc_firstnameactive) echo "gc_firstnamepassive";

?>