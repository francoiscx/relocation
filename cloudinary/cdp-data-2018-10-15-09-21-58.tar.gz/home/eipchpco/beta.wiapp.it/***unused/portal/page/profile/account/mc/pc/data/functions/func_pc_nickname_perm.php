<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$pc_nickname_perm = $_POST['pc_nickname_perm'];

//process the form if the button is clicked
if (isset($_POST['pc_nickname_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlpc_nickname_permQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlpc_nickname_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlpc_nickname_permUpdate = "UPDATE professional_card SET pc_nickname_perm =:pc_nickname_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlpc_nickname_permUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_nickname_perm' => $pc_nickname_perm, ':userID' => $userID));

                    $pc_nickname_result = "Update Successful";
                    $_SESSION['pc_nickname_perm'] = $pc_nickname_perm;
                
                 }catch (PDOException $ex){
                $pc_nickname_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlpc_nickname_permInsert = "INSERT INTO professional_card (userID, pc_nickname_perm)
                    VALUES (:userID, :pc_nickname_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlpc_nickname_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':pc_nickname_perm' => $pc_nickname_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $pc_nickname_result = "Card created";
                    $_SESSION['pc_nickname_perm'] = $pc_nickname_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $pc_nickname_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $pc_nickname_result
?>