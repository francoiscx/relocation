<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$sc_cell_perm = $_POST['sc_cell_perm'];

//process the form if the button is clicked
if (isset($_POST['sc_cell_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlsc_cell_permQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlsc_cell_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlsc_cell_permUpdate = "UPDATE social_card SET sc_cell_perm =:sc_cell_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlsc_cell_permUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_cell_perm' => $sc_cell_perm, ':userID' => $userID));

                    $sc_cell_result = "Success";
                    $_SESSION['sc_cell_perm'] = $sc_cell_perm;
                
                 }catch (PDOException $ex){
                $sc_cell_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlsc_cell_permInsert = "INSERT INTO social_card (userID, sc_cell_perm)
                    VALUES (:userID, :sc_cell_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlsc_cell_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':sc_cell_perm' => $sc_cell_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $sc_cell_result = "Success";
                    $_SESSION['sc_cell_perm'] = $sc_cell_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $sc_cell_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $sc_cell_result
?>