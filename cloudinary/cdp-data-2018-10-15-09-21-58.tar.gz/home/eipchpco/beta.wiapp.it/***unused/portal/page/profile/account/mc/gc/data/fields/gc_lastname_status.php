<!-- Start of Radio Buttons for gc_lastname_status -->
<div class="groupl">

<?php

$gc_lastname_status = $_SESSION['gc_lastname_status'];

if(!isset($gc_lastname_status)) {$gc_lastname_status = 'gc_lastnamepassive'; }



//echo $gc_lastname_status;

switch ($gc_lastname_status) {
    case "gc_lastnameactive":
        echo "
<div>

    <div class='gc_lastname_selection' id='gc_lastnameactive'>
    <a class='gc_lastname_selectionSwitch' href='#gc_lastnamepassive'><input type='radio' id='gc_lastname_status_on' name='gc_lastname_status' value='gc_lastnamepassive' hidden> 
    <label for='gc_lastname_status_on' class='gc_lastname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Surname
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_lastname_selection' id='gc_lastnamepassive'>
    <a class='gc_lastname_selectionSwitch' href='#gc_lastnameactive'><input type='radio' id='gc_lastname_status_off' name='gc_lastname_status' value='gc_lastnameactive' hidden>
    <label for='gc_lastname_status_off' class='gc_lastname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Surname
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_lastname_status').on('click', function () {
        check = $('#gc_lastname_status').prop('checked');
        
        if (check) {
            if ($('.gc_lastname_Check i').hasClass('icon-check-square')) {
                $('.gc_lastname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_lastname_Check i').hasClass('icon-square-o')) {
                $('.gc_lastname_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_lastname_status = $('#gc_lastnameactive, #gc_lastnamepassive').hide();
$('#gc_lastnameactive').show();
$('#gc_lastnamepassive').hide();
$('.gc_lastname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_lastname_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_lastnamepassive":
        echo "
<div>

  <div class='gc_lastname_selection' id='gc_lastnamepassive'>
    <a class='gc_lastname_selectionSwitch' href='#gc_lastnameactive'><input type='radio' id='gc_lastname_status_off' name='gc_lastname_status' value='gc_lastnameactive' hidden>
    <label for='gc_lastname_status_off' class='gc_lastname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Surname
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_lastname_selection' id='gc_lastnameactive'>
    <a class='gc_lastname_selectionSwitch' href='#gc_lastnamepassive'><input type='radio' id='gc_lastname_status_on' name='gc_lastname_status' value='gc_lastnamepassive' hidden>
    <label for='gc_lastname_status_on' class='gc_lastname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Surname
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_lastname_status').on('click', function () {
        check = $('#gc_lastname_status').prop('checked');
        
        if (check) {
            if ($('.gc_lastname_Check i').hasClass('icon-square-o')) {
                $('.gc_lastname_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_lastname_Check i').hasClass('icon-check-square')) {
                $('.gc_lastname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_lastname_status = $('#gc_lastnameactive, #gc_lastnamepassive').hide();
$('#gc_lastnameactive').hide();
$('#gc_lastnamepassive').show();
$('.gc_lastname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_lastname_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_lastname_selection' id='gc_lastnamepassive'>
    <a class='gc_lastname_selectionSwitch' href='#gc_lastnameactive'><input type='radio' id='gc_lastname_status_off' name='gc_lastname_status' value='gc_lastnameactive' hidden>
    <label for='gc_lastname_status_off' class='gc_lastname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Surname
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_lastname_selection' id='gc_lastnameactive'>
    <a class='gc_lastname_selectionSwitch' href='#gc_lastnamepassive'><input type='radio' id='gc_lastname_status_on' name='gc_lastname_status' value='gc_lastnamepassive' hidden>
    <label for='gc_lastname_status_on' class='gc_lastname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Surname
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_lastname_status').on('click', function () {
        check = $('#gc_lastname_status').prop('checked');
        
        if (check) {
            if ($('.gc_lastname_Check i').hasClass('icon-square-o')) {
                $('.gc_lastname_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_lastname_Check i').hasClass('icon-check-square')) {
                $('.gc_lastname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_lastname_status = $('#gc_lastnameactive, #gc_lastnamepassive').hide();
$('#gc_lastnameactive').hide();
$('#gc_lastnamepassive').show();
$('.gc_lastname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_lastname_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>