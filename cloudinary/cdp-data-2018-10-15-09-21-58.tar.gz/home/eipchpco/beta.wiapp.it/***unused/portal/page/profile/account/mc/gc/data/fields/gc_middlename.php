<?php
$gc_middlename = $_SESSION["gc_middlename"];
$gc_middlename_fs = $_SESSION["gc_middlename_fs"];
$gc_middlename_fsz = $_SESSION["gc_middlename_fsz"];
$gc_middlename_perm = $_SESSION["gc_middlename_perm"];
$gc_middlename_status = $_SESSION["gc_middlename_status"];

if($gc_middlename_fs > 0 && $gc_middlename_fs < 26){
$gc_middlename_fsz = '16px';

}elseif($gc_middlename_fs > 25 && $gc_middlename_fs < 32){
$gc_middlename_fsz = '14px';

}elseif($gc_middlename_fs > 31 && $gc_middlename_fs < 38){
$gc_middlename_fsz = '12px';

}elseif($gc_middlename_fs > 37 && $gc_middlename_fs < 45){
$gc_middlename_fsz = '10px';

}elseif($gc_middlename_fs > 34 && $gc_middlename_fs < 100){
$gc_middlename_fsz = '8px';

}else{
$gc_middlename_fsz = '16px';
}
?>




<div  id="gc_middlename_status"></div>

<!-- Start of Textfield for gc_middlename -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_middlename: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_middlename = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_middlename(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_middlename(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_middlename').donetypinggc_middlename(function(){
  	var gc_middlename = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_middlename.php",
        method:"POST",
        data:{gc_middlename:gc_middlename},
        success: function(data){
      	$('#gc_middlename_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_middlename = $_SESSION['gc_middlename'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="gc_middlename"><fb-none class="icon-none" aria-hidden="true"></fb-none>Middlename(s)<span><h5 id="gc_middlename_result" style="float:right; color:#381A64;"></h5></span></label>
            <input type="text" id="gc_middlename" name="gc_middlename" value="<?php echo $gc_middlename; ?>" style="font-size:<?php echo $gc_middlename_fsz;?>">
            
<!-- End of Textfield for gc_middlename -->






<!-- Start of Radio Buttons for gc_middlename_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_middlename_perm"]').click(function(){
  	var gc_middlename_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_middlename_perm.php",
        method:"POST",
        data:{gc_middlename_perm:gc_middlename_perm},
        success: function(data){
      	$('#gc_middlename_result').html(data);
      }
    });
  });
});
</script>

<?php

$gc_middlename_perm = $_SESSION['gc_middlename_perm'];
switch ($gc_middlename_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_middlename_perm_pub" name="gc_middlename_perm" checked="checked" value="Public">
                <label for="gc_middlename_perm_pub" id="gc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_middlename_perm_req" name="gc_middlename_perm" value="Request">
                <label for="gc_middlename_perm_req" id="gc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_middlename_perm_pri" name="gc_middlename_perm" value="Private">
                <label for="gc_middlename_perm_pri" id="gc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_middlename_perm_pub" name="gc_middlename_perm" value="Public">
                <label for="gc_middlename_perm_pub" id="gc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_middlename_perm_req" name="gc_middlename_perm" checked="checked" value="Request">
                <label for="gc_middlename_perm_req" id="gc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_middlename_perm_pri" name="gc_middlename_perm" value="Private">
                <label for="gc_middlename_perm_pri" id="gc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_middlename_perm_pub" name="gc_middlename_perm" value="Public">
                <label for="gc_middlename_perm_pub" id="gc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_middlename_perm_req" name="gc_middlename_perm" value="Request">
                <label for="gc_middlename_perm_req" id="gc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_middlename_perm_pri" name="gc_middlename_perm" checked="checked" value="Private">
                <label for="gc_middlename_perm_pri" id="gc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>




<script>
$('#gc_middlename').on('keyup', function(e) {
    var gc_middlename_fs = $(this),
        textLength = gc_middlename_fs.val().length
    ;
    if(textLength > 46) {
        gc_middlename_fs.css('font-size', '8px');    
    }else if(textLength > 39) {
        gc_middlename_fs.css('font-size', '10px');
    } else if(textLength > 33) {
        gc_middlename_fs.css('font-size', '12px');
    } else if(textLength > 27) {
        gc_middlename_fs.css('font-size', '14px');
    } else {gc_middlename_fs.css('font-size', '16px');
    }
    
        var gc_middlename_fs = gc_middlename_fs.val().length
        $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_middlename_fs.php",
        method:"POST",
        data:{gc_middlename_fs:gc_middlename_fs},
        success: function(data){
      	$('#gc_middlename_result').html(data);
      }
    });
});
</script>

<!-- End of Radio Buttons for gc_middlename_perm -->



<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_middlename_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 4e2);
</script>
</div>