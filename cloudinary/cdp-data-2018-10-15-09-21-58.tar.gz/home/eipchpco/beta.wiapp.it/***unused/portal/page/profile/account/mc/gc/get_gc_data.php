<?php
$userID = $_SESSION['id'];



//check if user has completed QuickStart (general info)
	$sqlQuery = "SELECT quickStart FROM users WHERE id = :userID";
	$statement = $db->prepare($sqlQuery);
	$statement->execute(array(':userID' => $userID));

    if(!isset($_row['quickStart'])) $result = "<h4 style='color: #381A64; border solid gray;'>" . $username . ", this Quick Start session will help you get familiar with how to create your Cards.</h4>";

//if user has not yet satisfacturaly completed QuickStart (general info) display what was provided.
$sqlQuery = "SELECT * FROM general_card WHERE userID = :userID";
	$statement = $db->prepare($sqlQuery);
	$statement->execute(array(':userID' => $userID));
	
	if(!isset($_row['gcID'])) $result = "<h4 style='color: #381A64; border solid gray;'>" . $username . " Start creating your Personal Card by filling in more fields.</h4>";
	
	while($row = $statement->fetch()){
		$gcID = $row['gcID'];
		$hashed_password = $row['password'];
		$user_email = $row['email'];
	
		
			if(isset($row['defaultVerification'])) $defaultVerification = $row['defaultVerification'];
			$_SESSION['defaultVerification'] = $defaultVerification;
			
			if(isset($row['first_name'])) $first_name = $row['first_name'];
			if(isset($row['middle_name'])) $middle_name = $row['middle_name'];
			if(isset($row['last_name'])) $last_name = $row['last_name'];





	$sqlQuery = "SELECT * FROM general_card WHERE userID = :userID";
	$statement = $db->prepare($sqlQuery);
	$statement->execute(array(':userID' => $userID));
	
	if(!isset($_row['gcID'])) $result = "<h4 style='color: #381A64; border solid gray;'>" . $username . " Start creating your Personal Card by filling in more fields.</h4>";
	
	while($row = $statement->fetch()){
		$gcID = $row['gcID'];
		$hashed_password = $row['password'];
		$user_email = $row['email'];
	
		
			if(isset($row['defaultVerification'])) $defaultVerification = $row['defaultVerification'];
			$_SESSION['defaultVerification'] = $defaultVerification;
			
			if(isset($row['first_name'])) $first_name = $row['first_name'];
			if(isset($row['middle_name'])) $middle_name = $row['middle_name'];
			if(isset($row['last_name'])) $last_name = $row['last_name'];
		
			if(isset($row['cell'])) $cell = $row['cell'];
			if(isset($row['dob'])) $dob = $row['dob'];
			if(isset($row['gender'])) $gender = $row['gender'];
			if(isset($row['status'])) $status = $row['status'];
		
			if(isset($row['sc_cell'])) $sc_cell = $row['sc_cell'];
			if(isset($row['sc_whatsapp'])) $sc_whatsapp = $row['sc_whatsapp'];
			if(isset($row['sc_skype'])) $sc_skype = $row['sc_skype'];		
        		
			if(isset($row['hs_street_name'])) $_SESSION['hs_street_name'] = $row['hs_street_name'];
			if(isset($row['hs_number'])) $_SESSION['hs_number'] = $row['hs_number'];
			if(isset($row['hs_suburb'])) $_SESSION['hs_suburb'] = $row['hs_suburb'];
			if(isset($row['hs_city'])) {$_SESSION['hs_city'] = $row['hs_city'];
			}else{
			$_SESSION['hs_city'] = $row['city'];
			}; 
			
			if(isset($row['hs_province'])) {$_SESSION['hs_province'] = $row['hs_province'];
			}else{
			$_SESSION['hs_province'] = $row['province'];
			};
			
			if(isset($row['hs_country'])) {$_SESSION['hs_country'] = $row['hs_country'];
			}else{
			$_SESSION['hs_country'] = $row['country'];
			};   
			
        	if(isset($row['hp_street_name'])) $_SESSION['hp_street_name'] = $row['hp_street_name'];
			if(isset($row['hp_number'])) $_SESSION['hp_number'] = $row['hp_number'];        	
			if(isset($row['hp_suburb'])) $_SESSION['hp_suburb'] = $row['hp_suburb'];
			
			if(isset($row['hp_city'])) {$_SESSION['hp_city'] = $row['hp_city'];
			}else{
			$_SESSION['hp_city'] = $row['city'];
			}; 
			
			if(isset($row['hp_province'])) {$_SESSION['hp_province'] = $row['hp_province'];
			}else{
			$_SESSION['hp_province'] = $row['province'];
			};
			
        	if(isset($row['hp_code'])) $_SESSION['hp_code'] = $row['hp_code'];
        	
        	if(isset($row['hp_country'])) {$_SESSION['hp_country'] = $row['hp_country'];
        	}else{
			$_SESSION['hp_country'] = $row['country'];
			};
			
			if(isset($row['ws_street_name'])) $_SESSION['ws_street_name'] = $row['ws_street_name'];
			if(isset($row['ws_number'])) $_SESSION['ws_number'] = $row['ws_number'];
			if(isset($row['ws_suburb'])) $_SESSION['ws_suburb'] = $row['ws_suburb'];
			
			if(isset($row['ws_city'])) {$_SESSION['ws_city'] = $row['ws_city'];
			}else{
			$_SESSION['ws_city'] = $row['city'];
			}; 
			
			if(isset($row['ws_province'])) {$_SESSION['ws_province'] = $row['ws_province'];
			}else{
			$_SESSION['ws_province'] = $row['province'];
			};
			
			if(isset($row['ws_country'])) {$_SESSION['ws_country'] = $row['ws_country'];
			}else{
			$_SESSION['ws_country'] = $row['country'];
			};	
			
        	if(isset($row['wp_street_name'])) $_SESSION['wp_street_name'] = $row['wp_street_name'];
        	if(isset($row['wp_number'])) $_SESSION['wp_number'] = $row['wp_number'];
			if(isset($row['wp_suburb'])) $_SESSION['wp_suburb'] = $row['wp_suburb'];
			
			if(isset($row['wp_city'])) {$_SESSION['wp_city'] = $row['wp_city'];
			}else{
			$_SESSION['wp_city'] = $row['city'];
			}; 
			
			if(isset($row['wp_province'])) {$_SESSION['wp_province'] = $row['wp_province'];
			}else{
			$_SESSION['wp_province'] = $row['province'];
			};
			
        	if(isset($row['wp_code'])) $_SESSION['wp_code'] = $row['wp_code'];
        	
        	if(isset($row['wp_country'])) {$_SESSION['wp_country'] = $row['wp_country'];
        	}else{
			$_SESSION['wp_country'] = $row['country'];
			};
			
		$username = $first_name.'&nbsp'.$last_name;
			
			if(isset($username)) $_SESSION['username'] = $username;
			if(isset($first_name)) $_SESSION['first_name'] = $first_name;
			if(isset($middle_name)) $_SESSION['middle_name'] = $middle_name;
			if(isset($last_name)) $_SESSION['last_name'] = $last_name; 
			if(!isset($cell)) $cell = "+27";
			if(isset($cell)) $_SESSION['cell'] = $cell;
			if(isset($dob)) $_SESSION['dob'] = $dob;
			if(isset($sc_cell)) $_SESSION['sc_cell'] = $sc_cell;
			if(isset($sc_whatsapp)) $_SESSION['sc_whatsapp'] = $sc_whatsapp;
			if(isset($sc_skype)) $_SESSION['sc_skype'] = $sc_skype;
			if(isset($gender)) $_SESSION['gender'] = $gender;
			if(isset($status)) $_SESSION['status'] = $status;
			
			if(!isset($_SESSION['sc_cell'])) $_SESSION['sc_cell'] = $cell;
			if(!isset($_SESSION['sc_whatsapp'])) $_SESSION['sc_whatsapp'] = $cell;
			
	}
	
if(isset($result)) echo $result;
?>	