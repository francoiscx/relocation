<!-- Start of Radio Buttons for pc_twitter_status -->
<div class="groupl">

<?php

$pc_twitter_status = $_SESSION['pc_twitter_status'];

if(!isset($pc_twitter_status)) {$pc_twitter_status = 'pc_twitterpassive'; }



//echo $pc_twitter_status;

switch ($pc_twitter_status) {
    case "pc_twitteractive":
        echo "
<div>

    <div class='pc_twitter_selection' id='pc_twitteractive'>
    <a class='pc_twitter_selectionSwitch' href='#pc_twitterpassive'><input type='radio' id='pc_twitter_status_on' name='pc_twitter_status' value='pc_twitterpassive' hidden> 
    <label for='pc_twitter_status_on' class='pc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_twitter_selection' id='pc_twitterpassive'>
    <a class='pc_twitter_selectionSwitch' href='#pc_twitteractive'><input type='radio' id='pc_twitter_status_off' name='pc_twitter_status' value='pc_twitteractive' hidden>
    <label for='pc_twitter_status_off' class='pc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_twitter_status').on('click', function () {
        check = $('#pc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.pc_twitter_Check i').hasClass('icon-check-square')) {
                $('.pc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_twitter_Check i').hasClass('icon-square-o')) {
                $('.pc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_twitter_status = $('#pc_twitteractive, #pc_twitterpassive').hide();
$('#pc_twitteractive').show();
$('#pc_twitterpassive').hide();
$('.pc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_twitter_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_twitterpassive":
        echo "
<div>

  <div class='pc_twitter_selection' id='pc_twitterpassive'>
    <a class='pc_twitter_selectionSwitch' href='#pc_twitteractive'><input type='radio' id='pc_twitter_status_off' name='pc_twitter_status' value='pc_twitteractive' hidden>
    <label for='pc_twitter_status_off' class='pc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_twitter_selection' id='pc_twitteractive'>
    <a class='pc_twitter_selectionSwitch' href='#pc_twitterpassive'><input type='radio' id='pc_twitter_status_on' name='pc_twitter_status' value='pc_twitterpassive' hidden>
    <label for='pc_twitter_status_on' class='pc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_twitter_status').on('click', function () {
        check = $('#pc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.pc_twitter_Check i').hasClass('icon-square-o')) {
                $('.pc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_twitter_Check i').hasClass('icon-check-square')) {
                $('.pc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_twitter_status = $('#pc_twitteractive, #pc_twitterpassive').hide();
$('#pc_twitteractive').hide();
$('#pc_twitterpassive').show();
$('.pc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_twitter_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_twitter_selection' id='pc_twitterpassive'>
    <a class='pc_twitter_selectionSwitch' href='#pc_twitteractive'><input type='radio' id='pc_twitter_status_off' name='pc_twitter_status' value='pc_twitteractive' hidden>
    <label for='pc_twitter_status_off' class='pc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_twitter_selection' id='pc_twitteractive'>
    <a class='pc_twitter_selectionSwitch' href='#pc_twitterpassive'><input type='radio' id='pc_twitter_status_on' name='pc_twitter_status' value='pc_twitterpassive' hidden>
    <label for='pc_twitter_status_on' class='pc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_twitter_status').on('click', function () {
        check = $('#pc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.pc_twitter_Check i').hasClass('icon-square-o')) {
                $('.pc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_twitter_Check i').hasClass('icon-check-square')) {
                $('.pc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_twitter_status = $('#pc_twitteractive, #pc_twitterpassive').hide();
$('#pc_twitteractive').hide();
$('#pc_twitterpassive').show();
$('.pc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_twitter_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>