<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$sc_googleP_status = $_POST['sc_googleP_status'];

//process the form if the button is clicked
if (isset($_POST['sc_googleP_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlsc_googleP_statusQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlsc_googleP_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlsc_googleP_statusUpdate = "UPDATE social_card SET sc_googleP_status =:sc_googleP_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlsc_googleP_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_googleP_status' => $sc_googleP_status, ':userID' => $userID));

                    $sc_googleP_status_result = 'sc_googleP_status';
                    $_SESSION['sc_googleP_status'] = $sc_googleP_status;
                
                 }catch (PDOException $ex){
                $sc_googleP_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlsc_googleP_statusInsert = "INSERT INTO social_card (userID, sc_googleP_status)
                    VALUES (:userID, :sc_googleP_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlsc_googleP_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':sc_googleP_status' => $sc_googleP_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $sc_googleP_status_result = 'sc_googleP_status';
                    $_SESSION['sc_googleP_status'] = $sc_googleP_status;
	    	        }
                }
            }catch (PDOException $ex){
                $sc_googleP_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($sc_googleP_status == sc_googlePactive) echo "sc_googlePactive";
 else if ($sc_googleP_status != sc_googlePactive) echo "sc_googlePpassive";

?>