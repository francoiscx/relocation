<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$pc_company_slogan = $_POST['pc_company_slogan'];

//process the form if the button is clicked
if (isset($_POST['pc_company_slogan'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE professional_card SET pc_company_slogan =:pc_company_slogan WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_company_slogan' => $pc_company_slogan, ':userID' => $userID));

                    $pc_company_slogan_result = "Update Successful";
                    $_SESSION['pc_company_slogan'] = $pc_company_slogan;
                    
                 }catch (PDOException $ex){
                $pc_company_slogan_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO professional_card (userID, pc_company_slogan)
                        VALUES (:userID, :pc_company_slogan)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':pc_company_slogan' => $pc_company_slogan));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $pc_company_slogan_result = "Data was successfully captured";
                }
   
                    $pc_company_slogan_result = "Card was created";
                    
                    $_SESSION['pc_company_slogan'] = $pc_company_slogan;
                }
            }catch (PDOException $ex){
                $pc_company_slogan_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $pc_company_slogan_result
?>

