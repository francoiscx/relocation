<!-- Start of Radio Buttons for pc_company_linkedin_status -->
<div class="groupl">

<?php

$pc_company_linkedin_status = $_SESSION['pc_company_linkedin_status'];

if(!isset($pc_company_linkedin_status)) {$pc_company_linkedin_status = 'pc_company_linkedinpassive'; }



//echo $pc_company_linkedin_status;

switch ($pc_company_linkedin_status) {
    case "pc_company_linkedinactive":
        echo "
<div>

    <div class='pc_company_linkedin_selection' id='pc_company_linkedinactive'>
    <a class='pc_company_linkedin_selectionSwitch' href='#pc_company_linkedinpassive'><input type='radio' id='pc_company_linkedin_status_on' name='pc_company_linkedin_status' value='pc_company_linkedinpassive' hidden> 
    <label for='pc_company_linkedin_status_on' class='pc_company_linkedin_Check'>
     <fa-linkedin class='icon-linkedin-square' aria-hidden='true'></fa-linkedin>LinkedIn
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_company_linkedin_selection' id='pc_company_linkedinpassive'>
    <a class='pc_company_linkedin_selectionSwitch' href='#pc_company_linkedinactive'><input type='radio' id='pc_company_linkedin_status_off' name='pc_company_linkedin_status' value='pc_company_linkedinactive' hidden>
    <label for='pc_company_linkedin_status_off' class='pc_company_linkedin_Check'>
    <fa-linkedin class='icon-linkedin-square' aria-hidden='true'></fa-linkedin>LinkedIn
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_linkedin_status').on('click', function () {
        check = $('#pc_company_linkedin_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_linkedin_Check i').hasClass('icon-check-square')) {
                $('.pc_company_linkedin_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_company_linkedin_Check i').hasClass('icon-square-o')) {
                $('.pc_company_linkedin_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_linkedin_status = $('#pc_company_linkedinactive, #pc_company_linkedinpassive').hide();
$('#pc_company_linkedinactive').show();
$('#pc_company_linkedinpassive').hide();
$('.pc_company_linkedin_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_linkedin_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_company_linkedinpassive":
        echo "
<div>

  <div class='pc_company_linkedin_selection' id='pc_company_linkedinpassive'>
    <a class='pc_company_linkedin_selectionSwitch' href='#pc_company_linkedinactive'><input type='radio' id='pc_company_linkedin_status_off' name='pc_company_linkedin_status' value='pc_company_linkedinactive' hidden>
    <label for='pc_company_linkedin_status_off' class='pc_company_linkedin_Check'>
    <fa-linkedin class='icon-linkedin-square' aria-hidden='true'></fa-linkedin>LinkedIn
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_company_linkedin_selection' id='pc_company_linkedinactive'>
    <a class='pc_company_linkedin_selectionSwitch' href='#pc_company_linkedinpassive'><input type='radio' id='pc_company_linkedin_status_on' name='pc_company_linkedin_status' value='pc_company_linkedinpassive' hidden>
    <label for='pc_company_linkedin_status_on' class='pc_company_linkedin_Check'>
     <fa-linkedin class='icon-linkedin-square' aria-hidden='true'></fa-linkedin>LinkedIn
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_linkedin_status').on('click', function () {
        check = $('#pc_company_linkedin_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_linkedin_Check i').hasClass('icon-square-o')) {
                $('.pc_company_linkedin_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_company_linkedin_Check i').hasClass('icon-check-square')) {
                $('.pc_company_linkedin_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_linkedin_status = $('#pc_company_linkedinactive, #pc_company_linkedinpassive').hide();
$('#pc_company_linkedinactive').hide();
$('#pc_company_linkedinpassive').show();
$('.pc_company_linkedin_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_linkedin_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_company_linkedin_selection' id='pc_company_linkedinpassive'>
    <a class='pc_company_linkedin_selectionSwitch' href='#pc_company_linkedinactive'><input type='radio' id='pc_company_linkedin_status_off' name='pc_company_linkedin_status' value='pc_company_linkedinactive' hidden>
    <label for='pc_company_linkedin_status_off' class='pc_company_linkedin_Check'>
    <fa-linkedin class='icon-linkedin-square' aria-hidden='true'></fa-linkedin>LinkedIn
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_company_linkedin_selection' id='pc_company_linkedinactive'>
    <a class='pc_company_linkedin_selectionSwitch' href='#pc_company_linkedinpassive'><input type='radio' id='pc_company_linkedin_status_on' name='pc_company_linkedin_status' value='pc_company_linkedinpassive' hidden>
    <label for='pc_company_linkedin_status_on' class='pc_company_linkedin_Check'>
     <fa-linkedin class='icon-linkedin-square' aria-hidden='true'></fa-linkedin>LinkedIn
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_company_linkedin_status').on('click', function () {
        check = $('#pc_company_linkedin_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_linkedin_Check i').hasClass('icon-square-o')) {
                $('.pc_company_linkedin_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_company_linkedin_Check i').hasClass('icon-check-square')) {
                $('.pc_company_linkedin_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_linkedin_status = $('#pc_company_linkedinactive, #pc_company_linkedinpassive').hide();
$('#pc_company_linkedinactive').hide();
$('#pc_company_linkedinpassive').show();
$('.pc_company_linkedin_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_linkedin_status.hide();
    $(href).show();
})
});
</script>


";
}


?>














</div>