<?php
$sc_skype = "sc_skype";
$sc_skype_perm = "sc_skype_perm";
$sc_skype_status = "sc_skype_status";
?>

<!-- Start of Textfield for sc_skype -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_skype: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingsc_skype = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_skype(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_skype(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_skype').donetypingsc_skype(function(){
  	var sc_skype = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_skype.php",
        method:"POST",
        data:{sc_skype:sc_skype},
        success: function(data){
      	$('#sc_skype_result').html(data);
      }
    });  
});

});
</script>

<?php
$sc_skype = $_SESSION['sc_skype'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="sc_skype">Skype&nbsp<span><h5 id="sc_skype_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="sc_skype" name="sc_skype" value="<?php echo $sc_skype; ?>">
            
<!-- End of Textfield for sc_skype -->






<!-- Start of Radio Buttons for sc_skype_perm -->

<script>
$(document).ready(function(){
	$('input[name="sc_skype_perm"]').click(function(){
  	var sc_skype_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_skype_perm.php",
        method:"POST",
        data:{sc_skype_perm:sc_skype_perm},
        success: function(data){
      	$('#sc_skype_result').html(data);
      }
    });
  });
});
</script>

<?php

$sc_skype_perm = $_SESSION['sc_skype_perm'];
switch ($sc_skype_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_skype_perm_pub" name="sc_skype_perm" checked="checked" value="Public">
                <label for="sc_skype_perm_pub" id="sc_skype_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_skype_perm_req" name="sc_skype_perm" value="Request">
                <label for="sc_skype_perm_req" id="sc_skype_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_skype_perm_pri" name="sc_skype_perm" value="Private">
                <label for="sc_skype_perm_pri" id="sc_skype_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_skype_perm_pub" name="sc_skype_perm" value="Public">
                <label for="sc_skype_perm_pub" id="sc_skype_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_skype_perm_req" name="sc_skype_perm" checked="checked" value="Request">
                <label for="sc_skype_perm_req" id="sc_skype_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_skype_perm_pri" name="sc_skype_perm" value="Private">
                <label for="sc_skype_perm_pri" id="sc_skype_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_skype_perm_pub" name="sc_skype_perm" value="Public">
                <label for="sc_skype_perm_pub" id="sc_skype_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_skype_perm_req" name="sc_skype_perm" value="Request">
                <label for="sc_skype_perm_req" id="sc_skype_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_skype_perm_pri" name="sc_skype_perm" checked="checked" value="Private">
                <label for="sc_skype_perm_pri" id="sc_skype_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#sc_skype_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for sc_skype_perm -->
