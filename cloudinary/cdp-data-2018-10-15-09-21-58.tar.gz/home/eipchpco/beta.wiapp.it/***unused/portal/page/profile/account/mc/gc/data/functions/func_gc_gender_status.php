<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gc_gender_status = $_POST['gc_gender_status'];

//process the form if the button is clicked
if (isset($_POST['gc_gender_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlgc_gender_statusQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgc_gender_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgc_gender_statusUpdate = "UPDATE general_card SET gc_gender_status =:gc_gender_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgc_gender_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_gender_status' => $gc_gender_status, ':userID' => $userID));

                    $gc_gender_status_result = 'gc_gender_status';
                    $_SESSION['gc_gender_status'] = $gc_gender_status;
                
                 }catch (PDOException $ex){
                $gc_gender_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlgc_gender_statusInsert = "INSERT INTO general_card (userID, gc_gender_status)
                    VALUES (:userID, :gc_gender_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgc_gender_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gc_gender_status' => $gc_gender_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gc_gender_status_result = 'gc_gender_status';
                    $_SESSION['gc_gender_status'] = $gc_gender_status;
	    	        }
                }
            }catch (PDOException $ex){
                $gc_gender_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($gc_gender_status == gc_genderactive) echo "gc_genderactive";
 else if ($gc_gender_status != gc_genderactive) echo "gc_genderpassive";

?>