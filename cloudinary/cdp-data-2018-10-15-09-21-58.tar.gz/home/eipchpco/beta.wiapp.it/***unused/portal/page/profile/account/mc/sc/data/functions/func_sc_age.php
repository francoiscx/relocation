<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$sc_age = $_POST['sc_age'];

//process the form if the button is clicked
if (isset($_POST['sc_age'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE social_card SET sc_age =:sc_age WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_age' => $sc_age, ':userID' => $userID));

                    $sc_age_result = "Success";
                    $_SESSION['sc_age'] = $sc_age;
                    
                 }catch (PDOException $ex){
                $sc_age_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO social_card (userID, sc_age)
                        VALUES (:userID, :sc_age)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':sc_age' => $sc_age));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $sc_age_result = "Data was successfully captured";
                }
   
                    $sc_age_result = "Success";
                    
                    $_SESSION['sc_age'] = $sc_age;
                }
            }catch (PDOException $ex){
                $sc_age_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $sc_age_result
?>

