<!-- Start of Radio Buttons for gc_whatsapp_status -->
<div class="groupl">

<?php

$gc_whatsapp_status = $_SESSION['gc_whatsapp_status'];

if(!isset($gc_whatsapp_status)) {$gc_whatsapp_status = 'gc_whatsapppassive'; }



//echo $gc_whatsapp_status;

switch ($gc_whatsapp_status) {
    case "gc_whatsappactive":
        echo "
<div>

    <div class='gc_whatsapp_selection' id='gc_whatsappactive'>
    <a class='gc_whatsapp_selectionSwitch' href='#gc_whatsapppassive'><input type='radio' id='gc_whatsapp_status_on' name='gc_whatsapp_status' value='gc_whatsapppassive' hidden> 
    <label for='gc_whatsapp_status_on' class='gc_whatsapp_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Whatsapp
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_whatsapp_selection' id='gc_whatsapppassive'>
    <a class='gc_whatsapp_selectionSwitch' href='#gc_whatsappactive'><input type='radio' id='gc_whatsapp_status_off' name='gc_whatsapp_status' value='gc_whatsappactive' hidden>
    <label for='gc_whatsapp_status_off' class='gc_whatsapp_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Whatsapp
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_whatsapp_status').on('click', function () {
        check = $('#gc_whatsapp_status').prop('checked');
        
        if (check) {
            if ($('.gc_whatsapp_Check i').hasClass('icon-check-square')) {
                $('.gc_whatsapp_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_whatsapp_Check i').hasClass('icon-square-o')) {
                $('.gc_whatsapp_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_whatsapp_status = $('#gc_whatsappactive, #gc_whatsapppassive').hide();
$('#gc_whatsappactive').show();
$('#gc_whatsapppassive').hide();
$('.gc_whatsapp_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_whatsapp_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_whatsapppassive":
        echo "
<div>

  <div class='gc_whatsapp_selection' id='gc_whatsapppassive'>
    <a class='gc_whatsapp_selectionSwitch' href='#gc_whatsappactive'><input type='radio' id='gc_whatsapp_status_off' name='gc_whatsapp_status' value='gc_whatsappactive' hidden>
    <label for='gc_whatsapp_status_off' class='gc_whatsapp_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Whatsapp
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_whatsapp_selection' id='gc_whatsappactive'>
    <a class='gc_whatsapp_selectionSwitch' href='#gc_whatsapppassive'><input type='radio' id='gc_whatsapp_status_on' name='gc_whatsapp_status' value='gc_whatsapppassive' hidden>
    <label for='gc_whatsapp_status_on' class='gc_whatsapp_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Whatsapp
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_whatsapp_status').on('click', function () {
        check = $('#gc_whatsapp_status').prop('checked');
        
        if (check) {
            if ($('.gc_whatsapp_Check i').hasClass('icon-square-o')) {
                $('.gc_whatsapp_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_whatsapp_Check i').hasClass('icon-check-square')) {
                $('.gc_whatsapp_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_whatsapp_status = $('#gc_whatsappactive, #gc_whatsapppassive').hide();
$('#gc_whatsappactive').hide();
$('#gc_whatsapppassive').show();
$('.gc_whatsapp_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_whatsapp_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_whatsapp_selection' id='gc_whatsapppassive'>
    <a class='gc_whatsapp_selectionSwitch' href='#gc_whatsappactive'><input type='radio' id='gc_whatsapp_status_off' name='gc_whatsapp_status' value='gc_whatsappactive' hidden>
    <label for='gc_whatsapp_status_off' class='gc_whatsapp_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Whatsapp
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_whatsapp_selection' id='gc_whatsappactive'>
    <a class='gc_whatsapp_selectionSwitch' href='#gc_whatsapppassive'><input type='radio' id='gc_whatsapp_status_on' name='gc_whatsapp_status' value='gc_whatsapppassive' hidden>
    <label for='gc_whatsapp_status_on' class='gc_whatsapp_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Whatsapp
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_whatsapp_status').on('click', function () {
        check = $('#gc_whatsapp_status').prop('checked');
        
        if (check) {
            if ($('.gc_whatsapp_Check i').hasClass('icon-square-o')) {
                $('.gc_whatsapp_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_whatsapp_Check i').hasClass('icon-check-square')) {
                $('.gc_whatsapp_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_whatsapp_status = $('#gc_whatsappactive, #gc_whatsapppassive').hide();
$('#gc_whatsappactive').hide();
$('#gc_whatsapppassive').show();
$('.gc_whatsapp_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_whatsapp_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>