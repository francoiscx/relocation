<p class="help-block">Only provide details of your place of employment.</p>	


<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#myPlaceOfWorkInfo">Institution Details <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="myPlaceOfWorkInfo" class="accordion-body collapse">
    	

			    <p class="help-block">Please provide info related to your place of work.</p>


										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_regname.php'; echo '</div>';
										?> 
										
										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_regnumber.php'; echo '</div>';
										?>
										
										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_vatnumber.php'; echo '</div>';
										?>
										
										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_taname.php'; echo '</div>';
										?>
										
										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_slogan.php'; echo '</div>';
										?>
										
										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_incdate.php'; echo '</div>';
										?>
										
										<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_industry.php'; echo '</div>';
										?>
										
										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_switchboard.php'; echo '</div>';
										?>
									
										<?php echo '<div class="groupl">'; include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_email.php'; echo '</div>';
										?>
										
										<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_website.php'; echo '</div>';
										?>
		    										
										<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_blog.php'; echo '</div>';
										?>
																				
										<?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_saddress.php'; echo '</div>';
										?>
                                        
                                        <?php echo '<div class="groupl">'; include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_paddress.php'; echo '</div>';
                                        ?>

		</div>
	</div>		

	

<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#myPlaceOfWorkNetworks">Institution Networks <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="myPlaceOfWorkNetworks" class="accordion-body collapse">	
									
            <p class="help-block">Please provide institution info you wish to share on your profesional card.<input type="text" placeholder="Filter Social Networks" id="filterPCC" style="float:right; padding-top:10px"/>
<div style="clear:both;"></div></p>	

			

		<div class="select-catpcc" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_linkedin_status.php';
	                    ?>
					</div>
					<span class="namepcc">LinkedIn</span>
                        <p class="categorypcc">Community</p>
		</div>


		<div class="select-catpcc" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_facebook_status.php';
	                    ?>
					</div>
					<span class="namepcc">facebook</span>
                        <p class="categorypcc">Community</p>
		</div>

		
		
		<div class="select-catpcc" catname="Blogging" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_twitter_status.php';
	                    ?>
					</div>
					<span class="namepcc">Twitter</span>
                        <p class="categorypcc">Blogging</p>
		</div>

		
		
		<div class="select-catpcc" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_googleP_status.php';
	                    ?>
					</div>
					<span class="namepcc">google+</span>
                        <p class="categorypcc">Community</p>
		</div>
            
		<div class="select-catpcc" catname="Video" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_youtube_status.php';
	                    ?>
					</div>
					<span class="namepcc">YouTube</span>
                        <p class="categorypcc">Video</p>
		</div>
		
		<div class="select-catpcc" catname="Photo" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_instagram_status.php';
	                    ?>
					</div>
					<span class="namepcc">Instagram</span>
                        <p class="categorypcc">Photo</p>
		</div>
            
		<div class="select-catpcc" catname="Photo" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_pinterest_status.php';
	                    ?>
					</div>
					<span class="namepcc">Pinterest</span>
                        <p class="categorypcc">Photo</p>
		</div>
            
		<div class="select-catpcc" catname="Photo" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_flickr_status.php';
	                    ?>
					</div>
					<span class="namepcc">flickr</span>
                        <p class="categorypcc">Photo</p>
		</div>				
				    
<script>
document.getElementById("filterPCC").oninput=function(){
  var matcher = new RegExp(document.getElementById("filterPCC").value, "gi");
  for (var i=0;i<document.getElementsByClassName("select-catpcc").length;i++) {
    if (matcher.test(document.getElementsByClassName("namepcc")[i].innerHTML) || matcher.test(document.getElementsByClassName("categorypcc")[i].innerHTML)) {
      document.getElementsByClassName("select-catpcc")[i].style.display="inline-block";
    } else {
      document.getElementsByClassName("select-catpcc")[i].style.display="none";
    }
      
  }
}
</script>				

				
												
	                <div style="clear:both;"></div></p>	    
						
                        
                        <hr/>				
				                <?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/pc_company_network_profiles.php';?>				
	

	
					
		    </div>	
		</div>
	</div>	
</div>	



