<?php
$sc_middlename = "sc_middlename";
$sc_middlename_perm = "sc_middlename_perm";
$sc_middlename_status = "sc_middlename_status";
?>


<div  id="sc_middlename_status"></div>

<!-- Start of Textfield for sc_middlename -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_middlename: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypingsc_middlename = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_middlename(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_middlename(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_middlename').donetypingsc_middlename(function(){
  	var sc_middlename = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_sc_middlename.php",
        method:"POST",
        data:{sc_middlename:sc_middlename},
        success: function(data){
      	$('#sc_middlename_result').html(data);
      }
    });  
});

});
</script>

<?php
$sc_middlename = $_SESSION['sc_middlename'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="sc_middlename"><fb-none class="icon-none" aria-hidden="true"></fb-none>Middle name/s&nbsp<span><h5 id="sc_middlename_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="sc_middlename" name="sc_middlename" value="<?php echo $sc_middlename; ?>">
            
<!-- End of Textfield for sc_middlename -->






<!-- Start of Radio Buttons for sc_middlename_perm -->

<script>
$(document).ready(function(){
	$('input[name="sc_middlename_perm"]').click(function(){
  	var sc_middlename_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_sc_middlename_perm.php",
        method:"POST",
        data:{sc_middlename_perm:sc_middlename_perm},
        success: function(data){
      	$('#sc_middlename_result').html(data);
      }
    });
  });
});
</script>

<?php

$sc_middlename_perm = $_SESSION['sc_middlename_perm'];
switch ($sc_middlename_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_middlename_perm_pub" name="sc_middlename_perm" checked="checked" value="Public">
                <label for="sc_middlename_perm_pub" id="sc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_middlename_perm_req" name="sc_middlename_perm" value="Request">
                <label for="sc_middlename_perm_req" id="sc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_middlename_perm_pri" name="sc_middlename_perm" value="Private">
                <label for="sc_middlename_perm_pri" id="sc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_middlename_perm_pub" name="sc_middlename_perm" value="Public">
                <label for="sc_middlename_perm_pub" id="sc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_middlename_perm_req" name="sc_middlename_perm" checked="checked" value="Request">
                <label for="sc_middlename_perm_req" id="sc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_middlename_perm_pri" name="sc_middlename_perm" value="Private">
                <label for="sc_middlename_perm_pri" id="sc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_middlename_perm_pub" name="sc_middlename_perm" value="Public">
                <label for="sc_middlename_perm_pub" id="sc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_middlename_perm_req" name="sc_middlename_perm" value="Request">
                <label for="sc_middlename_perm_req" id="sc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_middlename_perm_pri" name="sc_middlename_perm" checked="checked" value="Private">
                <label for="sc_middlename_perm_pri" id="sc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#sc_middlename_result").text(texts[count]);
    count < 4 ? count++ : count = 0;
}
setInterval(changeText, 5e2);
</script>
</div>
<!-- End of Radio Buttons for sc_middlename_perm -->