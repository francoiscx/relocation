<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$gl_cellArea = $_POST['gl_cellArea'];

//process the form if the button is clicked
if (isset($_POST['gl_cellArea'])) 
            try{
                //create SQL select statement to verify if userID exist in the general database
                $sqlQuery = "SELECT userID FROM general WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE general SET gl_cellArea =:gl_cellArea WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':gl_cellArea' => $gl_cellArea, ':userID' => $userID));

                    $gl_cellArea_result = "Success";
                    $_SESSION['gl_cellArea'] = $gl_cellArea;
                    
                 }catch (PDOException $ex){
                $gl_cellArea_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO general (userID, gl_cellArea)
                        VALUES (:userID, :gl_cellArea)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':gl_cellArea' => $gl_cellArea));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $gl_cellArea_result = "Success";
                }
   
                    $gl_cellArea_result = "Success";
                    
                    $_SESSION['gl_cellArea'] = $gl_cellArea;
                }
            }catch (PDOException $ex){
                $gl_cellArea_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $gl_cellArea_result
?>

