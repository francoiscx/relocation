<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$pc_linkedin = $_POST['pc_linkedin'];

//process the form if the button is clicked
if (isset($_POST['pc_linkedin'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE professional_card SET pc_linkedin =:pc_linkedin WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_linkedin' => $pc_linkedin, ':userID' => $userID));

                    $pc_linkedin_result = "Success";
                    $_SESSION['pc_linkedin'] = $pc_linkedin;
                    
                 }catch (PDOException $ex){
                $pc_linkedin_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO professional_card (userID, pc_linkedin)
                        VALUES (:userID, :pc_linkedin)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':pc_linkedin' => $pc_linkedin));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $pc_linkedin_result = "Success";
                }
   
                    $pc_linkedin_result = "Card was created";
                    
                    $_SESSION['pc_linkedin'] = $pc_linkedin;
                }
            }catch (PDOException $ex){
                $pc_linkedin_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $pc_linkedin_result
?>

