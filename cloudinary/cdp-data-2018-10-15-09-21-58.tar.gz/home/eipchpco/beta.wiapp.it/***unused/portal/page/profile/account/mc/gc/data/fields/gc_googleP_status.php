<!-- Start of Radio Buttons for gc_googleP_status -->
<div class="groupl">

<?php

$gc_googleP_status = $_SESSION['gc_googleP_status'];

if(!isset($gc_googleP_status)) {$gc_googleP_status = 'gc_googlePpassive'; }



//echo $gc_googleP_status;

switch ($gc_googleP_status) {
    case "gc_googlePactive":
        echo "
<div>

    <div class='gc_googleP_selection' id='gc_googlePactive'>
    <a class='gc_googleP_selectionSwitch' href='#gc_googlePpassive'><input type='radio' id='gc_googleP_status_on' name='gc_googleP_status' value='gc_googlePpassive' hidden> 
    <label for='gc_googleP_status_on' class='gc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_googleP_selection' id='gc_googlePpassive'>
    <a class='gc_googleP_selectionSwitch' href='#gc_googlePactive'><input type='radio' id='gc_googleP_status_off' name='gc_googleP_status' value='gc_googlePactive' hidden>
    <label for='gc_googleP_status_off' class='gc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_googleP_status').on('click', function () {
        check = $('#gc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.gc_googleP_Check i').hasClass('icon-check-square')) {
                $('.gc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_googleP_Check i').hasClass('icon-square-o')) {
                $('.gc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_googleP_status = $('#gc_googlePactive, #gc_googlePpassive').hide();
$('#gc_googlePactive').show();
$('#gc_googlePpassive').hide();
$('.gc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_googleP_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_googlePpassive":
        echo "
<div>

  <div class='gc_googleP_selection' id='gc_googlePpassive'>
    <a class='gc_googleP_selectionSwitch' href='#gc_googlePactive'><input type='radio' id='gc_googleP_status_off' name='gc_googleP_status' value='gc_googlePactive' hidden>
    <label for='gc_googleP_status_off' class='gc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_googleP_selection' id='gc_googlePactive'>
    <a class='gc_googleP_selectionSwitch' href='#gc_googlePpassive'><input type='radio' id='gc_googleP_status_on' name='gc_googleP_status' value='gc_googlePpassive' hidden>
    <label for='gc_googleP_status_on' class='gc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_googleP_status').on('click', function () {
        check = $('#gc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.gc_googleP_Check i').hasClass('icon-square-o')) {
                $('.gc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_googleP_Check i').hasClass('icon-check-square')) {
                $('.gc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_googleP_status = $('#gc_googlePactive, #gc_googlePpassive').hide();
$('#gc_googlePactive').hide();
$('#gc_googlePpassive').show();
$('.gc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_googleP_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_googleP_selection' id='gc_googlePpassive'>
    <a class='gc_googleP_selectionSwitch' href='#gc_googlePactive'><input type='radio' id='gc_googleP_status_off' name='gc_googleP_status' value='gc_googlePactive' hidden>
    <label for='gc_googleP_status_off' class='gc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_googleP_selection' id='gc_googlePactive'>
    <a class='gc_googleP_selectionSwitch' href='#gc_googlePpassive'><input type='radio' id='gc_googleP_status_on' name='gc_googleP_status' value='gc_googlePpassive' hidden>
    <label for='gc_googleP_status_on' class='gc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_googleP_status').on('click', function () {
        check = $('#gc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.gc_googleP_Check i').hasClass('icon-square-o')) {
                $('.gc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_googleP_Check i').hasClass('icon-check-square')) {
                $('.gc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_googleP_status = $('#gc_googlePactive, #gc_googlePpassive').hide();
$('#gc_googlePactive').hide();
$('#gc_googlePpassive').show();
$('.gc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_googleP_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>