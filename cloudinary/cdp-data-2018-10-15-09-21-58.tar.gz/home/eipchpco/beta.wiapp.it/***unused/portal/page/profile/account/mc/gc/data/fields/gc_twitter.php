<?php
$gc_twitter = "gc_twitter";
$gc_twitter_perm = "gc_twitter_perm";
$gc_twitter_status = "gc_twitter_status";
?>


<div  id="gc_twitter_status"></div>

<!-- Start of Textfield for gc_twitter -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_twitter: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_twitter = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_twitter(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_twitter(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_twitter').donetypinggc_twitter(function(){
  	var gc_twitter = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_twitter.php",
        method:"POST",
        data:{gc_twitter:gc_twitter},
        success: function(data){
      	$('#gc_twitter_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_twitter = $_SESSION['gc_twitter'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="gc_twitter"><fb-twitter class="icon-twitter-square" aria-hidden="true"></fb-twitter>twitter.com/&nbsp<span><h5 id="gc_twitter_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="gc_twitter" name="gc_twitter" value="<?php echo $gc_twitter; ?>">
            
<!-- End of Textfield for gc_twitter -->






<!-- Start of Radio Buttons for gc_twitter_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_twitter_perm"]').click(function(){
  	var gc_twitter_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_twitter_perm.php",
        method:"POST",
        data:{gc_twitter_perm:gc_twitter_perm},
        success: function(data){
      	$('#gc_twitter_result').html(data);
      }
    });
  });
});
</script>

<?php

$gc_twitter_perm = $_SESSION['gc_twitter_perm'];
switch ($gc_twitter_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_twitter_perm_pub" name="gc_twitter_perm" checked="checked" value="Public">
                <label for="gc_twitter_perm_pub" id="gc_twitter_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_twitter_perm_req" name="gc_twitter_perm" value="Request">
                <label for="gc_twitter_perm_req" id="gc_twitter_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_twitter_perm_pri" name="gc_twitter_perm" value="Private">
                <label for="gc_twitter_perm_pri" id="gc_twitter_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_twitter_perm_pub" name="gc_twitter_perm" value="Public">
                <label for="gc_twitter_perm_pub" id="gc_twitter_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_twitter_perm_req" name="gc_twitter_perm" checked="checked" value="Request">
                <label for="gc_twitter_perm_req" id="gc_twitter_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_twitter_perm_pri" name="gc_twitter_perm" value="Private">
                <label for="gc_twitter_perm_pri" id="gc_twitter_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_twitter_perm_pub" name="gc_twitter_perm" value="Public">
                <label for="gc_twitter_perm_pub" id="gc_twitter_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_twitter_perm_req" name="gc_twitter_perm" value="Request">
                <label for="gc_twitter_perm_req" id="gc_twitter_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_twitter_perm_pri" name="gc_twitter_perm" checked="checked" value="Private">
                <label for="gc_twitter_perm_pri" id="gc_twitter_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_twitter_result").text(texts[count]);
    count < 2 ? count++ : count = 0;
}
setInterval(changeText, 2e3);
</script>
</div>
<!-- End of Radio Buttons for gc_twitter_perm -->