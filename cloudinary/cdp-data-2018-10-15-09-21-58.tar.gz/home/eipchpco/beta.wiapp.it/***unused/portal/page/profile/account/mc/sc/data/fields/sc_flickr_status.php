<!-- Start of Radio Buttons for sc_flickr_status -->
<div class="groupl">

<?php

$sc_flickr_status = $_SESSION['sc_flickr_status'];

if(!isset($sc_flickr_status)) {$sc_flickr_status = 'sc_flickrpassive'; }



//echo $sc_flickr_status;

switch ($sc_flickr_status) {
    case "sc_flickractive":
        echo "
<div>

    <div class='sc_flickr_selection' id='sc_flickractive'>
    <a class='sc_flickr_selectionSwitch' href='#sc_flickrpassive'><input type='radio' id='sc_flickr_status_on' name='sc_flickr_status' value='sc_flickrpassive' hidden> 
    <label for='sc_flickr_status_on' class='sc_flickr_Check'>
     <fa-flickr class='icon-flickr' aria-hidden='true'></fa-flickr>flickr
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='sc_flickr_selection' id='sc_flickrpassive'>
    <a class='sc_flickr_selectionSwitch' href='#sc_flickractive'><input type='radio' id='sc_flickr_status_off' name='sc_flickr_status' value='sc_flickractive' hidden>
    <label for='sc_flickr_status_off' class='sc_flickr_Check'>
    <fa-flickr class='icon-flickr' aria-hidden='true'></fa-flickr>flickr
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#sc_flickr_status').on('click', function () {
        check = $('#sc_flickr_status').prop('checked');
        
        if (check) {
            if ($('.sc_flickr_Check i').hasClass('icon-check-square')) {
                $('.sc_flickr_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.sc_flickr_Check i').hasClass('icon-square-o')) {
                $('.sc_flickr_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_flickr_status = $('#sc_flickractive, #sc_flickrpassive').hide();
$('#sc_flickractive').show();
$('#sc_flickrpassive').hide();
$('.sc_flickr_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_flickr_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "sc_flickrpassive":
        echo "
<div>

  <div class='sc_flickr_selection' id='sc_flickrpassive'>
    <a class='sc_flickr_selectionSwitch' href='#sc_flickractive'><input type='radio' id='sc_flickr_status_off' name='sc_flickr_status' value='sc_flickractive' hidden>
    <label for='sc_flickr_status_off' class='sc_flickr_Check'>
    <fa-flickr class='icon-flickr' aria-hidden='true'></fa-flickr>flickr
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='sc_flickr_selection' id='sc_flickractive'>
    <a class='sc_flickr_selectionSwitch' href='#sc_flickrpassive'><input type='radio' id='sc_flickr_status_on' name='sc_flickr_status' value='sc_flickrpassive' hidden>
    <label for='sc_flickr_status_on' class='sc_flickr_Check'>
     <fa-flickr class='icon-flickr' aria-hidden='true'></fa-flickr>flickr
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#sc_flickr_status').on('click', function () {
        check = $('#sc_flickr_status').prop('checked');
        
        if (check) {
            if ($('.sc_flickr_Check i').hasClass('icon-square-o')) {
                $('.sc_flickr_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.sc_flickr_Check i').hasClass('icon-check-square')) {
                $('.sc_flickr_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_flickr_status = $('#sc_flickractive, #sc_flickrpassive').hide();
$('#sc_flickractive').hide();
$('#sc_flickrpassive').show();
$('.sc_flickr_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_flickr_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='sc_flickr_selection' id='sc_flickrpassive'>
    <a class='sc_flickr_selectionSwitch' href='#sc_flickractive'><input type='radio' id='sc_flickr_status_off' name='sc_flickr_status' value='sc_flickractive' hidden>
    <label for='sc_flickr_status_off' class='sc_flickr_Check'>
    <fa-flickr class='icon-flickr' aria-hidden='true'></fa-flickr>flickr
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='sc_flickr_selection' id='sc_flickractive'>
    <a class='sc_flickr_selectionSwitch' href='#sc_flickrpassive'><input type='radio' id='sc_flickr_status_on' name='sc_flickr_status' value='sc_flickrpassive' hidden>
    <label for='sc_flickr_status_on' class='sc_flickr_Check'>
     <fa-flickr class='icon-flickr' aria-hidden='true'></fa-flickr>flickr
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#sc_flickr_status').on('click', function () {
        check = $('#sc_flickr_status').prop('checked');
        
        if (check) {
            if ($('.sc_flickr_Check i').hasClass('icon-square-o')) {
                $('.sc_flickr_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.sc_flickr_Check i').hasClass('icon-check-square')) {
                $('.sc_flickr_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_flickr_status = $('#sc_flickractive, #sc_flickrpassive').hide();
$('#sc_flickractive').hide();
$('#sc_flickrpassive').show();
$('.sc_flickr_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_flickr_status.hide();
    $(href).show();
})
});
</script>


";
}


?>














</div>