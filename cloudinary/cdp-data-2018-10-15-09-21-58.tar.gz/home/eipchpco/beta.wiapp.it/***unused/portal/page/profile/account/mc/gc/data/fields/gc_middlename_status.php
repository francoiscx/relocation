<!-- Start of Radio Buttons for gc_middlename_status -->
<div class="groupl">

<?php

$gc_middlename_status = $_SESSION['gc_middlename_status'];

if(!isset($gc_middlename_status)) {$gc_middlename_status = 'gc_middlenamepassive'; }



//echo $gc_middlename_status;

switch ($gc_middlename_status) {
    case "gc_middlenameactive":
        echo "
<div>

    <div class='gc_middlename_selection' id='gc_middlenameactive'>
    <a class='gc_middlename_selectionSwitch' href='#gc_middlenamepassive'><input type='radio' id='gc_middlename_status_on' name='gc_middlename_status' value='gc_middlenamepassive' hidden> 
    <label for='gc_middlename_status_on' class='gc_middlename_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Middle name
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_middlename_selection' id='gc_middlenamepassive'>
    <a class='gc_middlename_selectionSwitch' href='#gc_middlenameactive'><input type='radio' id='gc_middlename_status_off' name='gc_middlename_status' value='gc_middlenameactive' hidden>
    <label for='gc_middlename_status_off' class='gc_middlename_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Middle name
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_middlename_status').on('click', function () {
        check = $('#gc_middlename_status').prop('checked');
        
        if (check) {
            if ($('.gc_middlename_Check i').hasClass('icon-check-square')) {
                $('.gc_middlename_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_middlename_Check i').hasClass('icon-square-o')) {
                $('.gc_middlename_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_middlename_status = $('#gc_middlenameactive, #gc_middlenamepassive').hide();
$('#gc_middlenameactive').show();
$('#gc_middlenamepassive').hide();
$('.gc_middlename_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_middlename_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_middlenamepassive":
        echo "
<div>

  <div class='gc_middlename_selection' id='gc_middlenamepassive'>
    <a class='gc_middlename_selectionSwitch' href='#gc_middlenameactive'><input type='radio' id='gc_middlename_status_off' name='gc_middlename_status' value='gc_middlenameactive' hidden>
    <label for='gc_middlename_status_off' class='gc_middlename_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Middle name
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_middlename_selection' id='gc_middlenameactive'>
    <a class='gc_middlename_selectionSwitch' href='#gc_middlenamepassive'><input type='radio' id='gc_middlename_status_on' name='gc_middlename_status' value='gc_middlenamepassive' hidden>
    <label for='gc_middlename_status_on' class='gc_middlename_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Middle name
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_middlename_status').on('click', function () {
        check = $('#gc_middlename_status').prop('checked');
        
        if (check) {
            if ($('.gc_middlename_Check i').hasClass('icon-square-o')) {
                $('.gc_middlename_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_middlename_Check i').hasClass('icon-check-square')) {
                $('.gc_middlename_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_middlename_status = $('#gc_middlenameactive, #gc_middlenamepassive').hide();
$('#gc_middlenameactive').hide();
$('#gc_middlenamepassive').show();
$('.gc_middlename_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_middlename_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_middlename_selection' id='gc_middlenamepassive'>
    <a class='gc_middlename_selectionSwitch' href='#gc_middlenameactive'><input type='radio' id='gc_middlename_status_off' name='gc_middlename_status' value='gc_middlenameactive' hidden>
    <label for='gc_middlename_status_off' class='gc_middlename_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Middle name
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_middlename_selection' id='gc_middlenameactive'>
    <a class='gc_middlename_selectionSwitch' href='#gc_middlenamepassive'><input type='radio' id='gc_middlename_status_on' name='gc_middlename_status' value='gc_middlenamepassive' hidden>
    <label for='gc_middlename_status_on' class='gc_middlename_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Middle name
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_middlename_status').on('click', function () {
        check = $('#gc_middlename_status').prop('checked');
        
        if (check) {
            if ($('.gc_middlename_Check i').hasClass('icon-square-o')) {
                $('.gc_middlename_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_middlename_Check i').hasClass('icon-check-square')) {
                $('.gc_middlename_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_middlename_status = $('#gc_middlenameactive, #gc_middlenamepassive').hide();
$('#gc_middlenameactive').hide();
$('#gc_middlenamepassive').show();
$('.gc_middlename_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_middlename_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>