<?php
if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/cardm.css" rel="stylesheet">';}
if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1cardm.css" rel="stylesheet">';}


$gc_firstname_status = $_SESSION['gc_firstname_status'];
$gc_middlename_status = $_SESSION['gc_middlename_status'];
$gc_lastname_status = $_SESSION['gc_lastname_status'];
$gc_nickname_status = $_SESSION['gc_nickname_status'];
$gc_gender_status = $_SESSION['gc_gender_status'];
$gc_age_status = $_SESSION['gc_age_status'];
$gc_homenumber_status = $_SESSION['gc_homenumber_status'];
$gc_cell_status = $_SESSION['gc_cell_status'];
$gc_whatsapp_status = $_SESSION['gc_whatsapp_status'];
$gc_email_status = $_SESSION['gc_email_status'];
?>


<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#myGeneralInfo">My Social Details <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="myGeneralInfo" class="accordion-body collapse in">
    	

			    <p class="help-block">You will find that however the info provided does display in the appropriate fields the permissions still need to be set
			    <br>
			    <ul>
			        <li><strong>Public</strong> - Once you exchange your card all info marked with "Public" will emidiately be available to such person.</li>
			        <li><strong>On Request</strong> - Info marked with "On Request" will not be visible but may be requested and once you aprove such person will have access to such information.</li>
			        <li><strong>Only Me</strong> - Any information marked as "Only Me" is private and can not be requested it will also not be made available to anyone.</li>
			    </ul>
			    </p>
			    
<form id="gc_network_handles" method="post" action="" autocomplete="off">   

		<div id="gc_firstname_field" class="groupl2" <?php if($gc_firstname_status == 'gc_firstnameactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
									    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_firstname.php';?>							
	    </div>
	    
	    
	    <div id="gc_middlename_field" class="groupl2" <?php if($gc_middlename_status == 'gc_middlenameactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
									    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_middlename.php';?>							
	    </div>
	    
	    
		<div id="gc_lastname_field" class="groupl2" <?php if($gc_lastname_status == 'gc_lastnameactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_lastname.php'; ?> 
	    </div>
	    
	    
		<div id="gc_nickname_field" class="groupl2" <?php if($gc_nickname_status == 'gc_nicknameactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_nickname.php'; ?>
	    </div>
	    
	    
		<div id="gc_gender_field" class="groupl2" <?php if($gc_gender_status == 'gc_genderactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_gender.php'; ?>
		</div>
		
		
		<div id="gc_age_field" class="groupl2" <?php if($gc_age_status == 'gc_ageactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>								
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_age.php'; ?>
	    </div>
	    
	    
		<div id="gc_homenumber_field" class="groupl2" <?php if($gc_homenumber_status == 'gc_homenumberactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_homenumber.php'; ?>
	    </div>
	    
	    
		<div id="gc_cell_field" class="groupl2" <?php if($gc_cell_status == 'gc_cellactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_cell.php'; ?>
        </div>
        
        
        <div id="gc_whatsapp_field" class="groupl2" <?php if($gc_whatsapp_status == 'gc_whatsappactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_whatsapp.php'; ?>
        </div>
        

        <div id="gc_email_field" class="groupl2" <?php if($gc_email_status == 'gc_emailactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_email.php'; ?>
        </div>
</form>


		</div>
	</div>		

	

<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#myNetworks">My Social Networks <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="myNetworks" class="accordion-body collapse in">	
				
			<p class="help-block">Select the networks you have a profile for and that you wish to share on your social card.</p>	


		<div class="select-cat" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_facebook_status.php';
	                    ?>
					</div>
					<span class="name">facebook</span>
                        <p class="category">Community</p>
		</div>
		
		<div class="select-cat" catname="Blogging" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_twitter_status.php';
	                    ?>
					</div>
					<span class="name">Twitter</span>
                        <p class="category">Blogging</p>
		</div>
		
		<div class="select-cat" catname="Community" style="visibility: visible; display: block;">
				
					<div>
						<?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/fields/gc_googleP_status.php';
	                    ?>
					</div>
					<span class="name">Google+</span>
                        <p class="category">Community</p>
		</div>
												
	            <div style="clear:both;"></div>         
                        
                        <hr>

				
				                <?php include '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/gc/data/gc_network_profiles.php';?>				
	

		    </div>	
		</div>
	</div>	
</div>	





<script>
$(document).ready(function(){
	$('input[name=\'gc_firstname_status\']').click(function(){
  	var gc_firstname_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_firstname_status.php',
        method:'POST',
        data:{gc_firstname_status:gc_firstname_status},
        success: function(gc_firstnameresponse){
                    gc_firstname_status_result = gc_firstnameresponse;
                    
                    if (gc_firstname_status_result == 'gc_firstnameactive')
                        $("#gc_firstname_field").show();
                    else    
                        $("#gc_firstname_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_middlename_status\']').click(function(){
  	var gc_middlename_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_middlename_status.php',
        method:'POST',
        data:{gc_middlename_status:gc_middlename_status},
        success: function(gc_middlenameresponse){
                    gc_middlename_status_result = gc_middlenameresponse;
                    console.log(gc_middlename_status_result);
                    
                    if (gc_middlename_status_result == 'gc_middlenameactive')
                        $("#gc_middlename_field").show();
                    else    
                        $("#gc_middlename_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_lastname_status\']').click(function(){
  	var gc_lastname_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_lastname_status.php',
        method:'POST',
        data:{gc_lastname_status:gc_lastname_status},
        success: function(gc_lastnameresponse){
                    gc_lastname_status_result = gc_lastnameresponse;
                    
                    if (gc_lastname_status_result == 'gc_lastnameactive')
                        $("#gc_lastname_field").show();
                    else    
                        $("#gc_lastname_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_nickname_status\']').click(function(){
  	var gc_nickname_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_nickname_status.php',
        method:'POST',
        data:{gc_nickname_status:gc_nickname_status},
        success: function(gc_nicknameresponse){
                    gc_nickname_status_result = gc_nicknameresponse;
                    //console.log(gc_nickname_status_result);
                    
                    if (gc_nickname_status_result == 'gc_nicknameactive')
                        $("#gc_nickname_field").show();
                    else    
                        $("#gc_nickname_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_gender_status\']').click(function(){
  	var gc_gender_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_gender_status.php',
        method:'POST',
        data:{gc_gender_status:gc_gender_status},
        success: function(gc_genderresponse){
                    gc_gender_status_result = gc_genderresponse;
                    
                    if (gc_gender_status_result == 'gc_genderactive')
                        $("#gc_gender_field").show();
                    else    
                        $("#gc_gender_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_age_status\']').click(function(){
  	var gc_age_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_age_status.php',
        method:'POST',
        data:{gc_age_status:gc_age_status},
        success: function(gc_ageresponse){
                    gc_age_status_result = gc_ageresponse;
                    //console.log(gc_age_status_result);
                    
                    if (gc_age_status_result == 'gc_ageactive')
                        $("#gc_age_field").show();
                    else    
                        $("#gc_age_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_homenumber_status\']').click(function(){
  	var gc_homenumber_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_homenumber_status.php',
        method:'POST',
        data:{gc_homenumber_status:gc_homenumber_status},
        success: function(gc_homenumberresponse){
                    gc_homenumber_status_result = gc_homenumberresponse;
                    //console.log(gc_homenumber_status_result);
                    
                    if (gc_homenumber_status_result == 'gc_homenumberactive')
                        $("#gc_homenumber_field").show();
                    else    
                        $("#gc_homenumber_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_cell_status\']').click(function(){
  	var gc_cell_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_cell_status.php',
        method:'POST',
        data:{gc_cell_status:gc_cell_status},
        success: function(gc_cellresponse){
                    gc_cell_status_result = gc_cellresponse;
                    //console.log(gc_cell_status_result);
                    
                    if (gc_cell_status_result == 'gc_cellactive')
                        $("#gc_cell_field").show();
                    else    
                        $("#gc_cell_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_whatsapp_status\']').click(function(){
  	var gc_whatsapp_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_whatsapp_status.php',
        method:'POST',
        data:{gc_whatsapp_status:gc_whatsapp_status},
        success: function(gc_whatsappresponse){
                    gc_whatsapp_status_result = gc_whatsappresponse;
                    //console.log(gc_whatsapp_status_result);
                    
                    if (gc_whatsapp_status_result == 'gc_whatsappactive')
                        $("#gc_whatsapp_field").show();
                    else    
                        $("#gc_whatsapp_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'gc_email_status\']').click(function(){
  	var gc_email_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/gc/data/functions/func_gc_email_status.php',
        method:'POST',
        data:{gc_email_status:gc_email_status},
        success: function(gc_emailresponse){
                    gc_email_status_result = gc_emailresponse;
                    //console.log(gc_email_status_result);
                    
                    if (gc_email_status_result == 'gc_emailactive')
                        $("#gc_email_field").show();
                    else    
                        $("#gc_email_field").hide();
                  } 
        });
  });
});
</script>

