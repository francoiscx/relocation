<?php
$pc_officenumber = "pc_officenumber";
$pc_officenumber_perm = "pc_officenumber_perm";
$pc_officenumber_status = "pc_officenumber_status";
?>

<!-- Start of Textfield for pc_officenumber -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_officenumber: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_officenumber = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_officenumber(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_officenumber(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_officenumber').donetypingpc_officenumber(function(){
  	var pc_officenumber = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_officenumber.php",
        method:"POST",
        data:{pc_officenumber:pc_officenumber},
        success: function(data){
      	$('#pc_officenumber_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_officenumber = $_SESSION['pc_officenumber'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_officenumber">Office Number&nbsp<span><h5 id="pc_officenumber_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_officenumber" name="pc_officenumber" value="<?php echo $pc_officenumber; ?>">
            
<!-- End of Textfield for pc_officenumber -->






<!-- Start of Radio Buttons for pc_officenumber_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_officenumber_perm"]').click(function(){
  	var pc_officenumber_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_officenumber_perm.php",
        method:"POST",
        data:{pc_officenumber_perm:pc_officenumber_perm},
        success: function(data){
      	$('#pc_officenumber_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_officenumber_perm = $_SESSION['pc_officenumber_perm'];
switch ($pc_officenumber_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_officenumber_perm_pub" name="pc_officenumber_perm" checked="checked" value="Public">
                <label for="pc_officenumber_perm_pub" id="pc_officenumber_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_officenumber_perm_req" name="pc_officenumber_perm" value="Request">
                <label for="pc_officenumber_perm_req" id="pc_officenumber_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_officenumber_perm_pri" name="pc_officenumber_perm" value="Private">
                <label for="pc_officenumber_perm_pri" id="pc_officenumber_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_officenumber_perm_pub" name="pc_officenumber_perm" value="Public">
                <label for="pc_officenumber_perm_pub" id="pc_officenumber_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_officenumber_perm_req" name="pc_officenumber_perm" checked="checked" value="Request">
                <label for="pc_officenumber_perm_req" id="pc_officenumber_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_officenumber_perm_pri" name="pc_officenumber_perm" value="Private">
                <label for="pc_officenumber_perm_pri" id="pc_officenumber_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_officenumber_perm_pub" name="pc_officenumber_perm" value="Public">
                <label for="pc_officenumber_perm_pub" id="pc_officenumber_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_officenumber_perm_req" name="pc_officenumber_perm" value="Request">
                <label for="pc_officenumber_perm_req" id="pc_officenumber_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_officenumber_perm_pri" name="pc_officenumber_perm" checked="checked" value="Private">
                <label for="pc_officenumber_perm_pri" id="pc_officenumber_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_officenumber_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for pc_officenumber_perm -->
