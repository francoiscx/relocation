<?php
//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

//process the form if the reset password button is clicked
if (isset($_POST['hp_street_name'])) {
    //initialize an array to store any error message from the form
    $form_errors = array();

    //check if error array is empty, if yes process form data and insert record
    if(empty($form_errors)){
        //collect form data and store in variables
        $email = $_SESSION['email'];
        
        $hp_street_name = $_POST['hp_street_name'];
        $hp_number = $_POST['hp_number'];
        $hp_suburb = $_POST['hp_suburb'];
        $hp_city = $_POST['hp_city'];
        $hp_province = $_POST['hp_province'];
        $hp_code = $_POST['hp_code'];
        $hp_country = $_POST['hp_country']; 
        
        	//Fields to change Case to Name
		$hp_street_name = name_field($hp_street_name);
		$hp_number = name_field($hp_number);
		$hp_suburb = name_field($hp_suburb);		
		$hp_city = name_field($hp_city);
		$hp_province = name_field($hp_province);
		$hp_code = name_field($hp_code);
		$hp_country = name_field($hp_country);
        
        //check if all info is inserted
        if(!isset($_POST['hp_street_name'])) {
            $result = "Please provide the full information";
            
        }else{
            try{
                //create SQL select statement to verify if email address input exist in the database
                $sqlQuery = "SELECT email FROM users WHERE email =:email";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':email' => $email));

                //check if record exist
                if($statement->rowCount() == 1){

                    //SQL statement to update info
                    $sqlUpdate = "UPDATE users SET hp_street_name =:hp_street_name, hp_number =:hp_number, hp_suburb =:hp_suburb, hp_city =:hp_city, hp_province =:hp_province, hp_code =:hp_code, hp_country =:hp_country WHERE email=:email";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':hp_street_name' => $hp_street_name, ':hp_number' => $hp_number, ':hp_suburb' => $hp_suburb, ':hp_city' => $hp_city, ':hp_province' => $hp_province, ':hp_code' => $hp_code, ':hp_country' => $hp_country, ':email' => $email));

                    $result = "Your details was successfully updated";
			if(isset($hp_street_name)) $_SESSION['hp_street_name'] = $hp_street_name;
			if(isset($hp_number)) $_SESSION['hp_number'] = $hp_number;
			if(isset($hp_suburb)) $_SESSION['hp_suburb'] = $hp_suburb;
			if(isset($hp_city)) $_SESSION['hp_city'] = $hp_city;
			if(isset($hp_province)) $_SESSION['hp_province'] = $hp_province;
			if(isset($hp_code)) $_SESSION['hp_code'] = $hp_code;	
			if(isset($hp_country)) $_SESSION['hp_country'] = $hp_country;
                }
                else{
                    $result = "The email address provided does not exist in our database, please try again";
                }
            }catch (PDOException $ex){
                $result = "An error occurred: ".$ex->getMessage();
            }
        }
    }
    else{
        if(count($form_errors) == 1){
            $result = "There was 1 error in the form";
        }else{
            $result = "There were " .count($form_errors). " errors in the form";
        }
    }
}
?>
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>