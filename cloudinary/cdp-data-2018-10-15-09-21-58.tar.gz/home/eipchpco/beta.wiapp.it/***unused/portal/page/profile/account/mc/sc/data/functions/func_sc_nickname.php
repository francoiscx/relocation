<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$sc_nickname = $_POST['sc_nickname'];

//process the form if the button is clicked
if (isset($_POST['sc_nickname'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE social_card SET sc_nickname =:sc_nickname WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_nickname' => $sc_nickname, ':userID' => $userID));

                    $sc_nickname_result = "Success";
                    $_SESSION['sc_nickname'] = $sc_nickname;
                    
                 }catch (PDOException $ex){
                $sc_nickname_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO social_card (userID, sc_nickname)
                        VALUES (:userID, :sc_nickname)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':sc_nickname' => $sc_nickname));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $sc_nickname_result = "Data was successfully captured";
                }
   
                    $sc_nickname_result = "Success";
                    
                    $_SESSION['sc_nickname'] = $sc_nickname;
                }
            }catch (PDOException $ex){
                $sc_nickname_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $sc_nickname_result
?>

