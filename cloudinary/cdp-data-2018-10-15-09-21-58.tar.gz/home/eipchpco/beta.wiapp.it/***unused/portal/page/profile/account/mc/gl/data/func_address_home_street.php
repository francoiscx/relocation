<?php
//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

//process the form if the reset password button is clicked
if (isset($_POST['hs_street_name'])) {
    //initialize an array to store any error message from the form
    $form_errors = array();

    //check if error array is empty, if yes process form data and insert record
    if(empty($form_errors)){
        //collect form data and store in variables
        $email = $_SESSION['email'];
        
        $hs_street_name = $_POST['hs_street_name'];
        $hs_number      = $_POST['hs_number'];
        $hs_suburb      = $_POST['hs_suburb'];
        $hs_city        = $_POST['hs_city'];
        $hs_province    = $_POST['hs_province'];
        $hs_country     = $_POST['hs_country']; 
        
        	//Fields to change Case to Name
		$hs_street_name = name_field($hs_street_name);
		$hs_suburb 	= name_field($hs_suburb);		
		$hs_city 	= name_field($hs_city);
		$hs_province 	= name_field($hs_province);
		$hs_country 	= name_field($hs_country);
        
        //check if user is old enough
        if(!isset($_POST['hs_street_name'])) {
            $result = "Please provide the full information";
        }else{
            try{
                //create SQL select statement to verify if email address input exist in the database
                $sqlQuery = "SELECT email FROM users WHERE email =:email";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':email' => $email));

                //check if record exist
                if($statement->rowCount() == 1){

                    //SQL statement to update info
                    $sqlUpdate = "UPDATE users SET hs_street_name =:hs_street_name, hs_number =:hs_number, hs_suburb =:hs_suburb, hs_city =:hs_city, hs_province =:hs_province, hs_country =:hs_country WHERE email=:email";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':hs_street_name' => $hs_street_name, ':hs_number' => $hs_number, ':hs_suburb' => $hs_suburb, ':hs_city' => $hs_city, ':hs_province' => $hs_province, ':hs_country' => $hs_country, ':email' => $email));

                    $result = "Your details was successfully updated";
			if(isset($hs_street_name)) $_SESSION['hs_street_name'] = $hs_street_name;
			if(isset($hs_number))      $_SESSION['hs_number']      = $hs_number;
			if(isset($hs_suburb))      $_SESSION['hs_suburb']      = $hs_suburb;
			if(isset($hs_city))        $_SESSION['hs_city']        = $hs_city; 
			if(isset($hs_province))    $_SESSION['hs_province']    = $hs_province;	
			if(isset($hs_country))     $_SESSION['hs_country']     = $hs_country;
                }
                else{
                    $result = "The email address provided does not exist in our database, please try again";
                }
            }catch (PDOException $ex){
                $result = "An error occurred: ".$ex->getMessage();
            }
        }
    }
    else{
        if(count($form_errors) == 1){
            $result = "There was 1 error in the form";
        }else{
            $result = "There were " .count($form_errors). " errors in the form";
        }
    }
}
?>
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>