<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$pc_facebook_status = $_POST['pc_facebook_status'];

//process the form if the button is clicked
if (isset($_POST['pc_facebook_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlpc_facebook_statusQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlpc_facebook_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlpc_facebook_statusUpdate = "UPDATE professional_card SET pc_facebook_status =:pc_facebook_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlpc_facebook_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_facebook_status' => $pc_facebook_status, ':userID' => $userID));

                    $pc_facebook_status_result = 'pc_facebook_status';
                    $_SESSION['pc_facebook_status'] = $pc_facebook_status;
                
                 }catch (PDOException $ex){
                $pc_facebook_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlpc_facebook_statusInsert = "INSERT INTO professional_card (userID, pc_facebook_status)
                    VALUES (:userID, :pc_facebook_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlpc_facebook_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':pc_facebook_status' => $pc_facebook_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $pc_facebook_status_result = 'pc_facebook_status';
                    $_SESSION['pc_facebook_status'] = $pc_facebook_status;
	    	        }
                }
            }catch (PDOException $ex){
                $pc_facebook_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($pc_facebook_status == pc_facebookactive) echo "pc_facebookactive";
 else if ($pc_facebook_status != pc_facebookactive) echo "pc_facebookpassive";

?>