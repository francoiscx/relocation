<!-- Start of Radio Buttons for gc_nickname_status -->
<div class="groupl">

<?php

$gc_nickname_status = $_SESSION['gc_nickname_status'];

if(!isset($gc_nickname_status)) {$gc_nickname_status = 'gc_nicknamepassive'; }



//echo $gc_nickname_status;

switch ($gc_nickname_status) {
    case "gc_nicknameactive":
        echo "
<div>

    <div class='gc_nickname_selection' id='gc_nicknameactive'>
    <a class='gc_nickname_selectionSwitch' href='#gc_nicknamepassive'><input type='radio' id='gc_nickname_status_on' name='gc_nickname_status' value='gc_nicknamepassive' hidden> 
    <label for='gc_nickname_status_on' class='gc_nickname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Nickname
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_nickname_selection' id='gc_nicknamepassive'>
    <a class='gc_nickname_selectionSwitch' href='#gc_nicknameactive'><input type='radio' id='gc_nickname_status_off' name='gc_nickname_status' value='gc_nicknameactive' hidden>
    <label for='gc_nickname_status_off' class='gc_nickname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Nickname
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_nickname_status').on('click', function () {
        check = $('#gc_nickname_status').prop('checked');
        
        if (check) {
            if ($('.gc_nickname_Check i').hasClass('icon-check-square')) {
                $('.gc_nickname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_nickname_Check i').hasClass('icon-square-o')) {
                $('.gc_nickname_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_nickname_status = $('#gc_nicknameactive, #gc_nicknamepassive').hide();
$('#gc_nicknameactive').show();
$('#gc_nicknamepassive').hide();
$('.gc_nickname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_nickname_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_nicknamepassive":
        echo "
<div>

  <div class='gc_nickname_selection' id='gc_nicknamepassive'>
    <a class='gc_nickname_selectionSwitch' href='#gc_nicknameactive'><input type='radio' id='gc_nickname_status_off' name='gc_nickname_status' value='gc_nicknameactive' hidden>
    <label for='gc_nickname_status_off' class='gc_nickname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Nickname
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_nickname_selection' id='gc_nicknameactive'>
    <a class='gc_nickname_selectionSwitch' href='#gc_nicknamepassive'><input type='radio' id='gc_nickname_status_on' name='gc_nickname_status' value='gc_nicknamepassive' hidden>
    <label for='gc_nickname_status_on' class='gc_nickname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Nickname
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_nickname_status').on('click', function () {
        check = $('#gc_nickname_status').prop('checked');
        
        if (check) {
            if ($('.gc_nickname_Check i').hasClass('icon-square-o')) {
                $('.gc_nickname_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_nickname_Check i').hasClass('icon-check-square')) {
                $('.gc_nickname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_nickname_status = $('#gc_nicknameactive, #gc_nicknamepassive').hide();
$('#gc_nicknameactive').hide();
$('#gc_nicknamepassive').show();
$('.gc_nickname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_nickname_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_nickname_selection' id='gc_nicknamepassive'>
    <a class='gc_nickname_selectionSwitch' href='#gc_nicknameactive'><input type='radio' id='gc_nickname_status_off' name='gc_nickname_status' value='gc_nicknameactive' hidden>
    <label for='gc_nickname_status_off' class='gc_nickname_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Nickname
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_nickname_selection' id='gc_nicknameactive'>
    <a class='gc_nickname_selectionSwitch' href='#gc_nicknamepassive'><input type='radio' id='gc_nickname_status_on' name='gc_nickname_status' value='gc_nicknamepassive' hidden>
    <label for='gc_nickname_status_on' class='gc_nickname_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Nickname
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_nickname_status').on('click', function () {
        check = $('#gc_nickname_status').prop('checked');
        
        if (check) {
            if ($('.gc_nickname_Check i').hasClass('icon-square-o')) {
                $('.gc_nickname_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_nickname_Check i').hasClass('icon-check-square')) {
                $('.gc_nickname_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_nickname_status = $('#gc_nicknameactive, #gc_nicknamepassive').hide();
$('#gc_nicknameactive').hide();
$('#gc_nicknamepassive').show();
$('.gc_nickname_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_nickname_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>