<?php 
			if(!isset($hs_city)) $hs_city = $_SESSION['city'];
			if(!isset($hp_city)) $hp_city = $_SESSION['city'];
			if(!isset($ws_city)) $ws_city = $_SESSION['city'];
			if(!isset($wp_city)) $wp_city = $_SESSION['city'];
			
			if(!isset($hs_province)) $hs_province = $_SESSION['province'];
			if(!isset($hp_province)) $hp_province = $_SESSION['province'];
			if(!isset($ws_province)) $ws_province = $_SESSION['province'];
			if(!isset($wp_province)) $wp_province = $_SESSION['province'];
			
			if(!isset($hs_country)) $hs_country = $_SESSION['country'];
			if(!isset($hp_country)) $hp_country = $_SESSION['country'];
			if(!isset($ws_country)) $ws_country = $_SESSION['country'];
			if(!isset($wp_country)) $wp_country = $_SESSION['country'];
?>


<p class="help-block">These details will not be shown to anyone.<br>This will serve as a quick reference when you want to share any of it on a later stage.</p>


<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseHomePhysical">Home Physical Address <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="collapseHomePhysical" class="accordion-body collapse">
    	
			<form action="/portal/page/profile/account/mc/gl/data/func_address_home_street.php" method="post" class="ajax">	

				<div class="groupll" style="min-height:220px">
				<h3>Home Physical Address</h3>
					<div>											
						<label style="font-size:13px">Number</label>
						<input type="number" id="hs_number" name="hs_number" value="<?php echo $_SESSION['hs_number']; ?>" placeholder="Number">
					</div>
					
					<div>											
						<label style="font-size:13px">Street Name</label>
						<input type="text" id="hs_street_name" name="hs_street_name" value="<?php echo $_SESSION['hs_street_name']; ?>" placeholder="Street name">			
					</div> 
	
					<div>											
						<label style="font-size:13px">Suburb</label>
						<input type="text" id="hs_suburb" name="hs_suburb" value="<?php echo $_SESSION['hs_suburb']; ?>" placeholder="Suburb">
					</div>
							
<?php if($notmobile == 101) { echo '</div><div class="groupll2" style="min-height:220px"><br>';}?>

					<div>
						<label style="font-size:13px">City</label>
						<input type="text" id="hs_city" name="hs_city" value="<?php echo $_SESSION['hs_city']; ?>" placeholder="City">
					</div>
			
					<div>
						<label style="font-size:13px">Province</label>
						<input type="text" id="hs_province" name="hs_province" value="<?php echo $_SESSION['hs_province']; ?>" placeholder="Province">
					</div>

					<div>
						<label style="font-size:13px">Country</label>
						<input type="text" id="hs_counrty" name="hs_country" value="<?php echo $_SESSION['hs_country']; ?>" placeholder="Country">
					</div>
			    </div>
			    <div class="col-sm-10">
					<div class="groupBtn">
       						<input type="submit" value="Save" class="button btn btn-primary btn-medium" float="right">	
					</div>	
				</div>
			</form>	
		</div>
	</div>		
	
	

<div class="accordion" style=" left-padding:0px; left-margin:10px" id="accordion3">
	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseHomePostal">Home Postal Address <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="collapseHomePostal" class="accordion-body collapse">	
									
			<form action="/portal/page/profile/account/mc/gl/data/func_address_home_postal.php" method="post" class="ajax">
	
				<div class="groupll" style="min-height:220px">				
				<h3>Home Postal Address</h3>
					<div>											
						<label style="font-size:13px">Number</label>
						<input type="number" id="hp_number" name="hp_number" value="<?php echo $_SESSION['hp_number']; ?>" placeholder="Number">
					</div>
					
					<div>											
						<label style="font-size:13px">Street Name</label>
						<input type="text" id="hp_street_name" name="hp_street_name" value="<?php echo $_SESSION['hp_street_name']; ?>" placeholder="Street name">
					</div> 
				
					<div>											
						<label style="font-size:13px">Suburb</label>
						<input type="text" id="hp_suburb" name="hp_suburb" value="<?php echo $_SESSION['hp_suburb']; ?>" placeholder="Suburb">
					</div>
			
					<div>
						<label style="font-size:13px">City</label>
						<input type="text" id="hp_city" name="hp_city" value="<?php echo $_SESSION['hp_city']; ?>" placeholder="City">
					</div>
			
<?php if($notmobile == 101) { echo '</div><div class="groupll2" style="min-height:220px"><br>';}?>

					<div>
						<label style="font-size:13px">Province</label>
						<input type="text" id="hp_province" name="hp_province" value="<?php echo $_SESSION['hp_province']; ?>" placeholder="Province">
					</div>
			
					<div>
						<label style="font-size:13px">Postal Code</label>
						<input type="text" id="hp_code" name="hp_code" value="<?php echo $_SESSION['hp_code']; ?>" placeholder="Postal Code">
					</div>
			
					<div>
						<label style="font-size:13px">Country</label>
						<input type="text" id="hp_country" name="hp_country" value="<?php echo $_SESSION['hp_country']; ?>" placeholder="Country">
					</div>		
		        </div>	
					<div class="col-sm-10">
					<div class="groupBtn">
       						<input type="submit" value="Save" class="button btn btn-primary btn-medium" float="right">	
					</div>	
				</div>	
				
			</form>	
				
		</div>
	</div>	

	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseWorkPhysical">Work Physical Address <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="collapseWorkPhysical" class="accordion-body collapse">
			
				<form action="/portal/page/profile/account/mc/gl/data/func_address_work_street.php" method="post" class="ajax">
	
				<div class="groupll" style="min-height:220px">
				<h3>Work Physical Address</h3>
					<div>											
						<label style="font-size:13px">Number</label>
						<input type="text" id="ws_number" name="ws_number" value="<?php echo $_SESSION['ws_number']; ?>" placeholder="Number">
					</div>
					
					<div>											
						<label style="font-size:13px">Street Name</label>
						<input type="text" id="ws_street_name" name="ws_street_name" value="<?php echo $_SESSION['ws_street_name']; ?>" placeholder="Street name">			
					</div> 
																					
					<div>											
						<label style="font-size:13px">Suburb</label>
						<input type="text" id="ws_suburb" name="ws_suburb" value="<?php echo $_SESSION['ws_suburb']; ?>" placeholder="Suburb">
					</div>
			
<?php if($notmobile == 101) { echo '</div><div class="groupll2" style="min-height:220px"><br>';}?>			
			
					<div>
						<label style="font-size:13px">City</label>
						<input type="text" id="ws_city" name="ws_city" value="<?php echo $_SESSION['ws_city']; ?>" placeholder="City">
					</div>
			
					<div>
						<label style="font-size:13px">Province</label>
						<input type="text" id="ws_province" name="ws_province" value="<?php echo $_SESSION['ws_province']; ?>" placeholder="Province">
					</div>
					
					<div>
						<label style="font-size:13px">Country</label>
						<input type="text" id="ws_country" name="ws_country" value="<?php echo $_SESSION['ws_country']; ?>" placeholder="Country">
					</div>
			
		    	</div>
					<div class="col-sm-10">
					<div class="groupBtn">
       						<input type="submit" value="Save" class="button btn btn-primary btn-medium" float="right">	
						
				</div>					
			</form>						
			</div>		
		</div>
	</div>
	
	
	
	

	<div class="accordion-in">
		<div class="accordion-heading"><a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseWorkPostal">Work Postal Address <span style="float:right"><i class="icon-down-open"></i></span></a>
		</div>
		<div id="collapseWorkPostal" class="accordion-body collapse">
			
				<form action="/portal/page/profile/account/mc/gl/data/func_address_work_postal.php" method="post" class="ajax">
	
				<div class="groupll" style="min-height:220px">
							
				<h3>Work Postal Address</h3>
					<div>											
						<label style="font-size:13px">Number</label>
						<input type="text" id="wp_number" name="wp_number" value="<?php echo $_SESSION['wp_number']; ?>" placeholder="Number">
					</div>
					
					<div>											
						<label style="font-size:13px">Street Name</label>
						<input type="text" id="wp_street_name" name="wp_street_name" value="<?php echo $_SESSION['wp_street_name']; ?>" placeholder="Street name">
					</div> 
																					
					<div>											
						<label style="font-size:13px">Suburb</label>
						<input type="text" id="wp_suburb" name="wp_suburb" value="<?php echo $_SESSION['wp_suburb']; ?>" placeholder="Suburb">
					</div>
			
					<div>
						<label style="font-size:13px">City</label>
						<input type="text" id="wp_city" name="wp_city" value="<?php echo $_SESSION['wp_city']; ?>" placeholder="City">
					</div>
									
					
<?php if($notmobile == 101) { echo '</div><div class="groupll2" style="min-height:220px"><br>';}?>			
			
					<div>
						<label style="font-size:13px">Province</label>
						<input type="text" id="wp_province" name="wp_province" value="<?php echo $_SESSION['wp_province']; ?>" placeholder="Province">
					</div>
			
					<div>
						<label style="font-size:13px">Postal Code</label>
						<input type="text" id="wp_code" name="wp_code" value="<?php echo $_SESSION['wp_code']; ?>" placeholder="Postal Code">
					</div>
					
					<div>
						<label style="font-size:13px">Country</label>
						<input type="text" id="wp_country" name="wp_country" value="<?php echo $_SESSION['wp_country']; ?>" placeholder="Country">
					</div>					

				</div>
					<div class="col-sm-10">
					<div class="groupBtn">
       						<input type="submit" value="Save" class="button btn btn-primary btn-medium" float="right">	
					</div>	
				</div>				
		
			    </form>	 

		   		
		</div>
	</div>
</div>	