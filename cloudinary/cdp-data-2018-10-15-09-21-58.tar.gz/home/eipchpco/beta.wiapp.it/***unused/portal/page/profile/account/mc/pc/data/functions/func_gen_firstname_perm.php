<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gen_firstname_perm = $_POST['gen_firstname_perm'];

//process the form if the button is clicked
if (isset($_POST['gen_firstname_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlgen_firstname_permQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgen_firstname_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgen_firstname_permUpdate = "UPDATE professional_card SET gen_firstname_perm =:gen_firstname_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgen_firstname_permUpdate);

                    //execute the statement
                    $statement->execute(array(':gen_firstname_perm' => $gen_firstname_perm, ':userID' => $userID));

                    $gen_firstname_result = "Update Successful";
                    $_SESSION['gen_firstname_perm'] = $gen_firstname_perm;
                
                 }catch (PDOException $ex){
                $gen_firstname_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlgen_firstname_permInsert = "INSERT INTO professional_card (userID, gen_firstname_perm)
                    VALUES (:userID, :gen_firstname_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgen_firstname_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gen_firstname_perm' => $gen_firstname_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gen_firstname_result = "Card created";
                    $_SESSION['gen_firstname_perm'] = $gen_firstname_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $gen_firstname_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $gen_firstname_result
?>