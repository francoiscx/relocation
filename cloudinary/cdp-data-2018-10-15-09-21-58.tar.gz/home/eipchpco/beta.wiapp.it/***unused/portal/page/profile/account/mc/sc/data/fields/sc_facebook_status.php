<!-- Start of Radio Buttons for sc_facebook_status -->
<div class="groupl">

<?php

$sc_facebook_status = $_SESSION['sc_facebook_status'];

if(!isset($sc_facebook_status)) {$sc_facebook_status = 'sc_facebookpassive'; }



//echo $sc_facebook_status;

switch ($sc_facebook_status) {
    case "sc_facebookactive":
        echo "
<div>

    <div class='sc_facebook_selection' id='sc_facebookactive'>
    <a class='sc_facebook_selectionSwitch' href='#sc_facebookpassive'><input type='radio' id='sc_facebook_status_on' name='sc_facebook_status' value='sc_facebookpassive' hidden> 
    <label for='sc_facebook_status_on' class='sc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='sc_facebook_selection' id='sc_facebookpassive'>
    <a class='sc_facebook_selectionSwitch' href='#sc_facebookactive'><input type='radio' id='sc_facebook_status_off' name='sc_facebook_status' value='sc_facebookactive' hidden>
    <label for='sc_facebook_status_off' class='sc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#sc_facebook_status').on('click', function () {
        check = $('#sc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.sc_facebook_Check i').hasClass('icon-check-square')) {
                $('.sc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.sc_facebook_Check i').hasClass('icon-square-o')) {
                $('.sc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_facebook_status = $('#sc_facebookactive, #sc_facebookpassive').hide();
$('#sc_facebookactive').show();
$('#sc_facebookpassive').hide();
$('.sc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_facebook_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "sc_facebookpassive":
        echo "
<div>

  <div class='sc_facebook_selection' id='sc_facebookpassive'>
    <a class='sc_facebook_selectionSwitch' href='#sc_facebookactive'><input type='radio' id='sc_facebook_status_off' name='sc_facebook_status' value='sc_facebookactive' hidden>
    <label for='sc_facebook_status_off' class='sc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='sc_facebook_selection' id='sc_facebookactive'>
    <a class='sc_facebook_selectionSwitch' href='#sc_facebookpassive'><input type='radio' id='sc_facebook_status_on' name='sc_facebook_status' value='sc_facebookpassive' hidden>
    <label for='sc_facebook_status_on' class='sc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#sc_facebook_status').on('click', function () {
        check = $('#sc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.sc_facebook_Check i').hasClass('icon-square-o')) {
                $('.sc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.sc_facebook_Check i').hasClass('icon-check-square')) {
                $('.sc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_facebook_status = $('#sc_facebookactive, #sc_facebookpassive').hide();
$('#sc_facebookactive').hide();
$('#sc_facebookpassive').show();
$('.sc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_facebook_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='sc_facebook_selection' id='sc_facebookpassive'>
    <a class='sc_facebook_selectionSwitch' href='#sc_facebookactive'><input type='radio' id='sc_facebook_status_off' name='sc_facebook_status' value='sc_facebookactive' hidden>
    <label for='sc_facebook_status_off' class='sc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='sc_facebook_selection' id='sc_facebookactive'>
    <a class='sc_facebook_selectionSwitch' href='#sc_facebookpassive'><input type='radio' id='sc_facebook_status_on' name='sc_facebook_status' value='sc_facebookpassive' hidden>
    <label for='sc_facebook_status_on' class='sc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#sc_facebook_status').on('click', function () {
        check = $('#sc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.sc_facebook_Check i').hasClass('icon-square-o')) {
                $('.sc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.sc_facebook_Check i').hasClass('icon-check-square')) {
                $('.sc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_facebook_status = $('#sc_facebookactive, #sc_facebookpassive').hide();
$('#sc_facebookactive').hide();
$('#sc_facebookpassive').show();
$('.sc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_facebook_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>