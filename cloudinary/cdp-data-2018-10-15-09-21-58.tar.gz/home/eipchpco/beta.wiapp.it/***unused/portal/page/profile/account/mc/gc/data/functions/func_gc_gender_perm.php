<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gc_gender_perm = $_POST['gc_gender_perm'];

//process the form if the button is clicked
if (isset($_POST['gc_gender_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlgc_gender_permQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgc_gender_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgc_gender_permUpdate = "UPDATE general_card SET gc_gender_perm =:gc_gender_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgc_gender_permUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_gender_perm' => $gc_gender_perm, ':userID' => $userID));

                    $gc_gender_result = "Success";
                    $_SESSION['gc_gender_perm'] = $gc_gender_perm;
                
                 }catch (PDOException $ex){
                $gc_gender_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlgc_gender_permInsert = "INSERT INTO general_card (userID, gc_gender_perm)
                    VALUES (:userID, :gc_gender_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgc_gender_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gc_gender_perm' => $gc_gender_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gc_gender_result = "Success";
                    $_SESSION['gc_gender_perm'] = $gc_gender_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $gc_gender_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $gc_gender_result
?>