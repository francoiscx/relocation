<?php
//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

 

//process the form if the reset password button is clicked
if(!empty($_POST['gender'] || $_POST['country'] || $_POST['dob_day'])) {
    
    //initialize an array to store any error message from the form
    $form_errors = array();

    //check if error array is empty, if yes process form data and insert record
    if(empty($form_errors)){
        //collect form data and store in variables
        $userID = $_SESSION['id'];
        $email = $_SESSION['email'];
        
        if(isset($_POST['gender'])) {$gender = $_POST['gender'];
        }else{
        $gender = $_SESSION['gender'];
        }
        
    if(empty($_SESSION['dob'])) {
        	$dob_day = $_POST['dob_day'];
    		$dob_month = $_POST['dob_month'];
    		$dob_year = $_POST['dob_year'];
    	
    		$dob = $_POST['dob_day'].'/'.$_POST['dob_month'].'/'.$_POST['dob_year'];
    	}else{
    		$dob = $_SESSION['dob'];
    	}
    	
    	
    	
        //date in mm/dd/yyyy format; or it can be in other formats as well
        $dobForAge = $_POST['dob_month'].'/'.$_POST['dob_day'].'/'.$_POST['dob_year'];
        //explode the date to get month, day and year
        $dobForAge = explode("/", $dobForAge);
        //get age from date or birthdate
        $age = (date("md", date("U", mktime(0, 0, 0, $dobForAge[0], $dobForAge[1], $dobForAge[2]))) > date("md")
        ? ((date("Y") - $dobForAge[2]) - 1)
        : (date("Y") - $dobForAge[2]));

	
 	
    if(isset($_SESSION['quickStart'])) {
    		$quickStart = $_SESSION['quickStart'];
    	}else{
    		$quickStart = NULL;
    	}    	
    if(!isset($_SESSION['city'])) {
    		$city = $_POST['city'];
    	}else{
    		$city = $_SESSION['city'];
    	}
    	
    if(!isset($_SESSION['province'])) {
    		$province = $_POST['province'];
    	}else{
    		$province = $_SESSION['province'];
    	}
    	
    if(!isset($_SESSION['country'])) {
    		$country = $_POST['country'];
    	}else{
    		$country = $_SESSION['country'];
    	}

	$defaultVerification = '1';
	
    $ipcountryCode = $_SESSION['ipcountryCode'];
    $ipcountry = $_SESSION['ipcountry'];
    $ipregionCode = $_SESSION['ipregionCode'];
    $ipregion = $_SESSION['ipregion'];
    $ipcity = $_SESSION['ipcity'];
    $areaCode = $_SESSION['areaCode'];

    
    
    $ipcurrencySymbol = $_SESSION['$ipcurrencySymbol'];
    $ipcurrency = $_SESSION['ipcurrency'];
    $ipcurrencyConversion = $_SESSION['ipcurrencyConversion'];




        if($userID == NULL){
            $result = "We could not recognize your account! Please Logout and then try login in again.";
            header("location:/portal/page/logout.php");
            
            
                                            }else{
                                                  try{
                                                    //create SQL select statement to verify if user has general database
                                                    $sqlQuery = "SELECT userID FROM general WHERE userID =:userID";
                                    
                                                    //use PDO prepared to sanitize data
                                                    $statement = $db->prepare($sqlQuery);
                                    
                                                    //execute the query
                                                    $statement->execute(array(':userID' => $userID));
                                    
                                                    //check if record exist
                                                    if($statement->rowCount() == 1){
                                    
                                                                                                        //SQL statement to update password
                                                                                                        $sqlUpdate = "UPDATE general SET gl_cellArea = :gl_cellArea, gl_cell = :gl_cell, ipcountryCode = :ipcountryCode, ipcountry = :ipcountry, ipregionCode = :ipregionCode, ipregion = :ipregion, ipcity = :ipcity, ipcurrencyCode = :ipcurrencyCode, ipcurrencySymbol = :ipcurrencySymbol,  ipcurrency = :ipcurrency, ipcurrencyConversion = :ipcurrencyConversion, currency = :currency, gender = :gender, dob = :dob, dob_day = :dob_day, dob_month = :dob_month, dob_year = :dob_year, age = :age, city = :city, province = :province, country = :country WHERE userID = :userID";
                                                                                    
                                                                                                        //use PDO prepared to sanitize SQL statement
                                                                                                        $statement = $db->prepare($sqlUpdate);
                                                                                    
                                                                                                        //execute the statement
                                                                                                        $statement->execute(array(':gl_cellArea' => $gl_cellArea, ':gl_cell' => $gl_cell, ':ipcountryCode' => $ipcountryCode, ':ipcountry' => $ipcountry, ':ipregionCode' => $ipregionCode, ':ipregion' => $ipregion, ':ipcity' => $ipcity, ':ipcurrencyCode' => $ipcurrencyCode, ':ipcurrencySymbol' => $ipcurrencySymbol,    ':ipcurrency' => $ipcurrency, ':ipcurrencyConversion' => $ipcurrencyConversion, ':currency' => $ipcurrency, ':gender' => $gender, ':dob' => $dob, ':dob_day' => $dob_day, ':dob_month' => $dob_month, ':dob_year' => $dob_year, ':age' => $age, ':city' => $city, ':province' => $province, ':country' => $country, ':userID' => $userID));
                         
                         
                         
                                                                                                //check if one new row was affected
                                                                                                if($statement->rowCount() == 1){
                                                                                                
                                                                                                        //SQL statement to update info
                                                                                                        $sqlUpdate = "UPDATE users SET defaultVerification = :defaultVerification WHERE id = :userID";
                                                                                    
                                                                                                        //use PDO prepared to sanitize SQL statement
                                                                                                        $statement = $db->prepare($sqlUpdate);
                                                                                    
                                                                                                        //execute the statement
                                                                                                        $statement->execute(array(':defaultVerification' => $defaultVerification, ':userID' => $userID));
                                                                                                

                                                                                                
                                                                                                

                                                                                                }
                                                                                                
                                                                                            $result = "<p style='padding:20px; border: 1px solid gray; color: #381A64;'> <b> $firstName</b>, you are good to go!</p>";
                                                                                                        
                                                                                            	$_SESSION['defaultVerification'] = "1" ;
                                                                                    
                                                                                if(!isset($quickStart)) header("location: /portal/QuickStart.php");
	        		                                                            header("location: /portal/connections.php");
                                                                                                
                                                                                }else{
                                                                                                        
                                                                                    
                                                                                                //create SQL insert statement
                                                                                                $sqlInsert = "INSERT INTO general (gl_cellArea, gl_cell, ipcountryCode, ipcountry, ipregionCode, ipregion, ipcity, ipcurrencyCode, ipcurrencySymbol, ipcurrency, ipcurrencyConversion, currency, gender, dob, dob_day, dob_month, dob_year, age, city, province, country, userID)
                                                                                                                           VALUES (:gl_cellArea, :gl_cell, :ipcountryCode, :ipcountry, :ipregionCode, :ipregion, :ipcity, :ipcurrencyCode, :ipcurrencySymbol, :ipcurrency, :ipcurrencyConversion, :currency, :gender, :dob, :dob_day, :dob_month, :dob_year, :age, :city, :province, :country, :userID)";
                                                                                    
                                                                                                //use PDO prepared to sanitize data
                                                                                                $statement = $db->prepare($sqlInsert);
                                                                                    
                                                                                                //add the data into the database
                                                                                                $statement->execute(array(':gl_cellArea' => $gl_cellArea, ':gl_cell' => $gl_cell, ':ipcountryCode' => $ipcountryCode, ':ipcountry' => $ipcountry, ':ipregionCode' => $ipregionCode, ':ipregion' => $ipregion, ':ipcity' => $ipcity, ':ipcurrencyCode' => $ipcurrencyCode, ':ipcurrencySymbol' => $ipcurrencySymbol, ':ipcurrency' => $ipcurrency, ':ipcurrencyConversion' => $ipcurrencyConversion, ':currency' => $currency, ':gender' => $gender, ':dob' => $dob, ':dob_day' => $dob_day, ':dob_month' => $dob_month, ':dob_year' => $dob_year, ':age' => $age, ':city' => $city, ':province' => $province, ':country' => $country, ':userID' => $userID));
                                                                                                                        
                                                                                                //check if one new row was created
                                                                                                if($statement->rowCount() == 1){


                                                                                                        //SQL statement to update info
                                                                                                        $sqlUpdate = "UPDATE users SET defaultVerification = :defaultVerification WHERE id = :userID";
                                                                                    
                                                                                                        //use PDO prepared to sanitize SQL statement
                                                                                                        $statement = $db->prepare($sqlUpdate);
                                                                                    
                                                                                                        //execute the statement
                                                                                                        $statement->execute(array(':defaultVerification' => $defaultVerification, ':userID' => $userID));
                                                                                                

                                                                                }
                                                                                                                                                                            
                                                                                            $result = "<p style='padding:20px; border: 1px solid gray; color: #381A64;'> <b> $firstName</b>, you are good to go!</p>";
                                                                                            
                                                                                            	$_SESSION['defaultVerification'] = "1" ;
                                                                                    
                                                                                if(!isset($quickStart)) header("location: /portal/QuickStart.php");
	        		                                                            header("location: /portal/connections.php");
                                                }
          }catch (PDOException $ex){
                $result = "An error occurred: ".$ex->getMessage();
            }
        }
    }
}
?>



<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>