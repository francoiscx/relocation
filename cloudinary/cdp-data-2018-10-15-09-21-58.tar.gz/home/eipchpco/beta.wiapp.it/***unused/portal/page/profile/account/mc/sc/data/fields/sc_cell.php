<?php
$sc_cellArea = "sc_cellArea";
$sc_cell = "sc_cell";
$sc_cell_perm = "sc_cell_perm";
$sc_cell_status = "sc_cell_status";
?>

<!-- Start of Textfield for sc_cell -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_cellArea: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingsc_cellArea = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_cellArea(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_cellArea(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_cellArea').donetypingsc_cellArea(function(){
  	var sc_cellArea = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_cellArea.php",
        method:"POST",
        data:{sc_cellArea:sc_cellArea},
        success: function(data){
      	$('#sc_cell_result').html(data);
      }
    });  
});

});
</script>



<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_cell: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypingsc_cell = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_cell(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_cell(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_cell').donetypingsc_cell(function(){
  	var sc_cell = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/sc/data/functions/func_sc_cell.php",
        method:"POST",
        data:{sc_cell:sc_cell},
        success: function(data){
      	$('#sc_cell_result').html(data);
      }
    });  
});

});
</script>

<?php
$sc_cellArea = $_SESSION['sc_cellArea'];
$sc_cell = $_SESSION['sc_cell'];
?>

    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px"for="sc_cellArea"><fb-none class="icon-none" aria-hidden="true"></fb-none>Cell&nbsp<span><h5 id="sc_cell_result" style="float:right; color:#381A64"></h5></span></label>
	        <input class="c" type="text" id="sc_cellArea" name="sc_cellArea" value="<?php echo $sc_cellArea; ?>">
            <input class="n" type="text" id="sc_cell" name="sc_cell" value="<?php echo $sc_cell; ?>">
           
<!-- End of Textfield for sc_cell -->






<!-- Start of Radio Buttons for sc_cell_perm -->

<script>
$(document).ready(function(){
	$('input[name="sc_cell_perm"]').click(function(){
  	var sc_cell_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_sc_cell_perm.php",
        method:"POST",
        data:{sc_cell_perm:sc_cell_perm},
        success: function(data){
      	$('#sc_cell_result').html(data);
      }
    });
  });
});
</script>

<?php

$sc_cell_perm = $_SESSION['sc_cell_perm'];
switch ($sc_cell_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_cell_perm_pub" name="sc_cell_perm" checked="checked" value="Public">
                <label for="sc_cell_perm_pub" id="sc_cell_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_cell_perm_req" name="sc_cell_perm" value="Request">
                <label for="sc_cell_perm_req" id="sc_cell_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_cell_perm_pri" name="sc_cell_perm" value="Private">
                <label for="sc_cell_perm_pri" id="sc_cell_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_cell_perm_pub" name="sc_cell_perm" value="Public">
                <label for="sc_cell_perm_pub" id="sc_cell_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_cell_perm_req" name="sc_cell_perm" checked="checked" value="Request">
                <label for="sc_cell_perm_req" id="sc_cell_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_cell_perm_pri" name="sc_cell_perm" value="Private">
                <label for="sc_cell_perm_pri" id="sc_cell_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_cell_perm_pub" name="sc_cell_perm" value="Public">
                <label for="sc_cell_perm_pub" id="sc_cell_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_cell_perm_req" name="sc_cell_perm" value="Request">
                <label for="sc_cell_perm_req" id="sc_cell_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_cell_perm_pri" name="sc_cell_perm" checked="checked" value="Private">
                <label for="sc_cell_perm_pri" id="sc_cell_perm_pri">Only Me</label>
            <a></a>
        </div>
    </div>
';
}

?>

    </div> <!-- /field -->


<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#sc_cell_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for sc_cell_perm -->
