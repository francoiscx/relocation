<!-- Start of Radio Buttons for pc_googleP_status -->
<div class="groupl">

<?php

$pc_googleP_status = $_SESSION['pc_googleP_status'];

if(!isset($pc_googleP_status)) {$pc_googleP_status = 'pc_googlePpassive'; }



//echo $pc_googleP_status;

switch ($pc_googleP_status) {
    case "pc_googlePactive":
        echo "
<div>

    <div class='pc_googleP_selection' id='pc_googlePactive'>
    <a class='pc_googleP_selectionSwitch' href='#pc_googlePpassive'><input type='radio' id='pc_googleP_status_on' name='pc_googleP_status' value='pc_googlePpassive' hidden> 
    <label for='pc_googleP_status_on' class='pc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_googleP_selection' id='pc_googlePpassive'>
    <a class='pc_googleP_selectionSwitch' href='#pc_googlePactive'><input type='radio' id='pc_googleP_status_off' name='pc_googleP_status' value='pc_googlePactive' hidden>
    <label for='pc_googleP_status_off' class='pc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_googleP_status').on('click', function () {
        check = $('#pc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.pc_googleP_Check i').hasClass('icon-check-square')) {
                $('.pc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_googleP_Check i').hasClass('icon-square-o')) {
                $('.pc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_googleP_status = $('#pc_googlePactive, #pc_googlePpassive').hide();
$('#pc_googlePactive').show();
$('#pc_googlePpassive').hide();
$('.pc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_googleP_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_googlePpassive":
        echo "
<div>

  <div class='pc_googleP_selection' id='pc_googlePpassive'>
    <a class='pc_googleP_selectionSwitch' href='#pc_googlePactive'><input type='radio' id='pc_googleP_status_off' name='pc_googleP_status' value='pc_googlePactive' hidden>
    <label for='pc_googleP_status_off' class='pc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_googleP_selection' id='pc_googlePactive'>
    <a class='pc_googleP_selectionSwitch' href='#pc_googlePpassive'><input type='radio' id='pc_googleP_status_on' name='pc_googleP_status' value='pc_googlePpassive' hidden>
    <label for='pc_googleP_status_on' class='pc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_googleP_status').on('click', function () {
        check = $('#pc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.pc_googleP_Check i').hasClass('icon-square-o')) {
                $('.pc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_googleP_Check i').hasClass('icon-check-square')) {
                $('.pc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_googleP_status = $('#pc_googlePactive, #pc_googlePpassive').hide();
$('#pc_googlePactive').hide();
$('#pc_googlePpassive').show();
$('.pc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_googleP_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_googleP_selection' id='pc_googlePpassive'>
    <a class='pc_googleP_selectionSwitch' href='#pc_googlePactive'><input type='radio' id='pc_googleP_status_off' name='pc_googleP_status' value='pc_googlePactive' hidden>
    <label for='pc_googleP_status_off' class='pc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_googleP_selection' id='pc_googlePactive'>
    <a class='pc_googleP_selectionSwitch' href='#pc_googlePpassive'><input type='radio' id='pc_googleP_status_on' name='pc_googleP_status' value='pc_googlePpassive' hidden>
    <label for='pc_googleP_status_on' class='pc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_googleP_status').on('click', function () {
        check = $('#pc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.pc_googleP_Check i').hasClass('icon-square-o')) {
                $('.pc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_googleP_Check i').hasClass('icon-check-square')) {
                $('.pc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_googleP_status = $('#pc_googlePactive, #pc_googlePpassive').hide();
$('#pc_googlePactive').hide();
$('#pc_googlePpassive').show();
$('.pc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_googleP_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>