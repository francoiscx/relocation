<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gc_homenumber_status = $_POST['gc_homenumber_status'];

//process the form if the button is clicked
if (isset($_POST['gc_homenumber_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlgc_homenumber_statusQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgc_homenumber_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgc_homenumber_statusUpdate = "UPDATE general_card SET gc_homenumber_status =:gc_homenumber_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgc_homenumber_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_homenumber_status' => $gc_homenumber_status, ':userID' => $userID));

                    $gc_homenumber_status_result = 'gc_homenumber_status';
                    $_SESSION['gc_homenumber_status'] = $gc_homenumber_status;
                
                 }catch (PDOException $ex){
                $gc_homenumber_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlgc_homenumber_statusInsert = "INSERT INTO general_card (userID, gc_homenumber_status)
                    VALUES (:userID, :gc_homenumber_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgc_homenumber_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gc_homenumber_status' => $gc_homenumber_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gc_homenumber_status_result = 'gc_homenumber_status';
                    $_SESSION['gc_homenumber_status'] = $gc_homenumber_status;
	    	        }
                }
            }catch (PDOException $ex){
                $gc_homenumber_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($gc_homenumber_status == gc_homenumberactive) echo "gc_homenumberactive";
 else if ($gc_homenumber_status != gc_homenumberactive) echo "gc_homenumberpassive";

?>