<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$pc_facebook = $_POST['pc_facebook'];

//process the form if the button is clicked
if (isset($_POST['pc_facebook'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE professional_card SET pc_facebook =:pc_facebook WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_facebook' => $pc_facebook, ':userID' => $userID));

                    $pc_facebook_result = "Update Successful";
                    $_SESSION['pc_facebook'] = $pc_facebook;
                    
                 }catch (PDOException $ex){
                $pc_facebook_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO professional_card (userID, pc_facebook)
                        VALUES (:userID, :pc_facebook)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':pc_facebook' => $pc_facebook));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $pc_facebook_result = "Data was successfully captured";
                }
   
                    $pc_facebook_result = "Card was created";
                    
                    $_SESSION['pc_facebook'] = $pc_facebook;
                }
            }catch (PDOException $ex){
                $pc_facebook_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $pc_facebook_result
?>

