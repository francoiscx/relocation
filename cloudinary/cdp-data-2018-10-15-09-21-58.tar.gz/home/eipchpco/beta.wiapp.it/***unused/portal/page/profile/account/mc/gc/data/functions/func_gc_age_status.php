<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$gc_age_status = $_POST['gc_age_status'];

//process the form if the button is clicked
if (isset($_POST['gc_age_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlgc_age_statusQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlgc_age_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlgc_age_statusUpdate = "UPDATE general_card SET gc_age_status =:gc_age_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlgc_age_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_age_status' => $gc_age_status, ':userID' => $userID));

                    $gc_age_status_result = 'gc_age_status';
                    $_SESSION['gc_age_status'] = $gc_age_status;
                
                 }catch (PDOException $ex){
                $gc_age_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlgc_age_statusInsert = "INSERT INTO general_card (userID, gc_age_status)
                    VALUES (:userID, :gc_age_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlgc_age_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':gc_age_status' => $gc_age_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $gc_age_status_result = 'gc_age_status';
                    $_SESSION['gc_age_status'] = $gc_age_status;
	    	        }
                }
            }catch (PDOException $ex){
                $gc_age_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($gc_age_status == gc_ageactive) echo "gc_ageactive";
 else if ($gc_age_status != gc_ageactive) echo "gc_agepassive";

?>