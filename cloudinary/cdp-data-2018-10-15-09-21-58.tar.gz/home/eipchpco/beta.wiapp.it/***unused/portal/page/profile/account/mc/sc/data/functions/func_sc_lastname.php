<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$sc_lastname = $_POST['sc_lastname'];

//process the form if the button is clicked
if (isset($_POST['sc_lastname'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE social_card SET sc_lastname =:sc_lastname WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_lastname' => $sc_lastname, ':userID' => $userID));

                    $sc_lastname_result = "Success";
                    $_SESSION['sc_lastname'] = $sc_lastname;
                    
                 }catch (PDOException $ex){
                $sc_lastname_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO social_card (userID, sc_lastname)
                        VALUES (:userID, :sc_lastname)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':sc_lastname' => $sc_lastname));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $sc_lastname_result = "Data was successfully captured";
                }
   
                    $sc_lastname_result = "Success";
                    
                    $_SESSION['sc_lastname'] = $sc_lastname;
                }
            }catch (PDOException $ex){
                $sc_lastname_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $sc_lastname_result
?>

