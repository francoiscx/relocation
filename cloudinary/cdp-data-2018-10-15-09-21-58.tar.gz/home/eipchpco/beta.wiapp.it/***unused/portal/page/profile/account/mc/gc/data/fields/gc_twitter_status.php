<!-- Start of Radio Buttons for gc_twitter_status -->
<div class="groupl">

<?php

$gc_twitter_status = $_SESSION['gc_twitter_status'];

if(!isset($gc_twitter_status)) {$gc_twitter_status = 'gc_twitterpassive'; }



//echo $gc_twitter_status;

switch ($gc_twitter_status) {
    case "gc_twitteractive":
        echo "
<div>

    <div class='gc_twitter_selection' id='gc_twitteractive'>
    <a class='gc_twitter_selectionSwitch' href='#gc_twitterpassive'><input type='radio' id='gc_twitter_status_on' name='gc_twitter_status' value='gc_twitterpassive' hidden> 
    <label for='gc_twitter_status_on' class='gc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_twitter_selection' id='gc_twitterpassive'>
    <a class='gc_twitter_selectionSwitch' href='#gc_twitteractive'><input type='radio' id='gc_twitter_status_off' name='gc_twitter_status' value='gc_twitteractive' hidden>
    <label for='gc_twitter_status_off' class='gc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_twitter_status').on('click', function () {
        check = $('#gc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.gc_twitter_Check i').hasClass('icon-check-square')) {
                $('.gc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_twitter_Check i').hasClass('icon-square-o')) {
                $('.gc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_twitter_status = $('#gc_twitteractive, #gc_twitterpassive').hide();
$('#gc_twitteractive').show();
$('#gc_twitterpassive').hide();
$('.gc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_twitter_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_twitterpassive":
        echo "
<div>

  <div class='gc_twitter_selection' id='gc_twitterpassive'>
    <a class='gc_twitter_selectionSwitch' href='#gc_twitteractive'><input type='radio' id='gc_twitter_status_off' name='gc_twitter_status' value='gc_twitteractive' hidden>
    <label for='gc_twitter_status_off' class='gc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_twitter_selection' id='gc_twitteractive'>
    <a class='gc_twitter_selectionSwitch' href='#gc_twitterpassive'><input type='radio' id='gc_twitter_status_on' name='gc_twitter_status' value='gc_twitterpassive' hidden>
    <label for='gc_twitter_status_on' class='gc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_twitter_status').on('click', function () {
        check = $('#gc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.gc_twitter_Check i').hasClass('icon-square-o')) {
                $('.gc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_twitter_Check i').hasClass('icon-check-square')) {
                $('.gc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_twitter_status = $('#gc_twitteractive, #gc_twitterpassive').hide();
$('#gc_twitteractive').hide();
$('#gc_twitterpassive').show();
$('.gc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_twitter_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_twitter_selection' id='gc_twitterpassive'>
    <a class='gc_twitter_selectionSwitch' href='#gc_twitteractive'><input type='radio' id='gc_twitter_status_off' name='gc_twitter_status' value='gc_twitteractive' hidden>
    <label for='gc_twitter_status_off' class='gc_twitter_Check'>
    <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_twitter_selection' id='gc_twitteractive'>
    <a class='gc_twitter_selectionSwitch' href='#gc_twitterpassive'><input type='radio' id='gc_twitter_status_on' name='gc_twitter_status' value='gc_twitterpassive' hidden>
    <label for='gc_twitter_status_on' class='gc_twitter_Check'>
     <fa-twitter class='icon-twitter-square' aria-hidden='true'></fa-twitter>Twitter
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_twitter_status').on('click', function () {
        check = $('#gc_twitter_status').prop('checked');
        
        if (check) {
            if ($('.gc_twitter_Check i').hasClass('icon-square-o')) {
                $('.gc_twitter_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_twitter_Check i').hasClass('icon-check-square')) {
                $('.gc_twitter_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_twitter_status = $('#gc_twitteractive, #gc_twitterpassive').hide();
$('#gc_twitteractive').hide();
$('#gc_twitterpassive').show();
$('.gc_twitter_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_twitter_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>