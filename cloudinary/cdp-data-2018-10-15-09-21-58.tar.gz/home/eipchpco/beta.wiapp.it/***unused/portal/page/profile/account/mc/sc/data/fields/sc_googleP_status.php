<!-- Start of Radio Buttons for sc_googleP_status -->
<div class="groupl">

<?php

$sc_googleP_status = $_SESSION['sc_googleP_status'];

if(!isset($sc_googleP_status)) {$sc_googleP_status = 'sc_googlePpassive'; }



//echo $sc_googleP_status;

switch ($sc_googleP_status) {
    case "sc_googlePactive":
        echo "
<div>

    <div class='sc_googleP_selection' id='sc_googlePactive'>
    <a class='sc_googleP_selectionSwitch' href='#sc_googlePpassive'><input type='radio' id='sc_googleP_status_on' name='sc_googleP_status' value='sc_googlePpassive' hidden> 
    <label for='sc_googleP_status_on' class='sc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='sc_googleP_selection' id='sc_googlePpassive'>
    <a class='sc_googleP_selectionSwitch' href='#sc_googlePactive'><input type='radio' id='sc_googleP_status_off' name='sc_googleP_status' value='sc_googlePactive' hidden>
    <label for='sc_googleP_status_off' class='sc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#sc_googleP_status').on('click', function () {
        check = $('#sc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.sc_googleP_Check i').hasClass('icon-check-square')) {
                $('.sc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.sc_googleP_Check i').hasClass('icon-square-o')) {
                $('.sc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_googleP_status = $('#sc_googlePactive, #sc_googlePpassive').hide();
$('#sc_googlePactive').show();
$('#sc_googlePpassive').hide();
$('.sc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_googleP_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "sc_googlePpassive":
        echo "
<div>

  <div class='sc_googleP_selection' id='sc_googlePpassive'>
    <a class='sc_googleP_selectionSwitch' href='#sc_googlePactive'><input type='radio' id='sc_googleP_status_off' name='sc_googleP_status' value='sc_googlePactive' hidden>
    <label for='sc_googleP_status_off' class='sc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='sc_googleP_selection' id='sc_googlePactive'>
    <a class='sc_googleP_selectionSwitch' href='#sc_googlePpassive'><input type='radio' id='sc_googleP_status_on' name='sc_googleP_status' value='sc_googlePpassive' hidden>
    <label for='sc_googleP_status_on' class='sc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#sc_googleP_status').on('click', function () {
        check = $('#sc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.sc_googleP_Check i').hasClass('icon-square-o')) {
                $('.sc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.sc_googleP_Check i').hasClass('icon-check-square')) {
                $('.sc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_googleP_status = $('#sc_googlePactive, #sc_googlePpassive').hide();
$('#sc_googlePactive').hide();
$('#sc_googlePpassive').show();
$('.sc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_googleP_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='sc_googleP_selection' id='sc_googlePpassive'>
    <a class='sc_googleP_selectionSwitch' href='#sc_googlePactive'><input type='radio' id='sc_googleP_status_off' name='sc_googleP_status' value='sc_googlePactive' hidden>
    <label for='sc_googleP_status_off' class='sc_googleP_Check'>
    <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='sc_googleP_selection' id='sc_googlePactive'>
    <a class='sc_googleP_selectionSwitch' href='#sc_googlePpassive'><input type='radio' id='sc_googleP_status_on' name='sc_googleP_status' value='sc_googlePpassive' hidden>
    <label for='sc_googleP_status_on' class='sc_googleP_Check'>
     <fa-googleP class='icon-google-plus-square' aria-hidden='true'></fa-googleP>Google+
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#sc_googleP_status').on('click', function () {
        check = $('#sc_googleP_status').prop('checked');
        
        if (check) {
            if ($('.sc_googleP_Check i').hasClass('icon-square-o')) {
                $('.sc_googleP_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.sc_googleP_Check i').hasClass('icon-check-square')) {
                $('.sc_googleP_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_googleP_status = $('#sc_googlePactive, #sc_googlePpassive').hide();
$('#sc_googlePactive').hide();
$('#sc_googlePpassive').show();
$('.sc_googleP_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_googleP_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>