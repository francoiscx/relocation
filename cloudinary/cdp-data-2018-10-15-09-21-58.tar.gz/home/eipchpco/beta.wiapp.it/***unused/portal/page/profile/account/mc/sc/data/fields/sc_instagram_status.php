<!-- Start of Radio Buttons for sc_instagram_status -->
<div class="groupl">

<?php

$sc_instagram_status = $_SESSION['sc_instagram_status'];

if(!isset($sc_instagram_status)) {$sc_instagram_status = 'sc_instagrampassive'; }



//echo $sc_instagram_status;

switch ($sc_instagram_status) {
    case "sc_instagramactive":
        echo "
<div>

    <div class='sc_instagram_selection' id='sc_instagramactive'>
    <a class='sc_instagram_selectionSwitch' href='#sc_instagrampassive'><input type='radio' id='sc_instagram_status_on' name='sc_instagram_status' value='sc_instagrampassive' hidden> 
    <label for='sc_instagram_status_on' class='sc_instagram_Check'>
     <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='sc_instagram_selection' id='sc_instagrampassive'>
    <a class='sc_instagram_selectionSwitch' href='#sc_instagramactive'><input type='radio' id='sc_instagram_status_off' name='sc_instagram_status' value='sc_instagramactive' hidden>
    <label for='sc_instagram_status_off' class='sc_instagram_Check'>
    <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#sc_instagram_status').on('click', function () {
        check = $('#sc_instagram_status').prop('checked');
        
        if (check) {
            if ($('.sc_instagram_Check i').hasClass('icon-check-square')) {
                $('.sc_instagram_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.sc_instagram_Check i').hasClass('icon-square-o')) {
                $('.sc_instagram_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_instagram_status = $('#sc_instagramactive, #sc_instagrampassive').hide();
$('#sc_instagramactive').show();
$('#sc_instagrampassive').hide();
$('.sc_instagram_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_instagram_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "sc_instagrampassive":
        echo "
<div>

  <div class='sc_instagram_selection' id='sc_instagrampassive'>
    <a class='sc_instagram_selectionSwitch' href='#sc_instagramactive'><input type='radio' id='sc_instagram_status_off' name='sc_instagram_status' value='sc_instagramactive' hidden>
    <label for='sc_instagram_status_off' class='sc_instagram_Check'>
    <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='sc_instagram_selection' id='sc_instagramactive'>
    <a class='sc_instagram_selectionSwitch' href='#sc_instagrampassive'><input type='radio' id='sc_instagram_status_on' name='sc_instagram_status' value='sc_instagrampassive' hidden>
    <label for='sc_instagram_status_on' class='sc_instagram_Check'>
     <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#sc_instagram_status').on('click', function () {
        check = $('#sc_instagram_status').prop('checked');
        
        if (check) {
            if ($('.sc_instagram_Check i').hasClass('icon-square-o')) {
                $('.sc_instagram_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.sc_instagram_Check i').hasClass('icon-check-square')) {
                $('.sc_instagram_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_instagram_status = $('#sc_instagramactive, #sc_instagrampassive').hide();
$('#sc_instagramactive').hide();
$('#sc_instagrampassive').show();
$('.sc_instagram_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_instagram_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='sc_instagram_selection' id='sc_instagrampassive'>
    <a class='sc_instagram_selectionSwitch' href='#sc_instagramactive'><input type='radio' id='sc_instagram_status_off' name='sc_instagram_status' value='sc_instagramactive' hidden>
    <label for='sc_instagram_status_off' class='sc_instagram_Check'>
    <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='sc_instagram_selection' id='sc_instagramactive'>
    <a class='sc_instagram_selectionSwitch' href='#sc_instagrampassive'><input type='radio' id='sc_instagram_status_on' name='sc_instagram_status' value='sc_instagrampassive' hidden>
    <label for='sc_instagram_status_on' class='sc_instagram_Check'>
     <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#sc_instagram_status').on('click', function () {
        check = $('#sc_instagram_status').prop('checked');
        
        if (check) {
            if ($('.sc_instagram_Check i').hasClass('icon-square-o')) {
                $('.sc_instagram_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.sc_instagram_Check i').hasClass('icon-check-square')) {
                $('.sc_instagram_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $sc_instagram_status = $('#sc_instagramactive, #sc_instagrampassive').hide();
$('#sc_instagramactive').hide();
$('#sc_instagrampassive').show();
$('.sc_instagram_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $sc_instagram_status.hide();
    $(href).show();
})
});
</script>


";
}


?>














</div>