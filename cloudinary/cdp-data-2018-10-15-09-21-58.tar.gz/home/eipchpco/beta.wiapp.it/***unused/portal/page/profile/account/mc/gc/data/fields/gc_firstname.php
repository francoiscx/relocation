<?php
$gc_firstname = "gc_firstname";
$gc_firstname_perm = "gc_firstname_perm";
$gc_firstname_status = "gc_firstname_status";
?>


<div  id="gc_firstname_status"></div>

<!-- Start of Textfield for gc_firstname -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_firstname: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_firstname = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_firstname(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_firstname(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_firstname').donetypinggc_firstname(function(){
  	var gc_firstname = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_firstname.php",
        method:"POST",
        data:{gc_firstname:gc_firstname},
        success: function(data){
      	$('#gc_firstname_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_firstname = $_SESSION['gc_firstname'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="gc_firstname"><fb-none class="icon-none" aria-hidden="true"></fb-none>First name&nbsp<span><h5 id="gc_firstname_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="gc_firstname" name="gc_firstname" value="<?php echo $gc_firstname; ?>">
            
<!-- End of Textfield for gc_firstname -->






<!-- Start of Radio Buttons for gc_firstname_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_firstname_perm"]').click(function(){
  	var gc_firstname_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_firstname_perm.php",
        method:"POST",
        data:{gc_firstname_perm:gc_firstname_perm},
        success: function(data){
      	$('#gc_firstname_result').html(data);
      }
    });
  });
});
</script>

<?php

$gc_firstname_perm = $_SESSION['gc_firstname_perm'];
switch ($gc_firstname_perm) {
    case "Public":
        echo '<div class="switch-one switch-1 switch-candyone">
                <input type="radio" class="radio" id="gc_firstname_perm_pub" name="gc_firstname_perm" checked="checked" value="Public">
                <label for="gc_firstname_perm_pub" id="gc_firstname_perm_pub">Public</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-one switch-1 switch-candyone">
                <input type="radio" class="radio" id="gc_firstname_perm_pub" name="gc_firstname_perm" checked="checked" value="Public">
                <label for="gc_firstname_perm_pub" id="gc_firstname_perm_pub">Public</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_firstname_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 5e2);
</script>
</div>
<!-- End of Radio Buttons for gc_firstname_perm -->