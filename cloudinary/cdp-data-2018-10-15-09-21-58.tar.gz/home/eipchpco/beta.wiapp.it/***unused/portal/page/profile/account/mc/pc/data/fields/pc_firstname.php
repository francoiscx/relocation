<?php   
$pc_firstname = "pc_firstname";
$pc_firstname_perm = "pc_firstname_perm";
$pc_firstname_status = "pc_firstname_status";
?>

<!-- Start of Textfield for pc_firstname -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_firstname: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_firstname = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_firstname(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_firstname(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_firstname').donetypingpc_firstname(function(){
  	var pc_firstname = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_firstname.php",
        method:"POST",
        data:{pc_firstname:pc_firstname},
        success: function(data){
      	$('#pc_firstname_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_firstname = $_SESSION['pc_firstname'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_firstname">First Name<span><h5 id="pc_firstname_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_firstname" name="pc_firstname" value="<?php echo $pc_firstname; ?>">
            
<!-- End of Textfield for pc_firstname -->






<!-- Start of Radio Buttons for pc_firstname_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_firstname_perm"]').click(function(){
  	var pc_firstname_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_firstname_perm.php",
        method:"POST",
        data:{pc_firstname_perm:pc_firstname_perm},
        success: function(data){
      	$('#pc_firstname_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_firstname_perm = $_SESSION['pc_firstname_perm'];
switch ($pc_firstname_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_firstname_perm_pub" name="pc_firstname_perm" checked="checked" value="Public">
                <label for="pc_firstname_perm_pub" id="pc_firstname_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_firstname_perm_req" name="pc_firstname_perm" value="Request">
                <label for="pc_firstname_perm_req" id="pc_firstname_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_firstname_perm_pri" name="pc_firstname_perm" value="Private">
                <label for="pc_firstname_perm_pri" id="pc_firstname_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_firstname_perm_pub" name="pc_firstname_perm" value="Public">
                <label for="pc_firstname_perm_pub" id="pc_firstname_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_firstname_perm_req" name="pc_firstname_perm" checked="checked" value="Request">
                <label for="pc_firstname_perm_req" id="pc_firstname_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_firstname_perm_pri" name="pc_firstname_perm" value="Private">
                <label for="pc_firstname_perm_pri" id="pc_firstname_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_firstname_perm_pub" name="pc_firstname_perm" value="Public">
                <label for="pc_firstname_perm_pub" id="pc_firstname_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_firstname_perm_req" name="pc_firstname_perm" value="Request">
                <label for="pc_firstname_perm_req" id="pc_firstname_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_firstname_perm_pri" name="pc_firstname_perm" checked="checked" value="Private">
                <label for="pc_firstname_perm_pri" id="pc_firstname_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_firstname_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for pc_firstname_perm -->
