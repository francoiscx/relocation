<?php
$gc_gender = "gc_gender";
$gc_gender_perm = "gc_gender_perm";
$gc_gender_status = "gc_gender_status";
?>

<div  id="gc_gender_status"></div>

<!-- Start of Textfield for gc_gender -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypinggc_gender: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypinggc_gender = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypinggc_gender(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypinggc_gender(el);
                });
            });
        }
    });
})(jQuery);


$('#gc_gender').donetypinggc_gender(function(){
  	var gc_gender = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_gender.php",
        method:"POST",
        data:{gc_gender:gc_gender},
        success: function(data){
      	$('#gc_gender_result').html(data);
      }
    });  
});

});
</script>

<?php
$gc_gender = $_SESSION['gc_gender'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="gc_gender"><fb-none class="icon-none" aria-hidden="true"></fb-none>Gender&nbsp<span><h5 id="gc_gender_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="gc_gender" name="gc_gender" value="<?php echo $gc_gender; ?>">
            
<!-- End of Textfield for gc_gender -->






<!-- Start of Radio Buttons for gc_gender_perm -->

<script>
$(document).ready(function(){
	$('input[name="gc_gender_perm"]').click(function(){
  	var gc_gender_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_gc_gender_perm.php",
        method:"POST",
        data:{gc_gender_perm:gc_gender_perm},
        success: function(data){
      	$('#gc_gender_result').html(data);
      }
    });
  });
});
</script>

<?php

$gc_gender_perm = $_SESSION['gc_gender_perm'];
switch ($gc_gender_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_gender_perm_pub" name="gc_gender_perm" checked="checked" value="Public">
                <label for="gc_gender_perm_pub" id="gc_gender_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_gender_perm_req" name="gc_gender_perm" value="Request">
                <label for="gc_gender_perm_req" id="gc_gender_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_gender_perm_pri" name="gc_gender_perm" value="Private">
                <label for="gc_gender_perm_pri" id="gc_gender_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_gender_perm_pub" name="gc_gender_perm" value="Public">
                <label for="gc_gender_perm_pub" id="gc_gender_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_gender_perm_req" name="gc_gender_perm" checked="checked" value="Request">
                <label for="gc_gender_perm_req" id="gc_gender_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_gender_perm_pri" name="gc_gender_perm" value="Private">
                <label for="gc_gender_perm_pri" id="gc_gender_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="gc_gender_perm_pub" name="gc_gender_perm" value="Public">
                <label for="gc_gender_perm_pub" id="gc_gender_perm_pub">Public</label>
                <input type="radio" class="radio" id="gc_gender_perm_req" name="gc_gender_perm" value="Request">
                <label for="gc_gender_perm_req" id="gc_gender_perm_req">On Request</label>
                <input type="radio" class="radio" id="gc_gender_perm_pri" name="gc_gender_perm" checked="checked" value="Private">
                <label for="gc_gender_perm_pri" id="gc_gender_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#gc_gender_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 5e2);
</script>
</div>
<!-- End of Radio Buttons for gc_gender_perm -->