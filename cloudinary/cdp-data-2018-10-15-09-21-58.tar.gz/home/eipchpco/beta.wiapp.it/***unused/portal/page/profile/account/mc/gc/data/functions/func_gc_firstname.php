<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$gc_firstname = $_POST['gc_firstname'];

//process the form if the button is clicked
if (isset($_POST['gc_firstname'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE general_card SET gc_firstname =:gc_firstname WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_firstname' => $gc_firstname, ':userID' => $userID));

                    $gc_firstname_result = "Success";
                    $_SESSION['gc_firstname'] = $gc_firstname;
                    
                 }catch (PDOException $ex){
                $gc_firstname_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO general_card (userID, gc_firstname)
                        VALUES (:userID, :gc_firstname)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':gc_firstname' => $gc_firstname));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $gc_firstname_result = "Success";
                }
   
                    $gc_firstname_result = "Card was created";
                    
                    $_SESSION['gc_firstname'] = $gc_firstname;
                }
            }catch (PDOException $ex){
                $gc_firstname_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $gc_firstname_result
?>

