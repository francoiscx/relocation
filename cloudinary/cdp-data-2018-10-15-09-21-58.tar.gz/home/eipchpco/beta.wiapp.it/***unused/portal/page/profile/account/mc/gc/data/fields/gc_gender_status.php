<!-- Start of Radio Buttons for gc_gender_status -->
<div class="groupl">

<?php

$gc_gender_status = $_SESSION['gc_gender_status'];

if(!isset($gc_gender_status)) {$gc_gender_status = 'gc_genderpassive'; }



//echo $gc_gender_status;

switch ($gc_gender_status) {
    case "gc_genderactive":
        echo "
<div>

    <div class='gc_gender_selection' id='gc_genderactive'>
    <a class='gc_gender_selectionSwitch' href='#gc_genderpassive'><input type='radio' id='gc_gender_status_on' name='gc_gender_status' value='gc_genderpassive' hidden> 
    <label for='gc_gender_status_on' class='gc_gender_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Gender
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='gc_gender_selection' id='gc_genderpassive'>
    <a class='gc_gender_selectionSwitch' href='#gc_genderactive'><input type='radio' id='gc_gender_status_off' name='gc_gender_status' value='gc_genderactive' hidden>
    <label for='gc_gender_status_off' class='gc_gender_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Gender
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#gc_gender_status').on('click', function () {
        check = $('#gc_gender_status').prop('checked');
        
        if (check) {
            if ($('.gc_gender_Check i').hasClass('icon-check-square')) {
                $('.gc_gender_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.gc_gender_Check i').hasClass('icon-square-o')) {
                $('.gc_gender_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_gender_status = $('#gc_genderactive, #gc_genderpassive').hide();
$('#gc_genderactive').show();
$('#gc_genderpassive').hide();
$('.gc_gender_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_gender_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "gc_genderpassive":
        echo "
<div>

  <div class='gc_gender_selection' id='gc_genderpassive'>
    <a class='gc_gender_selectionSwitch' href='#gc_genderactive'><input type='radio' id='gc_gender_status_off' name='gc_gender_status' value='gc_genderactive' hidden>
    <label for='gc_gender_status_off' class='gc_gender_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Gender
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='gc_gender_selection' id='gc_genderactive'>
    <a class='gc_gender_selectionSwitch' href='#gc_genderpassive'><input type='radio' id='gc_gender_status_on' name='gc_gender_status' value='gc_genderpassive' hidden>
    <label for='gc_gender_status_on' class='gc_gender_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Gender
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#gc_gender_status').on('click', function () {
        check = $('#gc_gender_status').prop('checked');
        
        if (check) {
            if ($('.gc_gender_Check i').hasClass('icon-square-o')) {
                $('.gc_gender_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.gc_gender_Check i').hasClass('icon-check-square')) {
                $('.gc_gender_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_gender_status = $('#gc_genderactive, #gc_genderpassive').hide();
$('#gc_genderactive').hide();
$('#gc_genderpassive').show();
$('.gc_gender_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_gender_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='gc_gender_selection' id='gc_genderpassive'>
    <a class='gc_gender_selectionSwitch' href='#gc_genderactive'><input type='radio' id='gc_gender_status_off' name='gc_gender_status' value='gc_genderactive' hidden>
    <label for='gc_gender_status_off' class='gc_gender_Check'>
    <fa-none class='icon-none' aria-hidden='true'></fa-none>Gender
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='gc_gender_selection' id='gc_genderactive'>
    <a class='gc_gender_selectionSwitch' href='#gc_genderpassive'><input type='radio' id='gc_gender_status_on' name='gc_gender_status' value='gc_genderpassive' hidden>
    <label for='gc_gender_status_on' class='gc_gender_Check'>
     <fa-none class='icon-none' aria-hidden='true'></fa-none>Gender
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#gc_gender_status').on('click', function () {
        check = $('#gc_gender_status').prop('checked');
        
        if (check) {
            if ($('.gc_gender_Check i').hasClass('icon-square-o')) {
                $('.gc_gender_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.gc_gender_Check i').hasClass('icon-check-square')) {
                $('.gc_gender_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $gc_gender_status = $('#gc_genderactive, #gc_genderpassive').hide();
$('#gc_genderactive').hide();
$('#gc_genderpassive').show();
$('.gc_gender_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $gc_gender_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>