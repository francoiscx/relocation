<!-- Start of Radio Buttons for pc_company_instagram_status -->
<div class="groupl">

<?php

$pc_company_instagram_status = $_SESSION['pc_company_instagram_status'];

if(!isset($pc_company_instagram_status)) {$pc_company_instagram_status = 'pc_company_instagrampassive'; }



//echo $pc_company_instagram_status;

switch ($pc_company_instagram_status) {
    case "pc_company_instagramactive":
        echo "
<div>

    <div class='pc_company_instagram_selection' id='pc_company_instagramactive'>
    <a class='pc_company_instagram_selectionSwitch' href='#pc_company_instagrampassive'><input type='radio' id='pc_company_instagram_status_on' name='pc_company_instagram_status' value='pc_company_instagrampassive' hidden> 
    <label for='pc_company_instagram_status_on' class='pc_company_instagram_Check'>
     <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_company_instagram_selection' id='pc_company_instagrampassive'>
    <a class='pc_company_instagram_selectionSwitch' href='#pc_company_instagramactive'><input type='radio' id='pc_company_instagram_status_off' name='pc_company_instagram_status' value='pc_company_instagramactive' hidden>
    <label for='pc_company_instagram_status_off' class='pc_company_instagram_Check'>
    <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_instagram_status').on('click', function () {
        check = $('#pc_company_instagram_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_instagram_Check i').hasClass('icon-check-square')) {
                $('.pc_company_instagram_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_company_instagram_Check i').hasClass('icon-square-o')) {
                $('.pc_company_instagram_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_instagram_status = $('#pc_company_instagramactive, #pc_company_instagrampassive').hide();
$('#pc_company_instagramactive').show();
$('#pc_company_instagrampassive').hide();
$('.pc_company_instagram_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_instagram_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_company_instagrampassive":
        echo "
<div>

  <div class='pc_company_instagram_selection' id='pc_company_instagrampassive'>
    <a class='pc_company_instagram_selectionSwitch' href='#pc_company_instagramactive'><input type='radio' id='pc_company_instagram_status_off' name='pc_company_instagram_status' value='pc_company_instagramactive' hidden>
    <label for='pc_company_instagram_status_off' class='pc_company_instagram_Check'>
    <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_company_instagram_selection' id='pc_company_instagramactive'>
    <a class='pc_company_instagram_selectionSwitch' href='#pc_company_instagrampassive'><input type='radio' id='pc_company_instagram_status_on' name='pc_company_instagram_status' value='pc_company_instagrampassive' hidden>
    <label for='pc_company_instagram_status_on' class='pc_company_instagram_Check'>
     <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_company_instagram_status').on('click', function () {
        check = $('#pc_company_instagram_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_instagram_Check i').hasClass('icon-square-o')) {
                $('.pc_company_instagram_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_company_instagram_Check i').hasClass('icon-check-square')) {
                $('.pc_company_instagram_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_instagram_status = $('#pc_company_instagramactive, #pc_company_instagrampassive').hide();
$('#pc_company_instagramactive').hide();
$('#pc_company_instagrampassive').show();
$('.pc_company_instagram_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_instagram_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_company_instagram_selection' id='pc_company_instagrampassive'>
    <a class='pc_company_instagram_selectionSwitch' href='#pc_company_instagramactive'><input type='radio' id='pc_company_instagram_status_off' name='pc_company_instagram_status' value='pc_company_instagramactive' hidden>
    <label for='pc_company_instagram_status_off' class='pc_company_instagram_Check'>
    <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_company_instagram_selection' id='pc_company_instagramactive'>
    <a class='pc_company_instagram_selectionSwitch' href='#pc_company_instagrampassive'><input type='radio' id='pc_company_instagram_status_on' name='pc_company_instagram_status' value='pc_company_instagrampassive' hidden>
    <label for='pc_company_instagram_status_on' class='pc_company_instagram_Check'>
     <fa-instagram class='icon-social-instagram' aria-hidden='true'></fa-instagram>Instagram
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_company_instagram_status').on('click', function () {
        check = $('#pc_company_instagram_status').prop('checked');
        
        if (check) {
            if ($('.pc_company_instagram_Check i').hasClass('icon-square-o')) {
                $('.pc_company_instagram_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_company_instagram_Check i').hasClass('icon-check-square')) {
                $('.pc_company_instagram_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_company_instagram_status = $('#pc_company_instagramactive, #pc_company_instagrampassive').hide();
$('#pc_company_instagramactive').hide();
$('#pc_company_instagrampassive').show();
$('.pc_company_instagram_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_company_instagram_status.hide();
    $(href).show();
})
});
</script>


";
}


?>














</div>