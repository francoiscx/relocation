<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$gc_middlename_fs = $_POST['gc_middlename_fs'];
$gc_middlename_fsz = $_POST['gc_middlename_fsz'];

if($gc_middlename_fs > 0 && $gc_middlename_fs < 27){
$gc_middlename_fsz = '16px';

}elseif($gc_middlename_fs > 26 && $gc_middlename_fs < 32){
$gc_middlename_fsz = '14px';

}elseif($gc_middlename_fs > 31 && $gc_middlename_fs < 38){
$gc_middlename_fsz = '12px';

}elseif($gc_middlename_fs > 37 && $gc_middlename_fs < 45){
$gc_middlename_fsz = '10px';

}elseif($gc_middlename_fs > 34 && $gc_middlename_fs < 100){
$gc_middlename_fsz = '8px';

}else{
$gc_middlename_fsz = '16px';
}


//process the form if the button is clicked
if (isset($_POST['gc_middlename_fs'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE general_card SET gc_middlename_fs =:gc_middlename_fs WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_middlename_fs' => $gc_middlename_fs, ':userID' => $userID));

                    $gc_middlename_fs_result = "Success";
                    $_SESSION['gc_middlename_fs'] = $gc_middlename_fs;
                    $_SESSION['gc_middlename_fsz'] = $gc_middlename_fsz;
                    
                 }catch (PDOException $ex){
                $gc_middlename_fs_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO general_card (userID, gc_middlename_fs)
                        VALUES (:userID, :gc_middlename_fs)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':gc_middlename_fs' => $gc_middlename_fs));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $gc_middlename_fs_result = "Success";
                }
   
                    
                    $_SESSION['gc_middlename_fs'] = $gc_middlename_fs;
                    $_SESSION['gc_middlename_fsz'] = $gc_middlename_fsz;
                }
            }catch (PDOException $ex){
                $gc_middlename_fs_result = "An error occurred: ".$ex->getMessage();
            }




?>

