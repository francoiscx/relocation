<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$pc_company_twitter_perm = $_POST['pc_company_twitter_perm'];

//process the form if the button is clicked
if (isset($_POST['pc_company_twitter_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlpc_company_twitter_permQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlpc_company_twitter_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlpc_company_twitter_permUpdate = "UPDATE professional_card SET pc_company_twitter_perm =:pc_company_twitter_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlpc_company_twitter_permUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_company_twitter_perm' => $pc_company_twitter_perm, ':userID' => $userID));

                    $pc_company_twitter_result = "Success";
                    $_SESSION['pc_company_twitter_perm'] = $pc_company_twitter_perm;
                
                 }catch (PDOException $ex){
                $pc_company_twitter_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlpc_company_twitter_permInsert = "INSERT INTO professional_card (userID, pc_company_twitter_perm)
                    VALUES (:userID, :pc_company_twitter_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlpc_company_twitter_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':pc_company_twitter_perm' => $pc_company_twitter_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $pc_company_twitter_result = "Success";
                    $_SESSION['pc_company_twitter_perm'] = $pc_company_twitter_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $pc_company_twitter_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $pc_company_twitter_result
?>