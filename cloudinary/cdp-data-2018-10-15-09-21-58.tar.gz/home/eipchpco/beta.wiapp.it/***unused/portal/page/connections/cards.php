<h1> Wi-CARD coming soon... </h1>



                                            <div class="control-group">
                                            
							<!--	<label class="control-label">Account</label>  -->
							
									<div class="controls">
										 <div class="accordion" id="accordion2">



<!-- Accordion 1 -->													 
													 
													 
													 
                                                      <div class="accordion-group">
                                                        <div class="accordion-heading">
                                                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
Find out more
                                                          </a>
                                                        </div>
                                                        <div id="collapseOne" class="accordion-body collapse <!--in-->">
                                                          <div class="accordion-inner">
	<a href="http://beta.wiapp.it">Click here for more info</a>
                                                          </div>
                                                        </div>
                                                      </div>
                                                      
  
  
  
  
  


                                                 
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                      
                                                   				</div>
									</div> <!-- /controls -->	
						</div> <!-- /control-group -->
 