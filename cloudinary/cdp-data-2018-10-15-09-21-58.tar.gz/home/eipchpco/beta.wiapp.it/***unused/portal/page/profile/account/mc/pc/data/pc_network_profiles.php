<?php
$pc_linkedin_status = $_SESSION['pc_linkedin_status'];
$pc_facebook_status = $_SESSION['pc_facebook_status'];
$pc_twitter_status = $_SESSION['pc_twitter_status'];
$pc_googleP_status = $_SESSION['pc_googleP_status'];
$pc_youtube_status = $_SESSION['pc_youtube_status'];
$pc_instagram_status = $_SESSION['pc_instagram_status'];
$pc_pinterest_status = $_SESSION['pc_pinterest_status'];
$pc_flickr_status = $_SESSION['pc_flickr_status'];
?>



<form id="pc_network_handles" method="post" action="" autocomplete="off">   

	<div>	
		<div id="pc_linkedin_field" class="groupl2" <?php if($pc_linkedin_status == 'pc_linkedinactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
									    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_linkedin.php';?>							
	    </div>
	    
	    <div id="pc_facebook_field" class="groupl2" <?php if($pc_facebook_status == 'pc_facebookactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
									    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_facebook.php';?>							
	    </div>
	    
		<div id="pc_twitter_field" class="groupl2" <?php if($pc_twitter_status == 'pc_twitteractive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_twitter.php'; ?> 
	    </div>
	    
		<div id="pc_googleP_field" class="groupl2" <?php if($pc_googleP_status == 'pc_googlePactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_googleP.php'; ?>
	    </div>
	    
		<div id="pc_youtube_field" class="groupl2" <?php if($pc_youtube_status == 'pc_youtubeactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_youtube.php'; ?>
		</div>
		
		<div id="pc_instagram_field" class="groupl2" <?php if($pc_instagram_status == 'pc_instagramactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>								
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_instagram.php'; ?>
	    </div>
	    
		<div id="pc_pinterest_field" class="groupl2" <?php if($pc_pinterest_status == 'pc_pinterestactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_pinterest.php'; ?>
	    </div>
	    
		<div id="pc_flickr_field" class="groupl2" <?php if($pc_flickr_status == 'pc_flickractive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_flickr.php'; ?>
        </div>
</div>
									
</form>






<script>
$(document).ready(function(){
	$('input[name=\'pc_linkedin_status\']').click(function(){
  	var pc_linkedin_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_linkedin_status.php',
        method:'POST',
        data:{pc_linkedin_status:pc_linkedin_status},
        success: function(pc_linkedinresponse){
                    pc_linkedin_status_result = pc_linkedinresponse;
                    
                    if (pc_linkedin_status_result == 'pc_linkedinactive')
                        $("#pc_linkedin_field").show();
                    else    
                        $("#pc_linkedin_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_facebook_status\']').click(function(){
  	var pc_facebook_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_facebook_status.php',
        method:'POST',
        data:{pc_facebook_status:pc_facebook_status},
        success: function(pc_facebookresponse){
                    pc_facebook_status_result = pc_facebookresponse;
                    console.log(pc_facebook_status_result);
                    
                    if (pc_facebook_status_result == 'pc_facebookactive')
                        $("#pc_facebook_field").show();
                    else    
                        $("#pc_facebook_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_twitter_status\']').click(function(){
  	var pc_twitter_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_twitter_status.php',
        method:'POST',
        data:{pc_twitter_status:pc_twitter_status},
        success: function(pc_twitterresponse){
                    pc_twitter_status_result = pc_twitterresponse;
                    
                    if (pc_twitter_status_result == 'pc_twitteractive')
                        $("#pc_twitter_field").show();
                    else    
                        $("#pc_twitter_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_googleP_status\']').click(function(){
  	var pc_googleP_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_googleP_status.php',
        method:'POST',
        data:{pc_googleP_status:pc_googleP_status},
        success: function(pc_googlePresponse){
                    pc_googleP_status_result = pc_googlePresponse;
                    //console.log(pc_googleP_status_result);
                    
                    if (pc_googleP_status_result == 'pc_googlePactive')
                        $("#pc_googleP_field").show();
                    else    
                        $("#pc_googleP_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_youtube_status\']').click(function(){
  	var pc_youtube_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_youtube_status.php',
        method:'POST',
        data:{pc_youtube_status:pc_youtube_status},
        success: function(pc_youtuberesponse){
                    pc_youtube_status_result = pc_youtuberesponse;
                    
                    if (pc_youtube_status_result == 'pc_youtubeactive')
                        $("#pc_youtube_field").show();
                    else    
                        $("#pc_youtube_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_instagram_status\']').click(function(){
  	var pc_instagram_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_instagram_status.php',
        method:'POST',
        data:{pc_instagram_status:pc_instagram_status},
        success: function(pc_instagramresponse){
                    pc_instagram_status_result = pc_instagramresponse;
                    //console.log(pc_instagram_status_result);
                    
                    if (pc_instagram_status_result == 'pc_instagramactive')
                        $("#pc_instagram_field").show();
                    else    
                        $("#pc_instagram_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_pinterest_status\']').click(function(){
  	var pc_pinterest_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_pinterest_status.php',
        method:'POST',
        data:{pc_pinterest_status:pc_pinterest_status},
        success: function(pc_pinterestresponse){
                    pc_pinterest_status_result = pc_pinterestresponse;
                    //console.log(pc_pinterest_status_result);
                    
                    if (pc_pinterest_status_result == 'pc_pinterestactive')
                        $("#pc_pinterest_field").show();
                    else    
                        $("#pc_pinterest_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_flickr_status\']').click(function(){
  	var pc_flickr_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_flickr_status.php',
        method:'POST',
        data:{pc_flickr_status:pc_flickr_status},
        success: function(pc_flickrresponse){
                    pc_flickr_status_result = pc_flickrresponse;
                    //console.log(pc_flickr_status_result);
                    
                    if (pc_flickr_status_result == 'pc_flickractive')
                        $("#pc_flickr_field").show();
                    else    
                        $("#pc_flickr_field").hide();
                  } 
        });
  });
});
</script>





