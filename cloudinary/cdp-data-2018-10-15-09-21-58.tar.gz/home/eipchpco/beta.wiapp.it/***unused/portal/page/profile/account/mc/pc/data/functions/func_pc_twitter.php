<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$pc_twitter = $_POST['pc_twitter'];

//process the form if the button is clicked
if (isset($_POST['pc_twitter'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE professional_card SET pc_twitter =:pc_twitter WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_twitter' => $pc_twitter, ':userID' => $userID));

                    $pc_twitter_result = "Success";
                    $_SESSION['pc_twitter'] = $pc_twitter;
                    
                 }catch (PDOException $ex){
                $pc_twitter_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO professional_card (userID, pc_twitter)
                        VALUES (:userID, :pc_twitter)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':pc_twitter' => $pc_twitter));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $pc_twitter_result = "Success";
                }
   
                    $pc_twitter_result = "Card was created";
                    
                    $_SESSION['pc_twitter'] = $pc_twitter;
                }
            }catch (PDOException $ex){
                $pc_twitter_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $pc_twitter_result
?>

