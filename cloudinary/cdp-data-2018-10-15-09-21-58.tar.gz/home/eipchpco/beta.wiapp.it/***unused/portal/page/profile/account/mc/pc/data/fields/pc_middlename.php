<?php
$pc_middlename = "pc_middlename";
$pc_middlename_perm = "pc_middlename_perm";
$pc_middlename_status = "pc_middlename_status";
?>

<!-- Start of Textfield for pc_middlename -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_middlename: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_middlename = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_middlename(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_middlename(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_middlename').donetypingpc_middlename(function(){
  	var pc_middlename = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_middlename.php",
        method:"POST",
        data:{pc_middlename:pc_middlename},
        success: function(data){
      	$('#pc_middlename_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_middlename = $_SESSION['pc_middlename'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_middlename">Middle Name(s)&nbsp<span><h5 id="pc_middlename_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_middlename" name="pc_middlename" value="<?php echo $pc_middlename; ?>">
            
<!-- End of Textfield for pc_middlename -->






<!-- Start of Radio Buttons for pc_middlename_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_middlename_perm"]').click(function(){
  	var pc_middlename_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_middlename_perm.php",
        method:"POST",
        data:{pc_middlename_perm:pc_middlename_perm},
        success: function(data){
      	$('#pc_middlename_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_middlename_perm = $_SESSION['pc_middlename_perm'];
switch ($pc_middlename_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_middlename_perm_pub" name="pc_middlename_perm" checked="checked" value="Public">
                <label for="pc_middlename_perm_pub" id="pc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_middlename_perm_req" name="pc_middlename_perm" value="Request">
                <label for="pc_middlename_perm_req" id="pc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_middlename_perm_pri" name="pc_middlename_perm" value="Private">
                <label for="pc_middlename_perm_pri" id="pc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_middlename_perm_pub" name="pc_middlename_perm" value="Public">
                <label for="pc_middlename_perm_pub" id="pc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_middlename_perm_req" name="pc_middlename_perm" checked="checked" value="Request">
                <label for="pc_middlename_perm_req" id="pc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_middlename_perm_pri" name="pc_middlename_perm" value="Private">
                <label for="pc_middlename_perm_pri" id="pc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_middlename_perm_pub" name="pc_middlename_perm" value="Public">
                <label for="pc_middlename_perm_pub" id="pc_middlename_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_middlename_perm_req" name="pc_middlename_perm" value="Request">
                <label for="pc_middlename_perm_req" id="pc_middlename_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_middlename_perm_pri" name="pc_middlename_perm" checked="checked" value="Private">
                <label for="pc_middlename_perm_pri" id="pc_middlename_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_middlename_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for pc_middlename_perm -->
