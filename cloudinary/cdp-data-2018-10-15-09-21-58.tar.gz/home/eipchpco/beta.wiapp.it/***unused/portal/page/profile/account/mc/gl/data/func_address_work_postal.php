<?php
//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

//process the form if the reset password button is clicked
if (isset($_POST['wp_street_name'])) {
    //initialize an array to store any error message from the form
    $form_errors = array();

    //check if error array is empty, if yes process form data and insert record
    if(empty($form_errors)){
        //collect form data and store in variables
        $email = $_SESSION['email'];
        
        $wp_street_name = $_POST['wp_street_name'];
        $wp_number = $_POST['wp_number'];
        $wp_suburb = $_POST['wp_suburb'];
        $wp_city = $_POST['wp_city'];
        $wp_province = $_POST['wp_province'];
        $wp_code = $_POST['wp_code'];
        $wp_country = $_POST['wp_country']; 
        
        	//Fields to change Case to Name
		$wp_street_name = name_field($wp_street_name);
		$wp_number = name_field($wp_number);
		$wp_suburb = name_field($wp_suburb);		
		$wp_city = name_field($wp_city);
		$wp_province = name_field($wp_province);
		$wp_code = name_field($wp_code);
		$wp_country = name_field($wp_country);
        
        //check if all info is inserted
        if(!isset($_POST['wp_street_name'])) {
            $result = "Please provide the full information";
            
        }else{
            try{
                //create SQL select statement to verify if email address input exist in the database
                $sqlQuery = "SELECT email FROM users WHERE email =:email";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':email' => $email));

                //check if record exist
                if($statement->rowCount() == 1){

                    //SQL statement to update info
                    $sqlUpdate = "UPDATE users SET wp_street_name =:wp_street_name, wp_number =:wp_number, wp_suburb =:wp_suburb, wp_city =:wp_city, wp_province =:wp_province, wp_code =:wp_code, wp_country =:wp_country WHERE email=:email";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':wp_street_name' => $wp_street_name, ':wp_number' => $wp_number, ':wp_suburb' => $wp_suburb, ':wp_city' => $wp_city, ':wp_province' => $wp_province, ':wp_code' => $wp_code, ':wp_country' => $wp_country, ':email' => $email));

                    $result = "Your details was successfully updated";
			if(isset($wp_street_name)) $_SESSION['wp_street_name'] = $wp_street_name;
			if(isset($wp_number)) $_SESSION['wp_number'] = $wp_number;
			if(isset($wp_suburb)) $_SESSION['wp_suburb'] = $wp_suburb;
			if(isset($wp_city)) $_SESSION['wp_city'] = $wp_city;
			if(isset($wp_province)) $_SESSION['wp_province'] = $wp_province;
			if(isset($wp_code)) $_SESSION['wp_code'] = $wp_code;	
			if(isset($wp_country)) $_SESSION['wp_country'] = $wp_country;
                }
                else{
                    $result = "The email address provided does not exist in our database, please try again";
                }
            }catch (PDOException $ex){
                $result = "An error occurred: ".$ex->getMessage();
            }
        }
    }
    else{
        if(count($form_errors) == 1){
            $result = "There was 1 error in the form";
        }else{
            $result = "There were " .count($form_errors). " errors in the form";
        }
    }
}
?>
<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>