<?php
$pc_company_linkedin_status = $_SESSION['pc_company_linkedin_status'];
$pc_company_facebook_status = $_SESSION['pc_company_facebook_status'];
$pc_company_twitter_status = $_SESSION['pc_company_twitter_status'];
$pc_company_googleP_status = $_SESSION['pc_company_googleP_status'];
$pc_company_youtube_status = $_SESSION['pc_company_youtube_status'];
$pc_company_instagram_status = $_SESSION['pc_company_instagram_status'];
$pc_company_pinterest_status = $_SESSION['pc_company_pinterest_status'];
$pc_company_flickr_status = $_SESSION['pc_company_flickr_status'];
?>



<form id="pc_network_handles" method="post" action="" autocomplete="off">   

	<div>	
		<div id="pc_company_linkedin_field" class="groupl2" <?php if($pc_company_linkedin_status == 'pc_company_linkedinactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
									    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_linkedin.php';?>							
	    </div>
	    
	    <div id="pc_company_facebook_field" class="groupl2" <?php if($pc_company_facebook_status == 'pc_company_facebookactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
									    <?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_facebook.php';?>							
	    </div>
	    
		<div id="pc_company_twitter_field" class="groupl2" <?php if($pc_company_twitter_status == 'pc_company_twitteractive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_twitter.php'; ?> 
	    </div>
	    
		<div id="pc_company_googleP_field" class="groupl2" <?php if($pc_company_googleP_status == 'pc_company_googlePactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_googleP.php'; ?>
	    </div>
	    
		<div id="pc_company_youtube_field" class="groupl2" <?php if($pc_company_youtube_status == 'pc_company_youtubeactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_youtube.php'; ?>
		</div>
		
		<div id="pc_company_instagram_field" class="groupl2" <?php if($pc_company_instagram_status == 'pc_company_instagramactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>								
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_instagram.php'; ?>
	    </div>
	    
		<div id="pc_company_pinterest_field" class="groupl2" <?php if($pc_company_pinterest_status == 'pc_company_pinterestactive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>										
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_pinterest.php'; ?>
	    </div>
	    
		<div id="pc_company_flickr_field" class="groupl2" <?php if($pc_company_flickr_status == 'pc_company_flickractive') echo 'style="display: block;"';
else echo 'style="display: none;"';?>>
										<?php include_once '/home/eipchpco/beta.wiapp.it/portal/page/profile/account/mc/pc/data/fields/pc_company_flickr.php'; ?>
        </div>
</div>
									
</form>






<script>
$(document).ready(function(){
	$('input[name=\'pc_company_linkedin_status\']').click(function(){
  	var pc_company_linkedin_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_linkedin_status.php',
        method:'POST',
        data:{pc_company_linkedin_status:pc_company_linkedin_status},
        success: function(pc_company_linkedinresponse){
                    pc_company_linkedin_status_result = pc_company_linkedinresponse;
                    
                    if (pc_company_linkedin_status_result == 'pc_company_linkedinactive')
                        $("#pc_company_linkedin_field").show();
                    else    
                        $("#pc_company_linkedin_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_company_facebook_status\']').click(function(){
  	var pc_company_facebook_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_facebook_status.php',
        method:'POST',
        data:{pc_company_facebook_status:pc_company_facebook_status},
        success: function(pc_company_facebookresponse){
                    pc_company_facebook_status_result = pc_company_facebookresponse;
                    console.log(pc_company_facebook_status_result);
                    
                    if (pc_company_facebook_status_result == 'pc_company_facebookactive')
                        $("#pc_company_facebook_field").show();
                    else    
                        $("#pc_company_facebook_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_company_twitter_status\']').click(function(){
  	var pc_company_twitter_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_twitter_status.php',
        method:'POST',
        data:{pc_company_twitter_status:pc_company_twitter_status},
        success: function(pc_company_twitterresponse){
                    pc_company_twitter_status_result = pc_company_twitterresponse;
                    
                    if (pc_company_twitter_status_result == 'pc_company_twitteractive')
                        $("#pc_company_twitter_field").show();
                    else    
                        $("#pc_company_twitter_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_company_googleP_status\']').click(function(){
  	var pc_company_googleP_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_googleP_status.php',
        method:'POST',
        data:{pc_company_googleP_status:pc_company_googleP_status},
        success: function(pc_company_googlePresponse){
                    pc_company_googleP_status_result = pc_company_googlePresponse;
                    //console.log(pc_company_googleP_status_result);
                    
                    if (pc_company_googleP_status_result == 'pc_company_googlePactive')
                        $("#pc_company_googleP_field").show();
                    else    
                        $("#pc_company_googleP_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_company_youtube_status\']').click(function(){
  	var pc_company_youtube_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_youtube_status.php',
        method:'POST',
        data:{pc_company_youtube_status:pc_company_youtube_status},
        success: function(pc_company_youtuberesponse){
                    pc_company_youtube_status_result = pc_company_youtuberesponse;
                    
                    if (pc_company_youtube_status_result == 'pc_company_youtubeactive')
                        $("#pc_company_youtube_field").show();
                    else    
                        $("#pc_company_youtube_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_company_instagram_status\']').click(function(){
  	var pc_company_instagram_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_instagram_status.php',
        method:'POST',
        data:{pc_company_instagram_status:pc_company_instagram_status},
        success: function(pc_company_instagramresponse){
                    pc_company_instagram_status_result = pc_company_instagramresponse;
                    //console.log(pc_company_instagram_status_result);
                    
                    if (pc_company_instagram_status_result == 'pc_company_instagramactive')
                        $("#pc_company_instagram_field").show();
                    else    
                        $("#pc_company_instagram_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_company_pinterest_status\']').click(function(){
  	var pc_company_pinterest_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_pinterest_status.php',
        method:'POST',
        data:{pc_company_pinterest_status:pc_company_pinterest_status},
        success: function(pc_company_pinterestresponse){
                    pc_company_pinterest_status_result = pc_company_pinterestresponse;
                    //console.log(pc_company_pinterest_status_result);
                    
                    if (pc_company_pinterest_status_result == 'pc_company_pinterestactive')
                        $("#pc_company_pinterest_field").show();
                    else    
                        $("#pc_company_pinterest_field").hide();
                  } 
        });
  });
});
</script>


<script>
$(document).ready(function(){
	$('input[name=\'pc_company_flickr_status\']').click(function(){
  	var pc_company_flickr_status = $(this).val();
    $.ajax({
    	url:'/portal/page/profile/account/mc/pc/data/functions/func_pc_company_flickr_status.php',
        method:'POST',
        data:{pc_company_flickr_status:pc_company_flickr_status},
        success: function(pc_company_flickrresponse){
                    pc_company_flickr_status_result = pc_company_flickrresponse;
                    //console.log(pc_company_flickr_status_result);
                    
                    if (pc_company_flickr_status_result == 'pc_company_flickractive')
                        $("#pc_company_flickr_field").show();
                    else    
                        $("#pc_company_flickr_field").hide();
                  } 
        });
  });
});
</script>





