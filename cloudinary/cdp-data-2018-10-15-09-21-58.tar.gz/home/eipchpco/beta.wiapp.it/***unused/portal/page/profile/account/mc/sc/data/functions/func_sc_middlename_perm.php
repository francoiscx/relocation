<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$sc_middlename_perm = $_POST['sc_middlename_perm'];

//process the form if the button is clicked
if (isset($_POST['sc_middlename_perm'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlsc_middlename_permQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlsc_middlename_permQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlsc_middlename_permUpdate = "UPDATE social_card SET sc_middlename_perm =:sc_middlename_perm WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlsc_middlename_permUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_middlename_perm' => $sc_middlename_perm, ':userID' => $userID));

                    $sc_middlename_result = "Success";
                    $_SESSION['sc_middlename_perm'] = $sc_middlename_perm;
                
                 }catch (PDOException $ex){
                $sc_middlename_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info
                    $sqlsc_middlename_permInsert = "INSERT INTO social_card (userID, sc_middlename_perm)
                    VALUES (:userID, :sc_middlename_perm)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlsc_middlename_permInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':sc_middlename_perm' => $sc_middlename_perm));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $sc_middlename_result = "Success";
                    $_SESSION['sc_middlename_perm'] = $sc_middlename_perm;
	    	        }
                }
            }catch (PDOException $ex){
                $sc_middlename_result = "An error occurred: ".$ex->getMessage();
        }

 
echo $sc_middlename_result
?>