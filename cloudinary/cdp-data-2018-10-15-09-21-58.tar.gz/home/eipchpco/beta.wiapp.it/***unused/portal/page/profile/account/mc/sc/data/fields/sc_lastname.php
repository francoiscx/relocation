<?php
$sc_lastname = "sc_lastname";
$sc_lastname_perm = "sc_lastname_perm";
$sc_lastname_status = "sc_lastname_status";
?>


<div  id="sc_lastname_status"></div>

<!-- Start of Textfield for sc_lastname -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_lastname: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypingsc_lastname = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_lastname(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_lastname(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_lastname').donetypingsc_lastname(function(){
  	var sc_lastname = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_sc_lastname.php",
        method:"POST",
        data:{sc_lastname:sc_lastname},
        success: function(data){
      	$('#sc_lastname_result').html(data);
      }
    });  
});

});
</script>

<?php
$sc_lastname = $_SESSION['sc_lastname'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="sc_lastname"><fb-none class="icon-none" aria-hidden="true"></fb-none>Surname/s&nbsp<span><h5 id="sc_lastname_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="sc_lastname" name="sc_lastname" value="<?php echo $sc_lastname; ?>">
            
<!-- End of Textfield for sc_lastname -->






<!-- Start of Radio Buttons for sc_lastname_perm -->

<script>
$(document).ready(function(){
	$('input[name="sc_lastname_perm"]').click(function(){
  	var sc_lastname_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_sc_lastname_perm.php",
        method:"POST",
        data:{sc_lastname_perm:sc_lastname_perm},
        success: function(data){
      	$('#sc_lastname_result').html(data);
      }
    });
  });
});
</script>

<?php

$sc_lastname_perm = $_SESSION['sc_lastname_perm'];
switch ($sc_lastname_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_lastname_perm_pub" name="sc_lastname_perm" checked="checked" value="Public">
                <label for="sc_lastname_perm_pub" id="sc_lastname_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_lastname_perm_req" name="sc_lastname_perm" value="Request">
                <label for="sc_lastname_perm_req" id="sc_lastname_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_lastname_perm_pri" name="sc_lastname_perm" value="Private">
                <label for="sc_lastname_perm_pri" id="sc_lastname_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_lastname_perm_pub" name="sc_lastname_perm" value="Public">
                <label for="sc_lastname_perm_pub" id="sc_lastname_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_lastname_perm_req" name="sc_lastname_perm" checked="checked" value="Request">
                <label for="sc_lastname_perm_req" id="sc_lastname_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_lastname_perm_pri" name="sc_lastname_perm" value="Private">
                <label for="sc_lastname_perm_pri" id="sc_lastname_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_lastname_perm_pub" name="sc_lastname_perm" value="Public">
                <label for="sc_lastname_perm_pub" id="sc_lastname_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_lastname_perm_req" name="sc_lastname_perm" value="Request">
                <label for="sc_lastname_perm_req" id="sc_lastname_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_lastname_perm_pri" name="sc_lastname_perm" checked="checked" value="Private">
                <label for="sc_lastname_perm_pri" id="sc_lastname_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#sc_lastname_result").text(texts[count]);
    count < 4 ? count++ : count = 0;
}
setInterval(changeText, 5e2);
</script>
</div>
<!-- End of Radio Buttons for sc_lastname_perm -->