<?php
$sc_gender = "sc_gender";
$sc_gender_perm = "sc_gender_perm";
$sc_gender_status = "sc_gender_status";
?>

<div  id="sc_gender_status"></div>

<!-- Start of Textfield for sc_gender -->
<div class="groupl">
    
<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingsc_gender: function(callback,timeout){
            timeout = timeout || 2e3; // 2 second default timeout
            var timeoutReference,
                doneTypingsc_gender = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingsc_gender(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingsc_gender(el);
                });
            });
        }
    });
})(jQuery);


$('#sc_gender').donetypingsc_gender(function(){
  	var sc_gender = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_sc_gender.php",
        method:"POST",
        data:{sc_gender:sc_gender},
        success: function(data){
      	$('#sc_gender_result').html(data);
      }
    });  
});

});
</script>

<?php
$sc_gender = $_SESSION['sc_gender'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px; padding-bottom=10px" for="sc_gender"><fb-none class="icon-none" aria-hidden="true"></fb-none>Gender&nbsp<span><h5 id="sc_gender_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="sc_gender" name="sc_gender" value="<?php echo $sc_gender; ?>">
            
<!-- End of Textfield for sc_gender -->






<!-- Start of Radio Buttons for sc_gender_perm -->

<script>
$(document).ready(function(){
	$('input[name="sc_gender_perm"]').click(function(){
  	var sc_gender_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/gc/data/functions/func_sc_gender_perm.php",
        method:"POST",
        data:{sc_gender_perm:sc_gender_perm},
        success: function(data){
      	$('#sc_gender_result').html(data);
      }
    });
  });
});
</script>

<?php

$sc_gender_perm = $_SESSION['sc_gender_perm'];
switch ($sc_gender_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_gender_perm_pub" name="sc_gender_perm" checked="checked" value="Public">
                <label for="sc_gender_perm_pub" id="sc_gender_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_gender_perm_req" name="sc_gender_perm" value="Request">
                <label for="sc_gender_perm_req" id="sc_gender_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_gender_perm_pri" name="sc_gender_perm" value="Private">
                <label for="sc_gender_perm_pri" id="sc_gender_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_gender_perm_pub" name="sc_gender_perm" value="Public">
                <label for="sc_gender_perm_pub" id="sc_gender_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_gender_perm_req" name="sc_gender_perm" checked="checked" value="Request">
                <label for="sc_gender_perm_req" id="sc_gender_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_gender_perm_pri" name="sc_gender_perm" value="Private">
                <label for="sc_gender_perm_pri" id="sc_gender_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="sc_gender_perm_pub" name="sc_gender_perm" value="Public">
                <label for="sc_gender_perm_pub" id="sc_gender_perm_pub">Public</label>
                <input type="radio" class="radio" id="sc_gender_perm_req" name="sc_gender_perm" value="Request">
                <label for="sc_gender_perm_req" id="sc_gender_perm_req">On Request</label>
                <input type="radio" class="radio" id="sc_gender_perm_pri" name="sc_gender_perm" checked="checked" value="Private">
                <label for="sc_gender_perm_pri" id="sc_gender_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#sc_gender_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 5e2);
</script>
</div>
<!-- End of Radio Buttons for sc_gender_perm -->