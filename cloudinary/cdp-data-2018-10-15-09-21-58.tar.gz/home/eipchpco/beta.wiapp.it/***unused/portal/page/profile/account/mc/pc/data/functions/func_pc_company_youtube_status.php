<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

$userID = $_SESSION['id'];
$pc_company_youtube_status = $_POST['pc_company_youtube_status'];

//process the form if the button is clicked
if (isset($_POST['pc_company_youtube_status'])) 
            try{
                //create SQL select statement to verify if userID exist in the professional_card database
                $sqlpc_company_youtube_statusQuery = "SELECT userID FROM professional_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlpc_company_youtube_statusQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                 try{   

                    //SQL statement to update card
                    $sqlpc_company_youtube_statusUpdate = "UPDATE professional_card SET pc_company_youtube_status =:pc_company_youtube_status WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlpc_company_youtube_statusUpdate);

                    //execute the statement
                    $statement->execute(array(':pc_company_youtube_status' => $pc_company_youtube_status, ':userID' => $userID));

                    $pc_company_youtube_status_result = 'pc_company_youtube_status';
                    $_SESSION['pc_company_youtube_status'] = $pc_company_youtube_status;
                
                 }catch (PDOException $ex){
                $pc_company_youtube_status_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{

                    //SQL statement to insert info into card
                    $sqlpc_company_youtube_statusInsert = "INSERT INTO professional_card (userID, pc_company_youtube_status)
                    VALUES (:userID, :pc_company_youtube_status)";
            
                    //use PDO prepared to sanitize data
                    $statement = $db->prepare($sqlpc_company_youtube_statusInsert);

                    //add the data into the database
                    $statement->execute(array(':userID' => $userID, ':pc_company_youtube_status' => $pc_company_youtube_status));

                    //check if one new row was created
	    	        if($statement->rowCount() == 1){
	    	            
                    $pc_company_youtube_status_result = 'pc_company_youtube_status';
                    $_SESSION['pc_company_youtube_status'] = $pc_company_youtube_status;
	    	        }
                }
            }catch (PDOException $ex){
                $pc_company_youtube_status_result = "An error occurred: ".$ex->getMessage();
        }

 if ($pc_company_youtube_status == pc_company_youtubeactive) echo "pc_company_youtubeactive";
 else if ($pc_company_youtube_status != pc_company_youtubeactive) echo "pc_company_youtubepassive";

?>