<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$sc_cell = $_POST['sc_cell'];

//process the form if the button is clicked
if (isset($_POST['sc_cell'])) 
            try{
                //create SQL select statement to verify if userID exist in the social_card database
                $sqlQuery = "SELECT userID FROM social_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE social_card SET sc_cell =:sc_cell WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':sc_cell' => $sc_cell, ':userID' => $userID));

                    $sc_cell_result = "Success";
                    $_SESSION['sc_cell'] = $sc_cell;
                    
                 }catch (PDOException $ex){
                $sc_cell_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO social_card (userID, sc_cell)
                        VALUES (:userID, :sc_cell)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':sc_cell' => $sc_cell));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $sc_cell_result = "Data was successfully captured";
                }
   
                    $sc_cell_result = "Success";
                    
                    $_SESSION['sc_cell'] = $sc_cell;
                }
            }catch (PDOException $ex){
                $sc_cell_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $sc_cell_result
?>

