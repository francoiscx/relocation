<?php
$pc_age = "pc_age";
$pc_age_perm = "pc_age_perm";
$pc_age_status = "pc_age_status";
?>


<?php
 //date in mm/dd/yyyy format; or it can be in other formats as well
 $birthDate = $_SESSION['dob'];
 //explode the date to get month, day and year
 $birthDate = explode("/", $birthDate);
 //get pc_age from date or birthdate
 $pc_age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
 	? ((date("Y") - $birthDate[2]) - 1)
    	: (date("Y") - $birthDate[2]));
?>


<!-- Start of Textfield for pc_age -->

<script>
$(document).ready(function() {
    
(function($){
    $.fn.extend({
        donetypingpc_age: function(callback,timeout){
            timeout = timeout || 1e3; // 1 second default timeout
            var timeoutReference,
                doneTypingpc_age = function(el){
                    if (!timeoutReference) return;
                    timeoutReference = null;
                    callback.call(el);
                };
            return this.each(function(i,el){
                var $el = $(el);
                // Chrome Fix (Use keyup over keypress to detect backspace)
                $el.is(':input') && $el.on('keyup keypress paste',function(e){
                    // This catches the backspace button in chrome, but also prevents
                    // the event from triggering too preemptively. Without this line,
                    // using tab/shift+tab will make the focused element fire the callback.
                    if (e.type=='keyup' && e.keyCode!=8) return;
                    
                    // Check if timeout has been set. If it has, "reset" the clock and
                    // start over again.
                    if (timeoutReference) clearTimeout(timeoutReference);
                    timeoutReference = setTimeout(function(){
                        // if we made it here, our timeout has elapsed. Fire the
                        // callback
                        doneTypingpc_age(el);
                    }, timeout);
                }).on('blur',function(){
                    // If we can, fire the event since we're leaving the field
                    doneTypingpc_age(el);
                });
            });
        }
    });
})(jQuery);


$('#pc_age').donetypingpc_age(function(){
  	var pc_age = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_age.php",
        method:"POST",
        data:{pc_age:pc_age},
        success: function(data){
      	$('#pc_age_result').html(data);
      }
    });  
});

});
</script>

<?php
$pc_age = $_SESSION['pc_age'];
?>

<div>
    <div class="field" style="padding-bottom:15px">		
	    <label style="font-size:13px" for="pc_age" >Age&nbsp<span><h5 id="pc_age_result" style="float:right; color:#381A64"></h5></span></label>
            <input type="text" id="pc_age" name="pc_age" value="<?php echo $pc_age; ?>">
            
<!-- End of Textfield for pc_age -->






<!-- Start of Radio Buttons for pc_age_perm -->

<script>
$(document).ready(function(){
	$('input[name="pc_age_perm"]').click(function(){
  	var pc_age_perm = $(this).val();
    $.ajax({
    	url:"/portal/page/profile/account/mc/pc/data/functions/func_pc_age_perm.php",
        method:"POST",
        data:{pc_age_perm:pc_age_perm},
        success: function(data){
      	$('#pc_age_result').html(data);
      }
    });
  });
});
</script>

<?php

$pc_age_perm = $_SESSION['pc_age_perm'];
switch ($pc_age_perm) {
    case "Public":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_age_perm_pub" name="pc_age_perm" checked="checked" value="Public">
                <label for="pc_age_perm_pub" id="pc_age_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_age_perm_req" name="pc_age_perm" value="Request">
                <label for="pc_age_perm_req" id="pc_age_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_age_perm_pri" name="pc_age_perm" value="Private">
                <label for="pc_age_perm_pri" id="pc_age_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    case "Request":
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_age_perm_pub" name="pc_age_perm" value="Public">
                <label for="pc_age_perm_pub" id="pc_age_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_age_perm_req" name="pc_age_perm" checked="checked" value="Request">
                <label for="pc_age_perm_req" id="pc_age_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_age_perm_pri" name="pc_age_perm" value="Private">
                <label for="pc_age_perm_pri" id="pc_age_perm_pri">Only Me</label>
            <a></a>
        </div>
';
        break;
    default:
        echo '<div class="switch-toggle switch-3 switch-candy">
                <input type="radio" class="radio" id="pc_age_perm_pub" name="pc_age_perm" value="Public">
                <label for="pc_age_perm_pub" id="pc_age_perm_pub">Public</label>
                <input type="radio" class="radio" id="pc_age_perm_req" name="pc_age_perm" value="Request">
                <label for="pc_age_perm_req" id="pc_age_perm_req">On Request</label>
                <input type="radio" class="radio" id="pc_age_perm_pri" name="pc_age_perm" checked="checked" value="Private">
                <label for="pc_age_perm_pri" id="pc_age_perm_pri">Only Me</label>
            <a></a>
        </div>
';
}

?>

    </div> <!-- /field -->
</div>

<script>
var texts = [""];
var count = 0;
function changeText() {
    $("#pc_age_result").text(texts[count]);
    count < 3 ? count++ : count = 0;
}
setInterval(changeText, 500);
</script>

<!-- End of Radio Buttons for pc_age_perm -->
