<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';
$userID = $_SESSION['id'];
$gc_age = $_POST['gc_age'];

//process the form if the button is clicked
if (isset($_POST['gc_age'])) 
            try{
                //create SQL select statement to verify if userID exist in the general_card database
                $sqlQuery = "SELECT userID FROM general_card WHERE userID =:userID";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':userID' => $userID));

                //check if record exist
                if($statement->rowCount() == 1){

                try{   
                    //SQL statement to update card
                    $sqlUpdate = "UPDATE general_card SET gc_age =:gc_age WHERE userID =:userID";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':gc_age' => $gc_age, ':userID' => $userID));

                    $gc_age_result = "Success";
                    $_SESSION['gc_age'] = $gc_age;
                    
                 }catch (PDOException $ex){
                $gc_age_result = "An error occurred: ".$ex->getMessage();
        }   
                }else{
                    
                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                        //SQL statement to insert info
                        $sqlInsert = "INSERT INTO general_card (userID, gc_age)
                        VALUES (:userID, :gc_age)";
            
                        //use PDO prepared to sanitize data
                        $statement = $db->prepare($sqlInsert);

                        //add the data into the database
                        $statement->execute(array(':userID' => $userID, ':gc_age' => $gc_age));

                        //check if one new row was created
	    	            if($statement->rowCount() == 1){
		    	           $gc_age_result = "Success";
                }
   
                    $gc_age_result = "Card was created";
                    
                    $_SESSION['gc_age'] = $gc_age;
                }
            }catch (PDOException $ex){
                $gc_age_result = "An error occurred: ".$ex->getMessage();
            }

 
echo $gc_age_result
?>

