<!-- Start of Radio Buttons for pc_facebook_status -->
<div class="groupl">

<?php

$pc_facebook_status = $_SESSION['pc_facebook_status'];

if(!isset($pc_facebook_status)) {$pc_facebook_status = 'pc_facebookpassive'; }



//echo $pc_facebook_status;

switch ($pc_facebook_status) {
    case "pc_facebookactive":
        echo "
<div>

    <div class='pc_facebook_selection' id='pc_facebookactive'>
    <a class='pc_facebook_selectionSwitch' href='#pc_facebookpassive'><input type='radio' id='pc_facebook_status_on' name='pc_facebook_status' value='pc_facebookpassive' hidden> 
    <label for='pc_facebook_status_on' class='pc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>

  <div class='pc_facebook_selection' id='pc_facebookpassive'>
    <a class='pc_facebook_selectionSwitch' href='#pc_facebookactive'><input type='radio' id='pc_facebook_status_off' name='pc_facebook_status' value='pc_facebookactive' hidden>
    <label for='pc_facebook_status_off' class='pc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
</div>


<script>
$(document).ready(function () {
    $('#pc_facebook_status').on('click', function () {
        check = $('#pc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.pc_facebook_Check i').hasClass('icon-check-square')) {
                $('.pc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
            }
        } else {
            if ($('.pc_facebook_Check i').hasClass('icon-square-o')) {
                $('.pc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_facebook_status = $('#pc_facebookactive, #pc_facebookpassive').hide();
$('#pc_facebookactive').show();
$('#pc_facebookpassive').hide();
$('.pc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_facebook_status.hide();
    $(href).show();
})
});
</script>

";
        break;
    case "pc_facebookpassive":
        echo "
<div>

  <div class='pc_facebook_selection' id='pc_facebookpassive'>
    <a class='pc_facebook_selectionSwitch' href='#pc_facebookactive'><input type='radio' id='pc_facebook_status_off' name='pc_facebook_status' value='pc_facebookactive' hidden>
    <label for='pc_facebook_status_off' class='pc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>
  
  <div class='pc_facebook_selection' id='pc_facebookactive'>
    <a class='pc_facebook_selectionSwitch' href='#pc_facebookpassive'><input type='radio' id='pc_facebook_status_on' name='pc_facebook_status' value='pc_facebookpassive' hidden>
    <label for='pc_facebook_status_on' class='pc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>


  
</div>


<script>
$(document).ready(function () {
    $('#pc_facebook_status').on('click', function () {
        check = $('#pc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.pc_facebook_Check i').hasClass('icon-square-o')) {
                $('.pc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square');
            }
        } else {
            if ($('.pc_facebook_Check i').hasClass('icon-check-square')) {
                $('.pc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_facebook_status = $('#pc_facebookactive, #pc_facebookpassive').hide();
$('#pc_facebookactive').hide();
$('#pc_facebookpassive').show();
$('.pc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_facebook_status.hide();
    $(href).show();
})
});
</script>

";

        break;
    default:
        echo "
        
<div>

  <div class='pc_facebook_selection' id='pc_facebookpassive'>
    <a class='pc_facebook_selectionSwitch' href='#pc_facebookactive'><input type='radio' id='pc_facebook_status_off' name='pc_facebook_status' value='pc_facebookactive' hidden>
    <label for='pc_facebook_status_off' class='pc_facebook_Check'>
    <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-square-o'></i>
    </label></a>
  </div>


  <div class='pc_facebook_selection' id='pc_facebookactive'>
    <a class='pc_facebook_selectionSwitch' href='#pc_facebookpassive'><input type='radio' id='pc_facebook_status_on' name='pc_facebook_status' value='pc_facebookpassive' hidden>
    <label for='pc_facebook_status_on' class='pc_facebook_Check'>
     <fa-facebook class='icon-facebook-square' aria-hidden='true'></fa-facebook>facebook
    <i class='icon-check-square'></i>
    </label></a>
  </div>
  
</div>

<script>
$(document).ready(function () {
    $('#pc_facebook_status').on('click', function () {
        check = $('#pc_facebook_status').prop('checked');
        
        if (check) {
            if ($('.pc_facebook_Check i').hasClass('icon-square-o')) {
                $('.pc_facebook_Check i').removeClass('icon-square-o').addClass('icon-check-square').removeClass('hidden');
            }
        } else {
            if ($('.pc_facebook_Check i').hasClass('icon-check-square')) {
                $('.pc_facebook_Check i').removeClass('icon-check-square').addClass('icon-square-o');
                 
            }    
        }     
    });
});
</script>

<script>
$(document).ready(function(){
var $pc_facebook_status = $('#pc_facebookactive, #pc_facebookpassive').hide();
$('#pc_facebookactive').hide();
$('#pc_facebookpassive').show();
$('.pc_facebook_selectionSwitch').click(function () {
    var href = $(this).attr('href');
    $pc_facebook_status.hide();
    $(href).show();
})
});
</script>


";
}

?>



</div>