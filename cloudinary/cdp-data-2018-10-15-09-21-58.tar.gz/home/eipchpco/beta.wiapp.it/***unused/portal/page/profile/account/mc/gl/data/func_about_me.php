<?php
//add our database connection script
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php'; 
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/database.php';
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/utilities.php';

//process the form if the button is clicked
if (isset($_POST['u_first_name'], $_POST['u_last_name'], $_POST['Cell'], $_POST['u_gender'])) {
    //initialize an array to store any error message from the form
    $form_errors = array();

    //Fields that requires checking for minimum length
    $fields_to_check_length = array('Cell' => 10);

    //call the function to check minimum required length and merge the return data into form_error array
    $form_errors = array_merge($form_errors, check_min_length($fields_to_check_length));

            //check if error array is empty, if yes process form data and insert record
    if(empty($form_errors)){
        //collect form data and store in variables
        $email = $_SESSION['email'];
        $dob = $_SESSION['dob'];
        $u_first_name = $_POST['u_first_name'];
        $u_middle_name = $_POST['u_middle_name'];
        $u_last_name = $_POST['u_last_name'];
        $u_cell = $_POST['Cell'];
        $u_gender = $_POST['u_gender'];  
        $u_status = $_POST['u_status'];
        
        		//Fields to change Case to Name
		$u_first_name = name_field($u_first_name);
		$u_middle_name = name_field($u_middle_name);		
		$u_last_name = name_field($u_last_name);
        
        if(isset($_SESSION['dob'])) {
        		$dob1 = $_SESSION['dob'];
        		}else{
        		$dob1 = $_POST['dob'];
        	}
  	//explode the date to get month, day and year
  	$dob1 = explode("/", $dob1);
  	//get age from date or birth
  	$age = (date("md", date("U", mktime(0, 0, 0, $dob1[0], $dob1[1], $dob1[2]))) > date("md")
   	 ? ((date("Y") - $dob1[2]) - 1)
   	 : (date("Y") - $dob1[2]));
   	 $_SESSION['age'] = $age;
        
        //check if user is old enough
        if($age < 13){
            $result = "Are you $age? You need to be 13 years or older to use Wi-APP! Please enter your correct age or terminate the use of this account until you are 13 years of age.";
        }else{
            try{
                //create SQL select statement to verify if email address input exist in the database
                $sqlQuery = "SELECT email FROM users WHERE email =:email";

                //use PDO prepared to sanitize data
                $statement = $db->prepare($sqlQuery);

                //execute the query
                $statement->execute(array(':email' => $email));

                //check if record exist
                if($statement->rowCount() == 1){

                    //SQL statement to update info
                    $sqlUpdate = "UPDATE users SET first_name =:firstname, middle_name =:middlename, last_name =:lastname, cell =:cell, dob =:dob, age =:age, gender =:gender, status =:status WHERE email=:email";

                    //use PDO prepared to sanitize SQL statement
                    $statement = $db->prepare($sqlUpdate);

                    //execute the statement
                    $statement->execute(array(':firstname' => $u_first_name, ':middlename' => $u_middle_name, ':lastname' => $u_last_name, ':cell' => $u_cell, ':dob' => $dob, ':age' => $age, ':gender' => $u_gender, ':status' => $u_status, ':email' => $email));

                    $result = "Your details was successfully updated";
			if(isset($u_first_name)) $_SESSION['first_name'] = $u_first_name;
			if(isset($u_middle_name)) $_SESSION['middle_name'] = $u_middle_name;
			if(isset($u_last_name)) $_SESSION['last_name'] = $u_last_name; 
			if(isset($u_cell)) $_SESSION['cell'] = $u_cell;
        		if(isset($u_gender)) $_SESSION['gender'] = $u_gender;  
        		if(isset($u_status)) $_SESSION['status'] = $u_status;
                }
                else{
                    $result = "The email address provided does not exist in our database, please try again";
                }
            }catch (PDOException $ex){
                $result = "An error occurred: ".$ex->getMessage();
            }
        }
    }
    else{
        if(count($form_errors) == 1){
            $result = "There was 1 error in the form";
        }else{
            $result = "There were " .count($form_errors). " errors in the form";
        }
    }
}
?>

<?php if(isset($result)) echo $result; ?>
<?php if(!empty($form_errors)) echo show_errors($form_errors); ?>