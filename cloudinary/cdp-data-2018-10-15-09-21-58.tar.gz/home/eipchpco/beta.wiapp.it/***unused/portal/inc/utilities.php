<?php


//display succcess message
//echo "<br>Utilities is also Connected<br>";
/**
 * @param $required_fields_array, n array containing the list of all required fields
 * @return array, containing all errors
 */
function check_empty_fields($required_fields_array){
    //initialize an array to store error messages
    $form_errors = array();

    //loop through the required fields array snd populate the form error array
    foreach($required_fields_array as $name_of_field){
        if(!isset($_POST[$name_of_field]) || $_POST[$name_of_field] == NULL){
            $form_errors[] = $name_of_field . " is a required field";
        }
    }

    return $form_errors;
}


function check_if_empty($required){
    //initialize an array to store error messages
    $form_errors = array();

    //loop through the required fields array snd populate the form error array
    foreach($required as $name_of_field){
        if(!isset($_POST[$name_of_field]) || $_POST[$name_of_field] == NULL){
            $form_errors[] = $name_of_field . " & Conditions need to be accepted before you can make use of our services.";
        }
    }

    return $form_errors;
}

/**
 * @param $fields_to_check_length, an array containing the name of fields
 * for which we want to check min required length e.g array('username' => 4, 'email' => 12)
 * @return array, containing all errors
 */
function check_min_length($fields_to_check_length){
    //initialize an array to store error messages
    $form_errors = array();

    foreach($fields_to_check_length as $name_of_field => $minimum_length_required){
        if(strlen(trim($_POST[$name_of_field])) < $minimum_length_required && $_POST[$name_of_field] != NULL){
            $form_errors[] = $name_of_field . " is too short, must be {$minimum_length_required} characters long";
        }
    }
    return $form_errors;
}




/**
 * @param $data, store a key/value pair array where key is the name of the form control
 * in this case 'email' and value is the input entered by the user
 * @return array, containing email error
 */
function check_email($data){
    //initialize an array to store error messages
    $form_errors = array();
    $key = 'Email';
    //check if the key email exist in data array
    if(array_key_exists($key, $data)){

        //check if the email field has a value
        if($_POST[$key] != null){

            // Remove all illegal characters from email
            $key = filter_var($key, FILTER_SANITIZE_EMAIL);

            //check if input is a valid email address
            if(filter_var($_POST[$key], FILTER_VALIDATE_EMAIL) === false){
                $form_errors[] = "<b>" . $_POST[$key] . "</b> does not seem to be a valid email address";
            }
        }
    }
    return $form_errors;
}




/**
 * @param $form_errors_array, the array holding all
 * errors which we want to loop through
 * @return string, list containing all error messages
 */
function show_errors($form_errors_array){
    $errors = ": ";

    //loop through error array and display all items in a list
    foreach($form_errors_array as $the_error){
        $errors .= "{$the_error}";
    }
    $errors .= "";
    return $errors;
}






/**
 * echo name_field("john o'grady-smith"); 	returns John O'Grady-Smith
 * change strings to first letter upper case
 * @return array, containing all errors
 */
function name_field($str,$a_char = array("'","-"," ")){   
    //$str contains the complete raw name string
    //$a_char is an array containing the characters we use as separators for capitalization. If you don't pass anything, there are three in there as default.
    $string = strtolower($str);
    foreach ($a_char as $temp){
        $pos = strpos($string,$temp);
        if ($pos){
            //we are in the loop because we found one of the special characters in the array, so lets split it up into chunks and capitalize each one.
            $mend = '';
            $a_split = explode($temp,$string);
            foreach ($a_split as $temp2){
                //capitalize each portion of the string which was separated at a special character
                $mend .= ucfirst($temp2).$temp;
                }
            $string = substr($mend,0,-1);
            }   
        }
    return ucfirst($string);
    }






function report($message, $eval = "Fail"){
	if($eval === "Pass"){
		$data = "<p style='padding: 20px; border: 1px solid gray; color: green;'>{$message}</p>";
	
  	 }else{
		$data = "<p style='padding: 20px; border: 1px solid gray; color: red;'>{$message}</p>";
	}
	return $data;	
}



function denyDuplicate($value, $db){

	try{
		$sqlQuery = "SELECT email FROM users WHERE email=:email";
		$statement = $db->prepare($sqlQuery);
		$statement->execute(array(':email' => $value));
		
		if($row = $statement->fetch()){
			return true;
		}
			return false;
	}catch (PDOException $ex){
		//handle exception
	}
	
}

function hasPC($value, $db){

	try{
		$sqlQuery = "SELECT userID FROM professional_card WHERE userID=:id";
		$statement = $db->prepare($sqlQuery);
		$statement->execute(array(':id' => $value));
		
		if($row = $statement->fetch()){
			return true;
		}
			return false;
	}catch (PDOException $ex){
		//handle exception
	}
	
}














