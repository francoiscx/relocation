<?php

require '/home/eipchpco/beta.wiapp.it/phpmailer/class.phpmailer.php';

$mail = new PHPMailer;

$mail->IsSMTP();                                      // Set mailer to use SMTP
$mail->Host = gethostbyname('tls://smtp.gmail.com');
$mail->Host = 'localhost';  // Specify main and backup server
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'system@beta.wiapp.it';                            // SMTP username
$mail->Password = 'System101Mail';                           // SMTP password
$mail->SMTPSecure = /*'tls'*/'';                            // Enable encryption, 'ssl' also accepted

$mail->From = 'system@beta.wiapp.it';
$mail->FromName = 'Wi-APP | Beta |System Generated Mail (Do not reply) ';
//$mail->AddAddress('josh@example.net', 'Josh Adams');  // Add a recipient
$mail->AddAddress('francoiscx@icloud.com');               // Name is optional
//$mail->AddReplyTo('info@example.com', 'Information');
//$mail->AddCC('cc@example.com');
//$mail->AddBCC('bcc@example.com');

$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
$mail->AddAttachment('/var/tmp/file.tar.gz');         // Add attachments
$mail->AddAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->IsHTML(true);                                  // Set email format to HTML

$mail->Subject = 'A new member has registered for Wi-APP | Beta';
$mail->Body    = '<br>Notice: </b> A new user was registered on Wi-APP | Beta';
$mail->AltBody = 'A new user was registered on Wi-APP | Beta';

if(!$mail->Send()) {
   echo 'Message could not be sent.';
   echo 'Mailer Error: ' . $mail->ErrorInfo;
   exit;
}

//echo 'Message has been sent';

?>