<body> 
<div class="navbar navbar-fixed-top">
	<div class="navbar-inner">
	  <div>
            <?php
  	        echo '<div class="container"><a href="http://beta.wiapp.it"><img src="/portal/img/tiles/apple-icon-152x152.png" width="70px" hspace="5" alt="Wi-APP"></a>'; 
            ?> 	    
	    </div> 
		<div class="container"> 

		    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
			    <div class="wnext">
			    	<span class="icon-bar"></span>
			    	<span class="icon-bar"></span>
			    	<span class="icon-bar"></span>
			    </div>				
			</a>

            <a class="brand" href="/portal/index.php">Wi-APP</a>
			    <div class="nav-collapse">
				    <ul class="nav pull-right">
						<li class="dropdown">
		   					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
	 								<div class="wtext">
	 								<?php echo $_SESSION['username'];?>
	 								</div>
									&nbsp<b class="caret"></b>

                            </a>
				                <ul class="dropdown-menu">
              					    <li><a href="/portal/profile.php"><div class="igwico"> <i class="icon-user"></i></div><b>&nbsp&nbspProfile</b></a></li> <br>                        							
            					    <li><a href="/portal/settings.php"><div class="igwico"> <i class="icon-wi-app-gear-dark"></i></div><b>&nbsp&nbspSettings</b></a></li>
							        <li><a href="/portal/profile.php"><div class="igwico">  <i class="icon-info">    </i></div><b>&nbsp&nbspHelp</b></a></li>
              					    <li><a href="/portal/page/logout.php"> <div class="igwico"> <i class="icon-sign-out"> </i></div><b>&nbsp&nbspLogout</b></a></li>
								</ul>
          				</li>
       				</ul>
                </div><!--/.nav-collapse -->
    	    </div><!-- /container -->
    </div><!-- /navbar-inner -->
</div><!-- /navbar -->