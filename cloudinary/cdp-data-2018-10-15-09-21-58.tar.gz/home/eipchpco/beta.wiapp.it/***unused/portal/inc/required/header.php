<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php' ?>
<?php if(!isset($_SESSION['id'])) header("location:/portal/page/logout.php");?>
<!DOCTYPE HTML>
<html lang="en">
<head>
  <title>Wi-APP <?php if(isset($Page)) echo " | ";?> <?php echo $Page; ?></title> 
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta content='width=device-width, maximum-scale=1.0, user-scalable=0' name='viewport'>
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="/portal/img/tiles/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff"><link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
  
<?php require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';?>

<!--Home Screen Buttons-->
<link rel="shortcut icon" href="/portal/img/tiles/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" sizes="57x57" href="/portal/img/tiles/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/portal/img/tiles/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/portal/img/tiles/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/portal/img/tiles/apple-icon-76x76.png"> 
<link rel="apple-touch-icon" sizes="114x114" href="/portal/img/tiles/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/portal/img/tiles/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/portal/img/tiles/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/portal/img/tiles/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/portal/img/tiles/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="/portal/img/tiles/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/portal/img/tiles/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/portal/img/tiles/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/portal/img/tiles/favicon-16x16.png">
<link href="https://file.myfontastic.com/KKqgH4SYhM9ooPCkVerp8m/icons.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<link rel="stylesheet" href="/portal/css/bootstrap-3.3.7.min.css">
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

<!-- <link href="/portal/css/font-awesome-4.1.0.min.css" rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet"> -->

<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    echo '<link href="/portal/css/bootstrapi.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivei.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylei.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitchi.css" rel="stylesheet">';
}
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    echo '<link href="/portal/css/bootstrapa.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivea.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylea.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitcha.css" rel="stylesheet">';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/carda.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1carda.css" rel="stylesheet">';}
}
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    echo '<link href="/portal/css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivem.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylem.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitchm.css" rel="stylesheet">';
    if ((isset($ccardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/cardm.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1cardm.css" rel="stylesheet">';}
}
else if (Detect::isComputer()) {
    $notmobile = 101;
    //echo 'Computer';
    echo '<link href="/portal/css/bootstrap.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsive.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/style.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitch.css" rel="stylesheet">';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/card.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1card.css" rel="stylesheet">';}
}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    echo '<link href="/portal/css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/bootstrap-responsivem.min.css" rel="stylesheet">';
    echo '<link href="/portal/css/stylem.css" rel="stylesheet">';
    echo '<link href="/portal/css/toggleSwitchm.css" rel="stylesheet">';
    if ((isset($cardStyle) ? $cardStyle : null) == 'card') { echo '<link href="/portal/css/pages/cards/cardm.css" rel="stylesheet">';}
    if ((isset($cardStyle) ? $cardStyle : null) == '1card') { echo '<link href="/portal/css/pages/cards/1cardm.css" rel="stylesheet">';}
}

?>
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<!--[endif]-->

</head>