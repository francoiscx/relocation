<?php
header("location: /portal.php");
?>