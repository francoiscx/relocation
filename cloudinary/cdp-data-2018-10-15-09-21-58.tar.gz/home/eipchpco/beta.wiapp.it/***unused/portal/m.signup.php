<?php
include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/sessions.php';
require_once '/home/eipchpco/beta.wiapp.it/portal/inc/detect.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Wi-APP | Registration</title>
<meta name = "viewport" content = "width = device-width">
<meta name = "viewport" content = "initial-scale = 1.0, user-scalable = no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<link href="css/font-awesome.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

<?php
if (Detect::isiOS()) { //browser reported as an iPhone/iPod touch -- do something here
    //echo 'iPhone';
    echo '<link href="css/bootstrapi.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivei.min.css" rel="stylesheet">';
    echo '<link href="css/stylei.css" rel="stylesheet">';
    echo '<link href="css/pages/signini.css" rel="stylesheet">';
    }
else if (Detect::isAndroidOS()) { //browser reported as an Android -- do something here
    //echo 'Android';
    echo '<link href="css/bootstrapa.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivea.min.css" rel="stylesheet">';
    echo '<link href="css/stylea.css" rel="stylesheet">';
    echo '<link href="css/pages/signina.css" rel="stylesheet">';
    }
else if (Detect::isTablet()) {//browser reported as tablet device -- do something here
    //echo 'Tablet';
    echo '<link href="css/pages/signinm.css" rel="stylesheet">';
    echo '<link href="css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="css/stylem.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivem.min.css" rel="stylesheet">';
    }
else if (Detect::isComputer()) {
    $notmobile = 101;
    //echo 'Computer';
    echo '<link href="css/bootstrap.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsive.min.css" rel="stylesheet">';
    echo '<link href="css/style.css" rel="stylesheet">';
    echo '<link href="css/pages/signin.css" rel="stylesheet">';
}
else { //browser reported as other mobile device -- do something here
    //echo 'Other Mobile';
    echo '<link href="css/bootstrapm.min.css" rel="stylesheet">';
    echo '<link href="css/bootstrap-responsivem.min.css" rel="stylesheet">';    
    echo '<link href="css/stylem.css" rel="stylesheet">';
    echo '<link href="css/pages/signinm.css" rel="stylesheet">';
}

?>




    
</head>
<body>


<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
  <div>
    <div class="container">
                       <a href="http://beta.wiapp.it"><img src="/portal/img/tiles/apple-icon-152x152.png" width="70px" hspace="5" alt="Wi-APP"></a>
  </div>
  </div>
    <div class="container"> <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
    
    		  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span> 
                  
                  	</a><a class="brand" href="/portal/index.php">Wi-APP</a>
<?php			
include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/func_m.signup.php';
?>
			<div class="nav-collapse">
				<ul class="nav pull-right">
					 
					
					<li class="">						
						<a href="/info/index.php" class="">
							<i class="icon-info-sign "></i>
							Learn more about Wi-APP
						</a>
						
					</li>
				</ul>
				
			</div><!--/.nav-collapse -->	
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
</div> <!-- /navbar -->

<div class="account-container">
	
	<div class="content clearfix">
	
		
		<form method="post" action="" >
		
<?php if(isset($registered)) echo "<h1>Account Created!</h1>";						
	else if (isset($result)) echo "<h1>Oops! Some fixes required.</h1>";
	else echo "<h1>Create your account</h1>";?>		
	<div id='UserAvailResponse'></div>
	<div class="login-fields">
			
			
	
<?php if(isset($result)) echo $result;?>
<?php if(!empty($form_errors)) echo show_errors($form_errors);?>	
	
<?php if(!isset($result)) echo "<h3>Get started now, it's free</h3><br>";?>			
				
<?php if(!isset($result)) include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/m.register.php';?>
			
				
				
			</div> <!-- .actions -->
			
		</form>
		
		
		

		
	</div> <!-- /content -->
	
</div> <!-- /account-container -->

<!-- Text Under Box -->
<div class="login-extra" style="margin-bottom:100px">
<?php if(isset($registered)) include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/now_login.php';
else if (isset($result)) echo "<a href=\"javascript:history.go(-1)\">GO BACK</a>";
else include_once '/home/eipchpco/beta.wiapp.it/portal/modules/register/have_account.php';?>
</div> <!-- /login-extra -->

<?php include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';?> 
<?php include_once '/home/eipchpco/beta.wiapp.it/portal/inc/required/footer_bottom.php';?>

<script>
function checkServer()
{
    var ajaxrequest;
    var email = document.getElementById("Email").value;
    
    if (window.XMLHttpRequest)
    {
        ajaxrequest = new XMLHttpRequest();
    } else {
        ajaxrequest = new ActiveXObject("Microsoft.XMLHTTP"); /// Older Browsers
    }
    
    ajaxrequest.onreadystatechange = function()
    {
        console.log(ajaxrequest);
    if (ajaxrequest.readyState == 4 && ajaxrequest.status == 200)
    {
        document.getElementById("UserAvailResponse").innerHTML = ajaxrequest.responseText;
        }
    }
    ajaxrequest.open("POST", "/portal/modules/register/m.welcome_user.php", true);
    ajaxrequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajaxrequest.send("Email=" + email);
}
</script>


<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/signin.js"></script>

</body>

					
 </html>