$(document).ready(function() {
  /*This means when page is ready.
  ie. when the pages full HTML is loaded, this function will be executed.
  */


  /*Now we have to listen for form submission of our form with id add-form*/
  $('#add-form').submit(
    function(evt) {
      /*
        This means when the form is submitted this function should be executed.
        ie. we are assigning this function (listener) to the submit event of the form
        jquery will pass the event object as argument to this fn.
        So I added first argument with name evt. ( You can put any name, It is just a variable )
      */

      /*
        Now what we have to do is prevent the default action when form is submitted.
        Default action when form is submitted is, submit to the specific page which is mentioned in form's action.
        We dont want to submit it as it will cause full page reload.
        So we will prevent, it by calling current events prevetnDefault() method, which will prevent the default behaviour.
      */
      evt.preventDefault();


      /*
        Now we have to take our data from form
      */
      var num1 = $('#num1').val();
      var num2 = $('#num2').val();

      /*
        Now we have to create an object, that contains,
        the data needed to be passed to the other page.
      */

      var data = {
        number1:num1,
        number2:num2
      };
      var url = './sum.php';

      /*
        Now we have to send these data using HTTP post method,
        using AJAX. We have
      */

      $.post(url,data,function(response) {
        $('#result').html(response);
        /*
          Puts the response from server as the HTML contentto the element with id 'result'
          
        */
      });
      /*
        The above lines literal meaning is like below.
        "Send the 'data' to  the  'url' with HTTP POST method and when request is success call the assigned function"
        Also note that jquery will pass the reponse from the url as the first argument to the function,
        which I collected in the variable named response
      */

      /*Note that ajax will be "asynchronous, which means it just tells like, this request must be done.
        ie. it wont block the execution, until the request is finished.
        So the lines below this request will execute before the ajax request is finsihed.
        That is why you get the alert message first.
      "*/
      alert('Request initiated');

    }


  );
});
