<?php

include_once '/home/eipchpco/beta.wiapp.it/portal/required/header.php';
 		
include_once '/home/eipchpco/beta.wiapp.it/portal/required/navbar_top.php';

echo "<!-- Navbar Tabs -->  \n";
echo "<div class=\"subnavbar\">\n";
echo "  <div class=\"subnavbar-inner\">\n";
echo "    <div class=\"container\">\n";
echo "      <ul class=\"mainnav\">\n";
echo "        <li><a href=\"index.php\"><i class=\"icon-dashboard\"></i><span>Dashboard</span> </a> </li>\n";
echo "        <li><a href=\"reports.php\"><i class=\"icon-list-alt\"></i><span>Reports</span> </a> </li>\n";
echo "        <li><a href=\"guidely.php\"><i class=\"icon-facetime-video\"></i><span>App Tour</span> </a></li>\n";
echo "        <li class=\"active\"><a href=\"page/charts.php\"><i class=\"icon-bar-chart\"></i><span>Charts</span> </a> </li>\n";
echo "        <li><a href=\"shortcodes.php\"><i class=\"icon-code\"></i><span>Shortcodes</span> </a> </li>\n";
echo "        <li class=\"dropdown\"><a href=\"javascript:;\" class=\"dropdown-toggle\" data-toggle=\"dropdown\"> <i class=\"icon-long-arrow-down\"></i><span>Drops</span> <b class=\"caret\"></b></a>\n";
echo "          <ul class=\"dropdown-menu\">\n";
echo "            <li><a href=\"icons.php\">Icons</a></li>\n";
echo "            <li><a href=\"faq.php\">FAQ</a></li>\n";
echo "            <li><a href=\"pricing.php\">Pricing Plans</a></li>\n";
echo "            <li><a href=\"login.php\">Login</a></li>\n";
echo "            <li><a href=\"signup.php\">Signup</a></li>\n";
echo "            <li><a href=\"error.php\">404</a></li>\n";
echo "          </ul>\n";
echo "        </li>\n";
echo "      </ul>\n";
echo "    </div>\n";
echo "    <!-- /container --> \n";
echo "  </div>\n";
echo "  <!-- /subnavbar-inner --> \n";
echo "</div>\n";
echo "<!-- /subnavbar -->\n";
echo "<div class=\"main\">\n";
echo "  <div class=\"main-inner\">\n";
echo "    <div class=\"container\">\n";
echo "      <div class=\"row\">";
    

echo "    <div class=\"main\">\n";
echo "        <div class=\"main-inner\">\n";
echo "            <div class=\"container\">\n";
echo "                <div class=\"row\">\n";
echo "                    <div class=\"span6\">\n";
echo "                        <div class=\"widget\">\n";
echo "                            <div class=\"widget-header\">\n";
echo "                                <i class=\"icon-bar-chart\"></i>\n";




include_once'/home/eipchpco/beta.wiapp.it/portal/charts/bar_chart.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/charts/line_chart.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/charts/pie_chart.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/charts/donut_chart.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/charts/chart.php';



include_once '/home/eipchpco/beta.wiapp.it/portal/required/break_before_footer.php';    
    
include_once '/home/eipchpco/beta.wiapp.it/portal/modules/footer_top.php';
      
include_once '/home/eipchpco/beta.wiapp.it/portal/required/footer_bottom.php';

include_once '/home/eipchpco/beta.wiapp.it/portal/required/scripts.php';
    
include_once '/home/eipchpco/beta.wiapp.it/portal/pagedata/charts_data.php';
    
    
?>    
    
