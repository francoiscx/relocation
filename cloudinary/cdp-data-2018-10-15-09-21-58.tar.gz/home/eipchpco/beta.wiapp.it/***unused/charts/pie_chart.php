                                <h3>Pie Chart</h3>
                            </div>
                            <!-- /widget_header -->
                            <div class="widget-content">
                                <canvas id="pie-chart" class="chart-holder" width="438" height="250">
                                </canvas>
                                <!-- /pie-chart -->
                            </div>
                            <!-- /widget-content -->
                        </div>
                        <!-- /widget -->
                    </div>
                    <!-- /span6 -->
                    <div class="span6">
                        <div class="widget">
                            <div class="widget-header">
                                <i class="icon-bar-chart"></i>

