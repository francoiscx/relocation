                                <h3>Donut Chart</h3>
                            </div>
                            <!-- /widget_header -->
                            <div class="widget-content">
                                <canvas id="donut-chart" class="chart-holder" width="438" height="250">
                                </canvas>
                                <!-- /bar-chart -->
                            </div>
                            <!-- /widget-content -->
                        </div>
                        <!-- /widget -->
                        <div class="widget">
                            <div class="widget-header">
                                <i class="icon-bar-chart"></i>
