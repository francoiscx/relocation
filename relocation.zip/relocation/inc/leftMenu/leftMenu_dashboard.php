<?php
if($siteSection == "Dashboard") {

echo '    <li class="active treeview">';

} else {
    
echo '    <li class="treeview">';
    
}
?>


        <a href="#">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              




<?php
if($sitePage == "byEmployee") {

echo '          <li class="active"><a href="index.php"><i class="fa fa-circle"></i>List By Employee</a></li>';
            
} else {

echo '            <li class="active"><a href="index.php"><i class="fa fa-circle-o"></i>List By Employee</a></li>';
}
?>

<?php
//if($sitePage == "byClients") {

//echo '          <li class="active"><a href="#"><i class="fa fa-circle"></i>List By Clients</a></li>';
            
//} else {

//echo '            <li class="active"><a href="#"><i class="fa fa-circle-o"></i>List By Clients</a></li>';
//}
?>

          </ul>
</li>