TODO
====

## Write comments and action items here or in comments

Use keywords TODO, FIXME, REVIEW in comments in the code.

-----------------------

Found 3 TODO items in 3 files

  * cloudinary-main.coffee
    * (187, 45) @imageTag(publicId, options).toHtml() # TODO need to call cloudinary_update
  * config.coffee
    * (87, 49) if !@configuration? || new_config == true # REVIEW do we need/want this auto-initialization?
  * utils.coffee
    * (210, 3) TODO create a shim that will switch between jQuery and lodash
  * header-jquery-upload.coffee
    * (21, 4) #  FIXME add fileupload dependency