const presets = [
    [
      "@babel/preset-env",
    ]
];
const plugins = ["@babel/plugin-proposal-object-rest-spread"];

module.exports = {presets, plugins};
