import * as cloudinary from './namespace/cloudinary-core';
export * from './namespace/cloudinary-core';

export default cloudinary;
