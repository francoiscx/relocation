<?php
\Cloudinary::config(array(
    "cloud_name" => "my_cloud_name",
    "api_key" => "123456789012345",
    "api_secret" => "abcdefghijklmnopqrstuvwxyz1"
));

R::setup('mysql:host=my_database.mydomain.com;dbname=photo_album', 'username', 'password');
?>

